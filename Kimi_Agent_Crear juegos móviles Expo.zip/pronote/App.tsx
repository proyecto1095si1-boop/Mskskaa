/**
 * ProNote - Aplicación Principal (Versión 2.0)
 * Punto de entrada con todas las funcionalidades avanzadas
 */

import React, { useEffect, useState, useCallback } from 'react';
import { 
  View, 
  StyleSheet, 
  StatusBar, 
  useColorScheme,
  SafeAreaView,
  Dimensions,
  LogBox,
} from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { useKeepAwake } from 'expo-keep-awake';
import { BottomSheetModalProvider } from '@gorhom/bottom-sheet';
import { PortalProvider } from '@gorhom/portal';
import Toast from 'react-native-toast-message';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { I18nextProvider } from 'react-i18next';

// i18n
import i18n from './src/i18n';

// Store
import { useDrawingStore } from './src/store/useDrawingStore';

// Servicios
import {
  storageService,
  analyticsService,
  ocrService,
  cloudSyncService,
} from './src/services';

// Componentes
import { ProNoteCanvas } from './src/components/ProNoteCanvas';
import { Toolbar } from './src/components/Toolbar';
import { TopBar } from './src/components/TopBar';
import { LayerPanel } from './src/components/LayerPanel';
import { ColorPicker } from './src/components/ColorPicker';
import { ZoomControls } from './src/components/ZoomControls';
import { GlobalSearch } from './src/components/common/GlobalSearch';
import { Onboarding } from './src/components/onboarding/Onboarding';

// Hooks
import { useAdvancedGestures } from './src/hooks/gestures/useAdvancedGestures';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

// Ignorar warnings específicos
LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'ViewPropTypes will be removed from React Native',
]);

// React Query client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      staleTime: 5 * 60 * 1000, // 5 minutos
    },
  },
});

// ============================================================================
// COMPONENTE PRINCIPAL
// ============================================================================

export default function App() {
  // Mantener pantalla encendida
  useKeepAwake();

  const colorScheme = useColorScheme();
  const isDarkMode = colorScheme === 'dark';

  // Estado local
  const [showLayerPanel, setShowLayerPanel] = useState(false);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [canvasSize, setCanvasSize] = useState({
    width: SCREEN_WIDTH,
    height: SCREEN_HEIGHT - 120,
  });

  // Store
  const {
    createDocument,
    getCurrentDocument,
    loadDocument,
    activeTool,
    zoom,
    preferences,
  } = useDrawingStore();

  // Gestos avanzados
  const gestures = useAdvancedGestures({
    minScale: 0.1,
    maxScale: 5,
    enableRotation: false,
    enablePan: activeTool === 'hand',
  });

  // Inicialización de la app
  useEffect(() => {
    initializeApp();
  }, []);

  const initializeApp = async () => {
    try {
      // Inicializar servicios
      await storageService.initialize();
      await analyticsService.initialize();

      // Verificar primera ejecución
      const hasSeenOnboarding = await storageService.loadSettings()
        .then(s => s.hasSeenOnboarding);
      
      if (!hasSeenOnboarding) {
        setShowOnboarding(true);
      }

      // Crear documento inicial si no hay ninguno
      const doc = getCurrentDocument();
      if (!doc) {
        createDocument();
      }

      // Iniciar sesión de analytics
      analyticsService.startSession();

      setIsInitialized(true);
    } catch (error) {
      console.error('Error initializing app:', error);
      Toast.show({
        type: 'error',
        text1: 'Error de inicialización',
        text2: 'Por favor, reinicia la aplicación',
      });
    }
  };

  // Manejar cierre de onboarding
  const handleOnboardingComplete = useCallback(async () => {
    setShowOnboarding(false);
    await storageService.saveSettings({ hasSeenOnboarding: true });
    analyticsService.trackEvent('onboarding_completed');
  }, []);

  // Manejar selección de resultado de búsqueda
  const handleSearchResult = useCallback((result: any) => {
    if (result.documentId) {
      loadDocument(result.documentId);
    }
    analyticsService.trackEvent('search_result_selected', {
      type: result.type,
    });
  }, [loadDocument]);

  // ==========================================================================
  // RENDER
  // ==========================================================================

  if (!isInitialized) {
    return (
      <View style={[styles.container, styles.loadingContainer]}>
        <StatusBar
          barStyle={isDarkMode ? 'light-content' : 'dark-content'}
          backgroundColor={isDarkMode ? '#121212' : '#FFFFFF'}
        />
        {/* Aquí iría un componente de loading */}
      </View>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <I18nextProvider i18n={i18n}>
        <GestureHandlerRootView style={styles.container}>
          <PortalProvider>
            <BottomSheetModalProvider>
              <SafeAreaView style={[
                styles.container,
                isDarkMode ? styles.darkContainer : styles.lightContainer
              ]}>
                <StatusBar
                  barStyle={isDarkMode ? 'light-content' : 'dark-content'}
                  backgroundColor={isDarkMode ? '#121212' : '#FFFFFF'}
                />

                {/* Onboarding */}
                {showOnboarding && (
                  <Onboarding onComplete={handleOnboardingComplete} />
                )}

                {/* Barra superior */}
                <TopBar
                  onToggleLayerPanel={() => setShowLayerPanel(!showLayerPanel)}
                  onToggleColorPicker={() => setShowColorPicker(!showColorPicker)}
                  onToggleSearch={() => setShowSearch(true)}
                />

                {/* Área principal */}
                <View style={styles.mainArea}>
                  {/* Canvas de dibujo */}
                  <ProNoteCanvas
                    width={canvasSize.width}
                    height={canvasSize.height}
                    gestures={gestures}
                  />

                  {/* Panel de capas (overlay) */}
                  {showLayerPanel && (
                    <LayerPanel
                      onClose={() => setShowLayerPanel(false)}
                    />
                  )}

                  {/* Selector de color (overlay) */}
                  {showColorPicker && (
                    <ColorPicker
                      onClose={() => setShowColorPicker(false)}
                    />
                  )}

                  {/* Controles de zoom */}
                  <ZoomControls />
                </View>

                {/* Barra de herramientas inferior */}
                <Toolbar />

                {/* Búsqueda global */}
                <GlobalSearch
                  visible={showSearch}
                  onClose={() => setShowSearch(false)}
                  onResultSelect={handleSearchResult}
                />

                {/* Toast notifications */}
                <Toast />
              </SafeAreaView>
            </BottomSheetModalProvider>
          </PortalProvider>
        </GestureHandlerRootView>
      </I18nextProvider>
    </QueryClientProvider>
  );
}

// ============================================================================
// ESTILOS
// ============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  lightContainer: {
    backgroundColor: '#FFFFFF',
  },
  darkContainer: {
    backgroundColor: '#121212',
  },
  mainArea: {
    flex: 1,
    position: 'relative',
  },
});
