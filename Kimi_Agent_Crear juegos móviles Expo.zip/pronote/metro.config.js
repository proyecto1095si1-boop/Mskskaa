const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Configuración para React Native Skia
config.resolver.assetExts.push('wasm');

// Soporte para archivos de fuentes
config.resolver.assetExts.push('ttf');
config.resolver.assetExts.push('otf');

module.exports = config;
