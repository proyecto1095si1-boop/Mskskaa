import { registerRootComponent } from 'expo';
import App from './App';

// Registra el componente principal
registerRootComponent(App);
