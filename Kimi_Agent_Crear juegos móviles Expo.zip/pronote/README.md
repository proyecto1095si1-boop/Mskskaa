# ProNote 2.0 📝✨

**La aplicación de toma de notas más potente y completa para iOS y Android.**

Construida con **Expo**, **React Native Skia** y un motor de dibujo acelerado por GPU que ofrece **cero latencia** y **60/120 FPS**.

---

## 🚀 Características Principales

### 🎨 Motor de Dibujo Profesional
- **Cero Latencia**: Renderizado directo en UI Thread con React Native Skia
- **Suavizado Catmull-Rom**: Curvas suaves y naturales
- **Ancho Variable Dinámico**: Basado en velocidad y presión del stylus
- **Lazy Brush**: Estabilización avanzada para trazos precisos
- **Palm Rejection**: Modo exclusivo para stylus
- **60/120 FPS**: Animaciones fluidas sin bloqueos

### 🛠️ Herramientas de Dibujo
| Herramienta | Descripción |
|-------------|-------------|
| ✏️ **Pluma** | Trazos con presión y velocidad |
| 🖍️ **Resaltador** | Tinta translúcida con blend mode multiply |
| 🔴 **Láser** | Trazos efímeros para presentaciones |
| 📎 **Cinta** | Textura de washi tape |
| 🧼 **Borrador** | Por píxeles o por objeto completo |
| 📏 **Regla** | Proyección vectorial para líneas perfectas |
| ⬜ **Formas** | Detección automática de círculos, rectángulos, líneas |
| ➰ **Lazo** | Selección múltiple con punto-en-polígono |
| 🔄 **Simetría** | Mandala, espejo y kaleidoscopio |

### 📄 Gestión de Documentos
- 📑 **Múltiples páginas** por documento
- 🗂️ **Sistema de capas** con z-index y blend modes
- 🏷️ **Etiquetas** y favoritos
- 🔍 **Búsqueda global** con Fuse.js
- 💾 **Auto-guardado** configurable
- ↩️ **Undo/Redo** ilimitado

### 📤 Exportación e Importación
| Formato | Exportar | Importar | OCR |
|---------|----------|----------|-----|
| **PDF** | ✅ | ✅ | ✅ |
| **PNG/JPG** | ✅ | ✅ | ✅ |
| **SVG** | ✅ | ❌ | ❌ |
| **ProNote** | ✅ | ✅ | ❌ |
| **Markdown** | ✅ | ✅ | ❌ |
| **Texto** | ✅ | ✅ | ❌ |

### 🌐 Sincronización y Colaboración
- ☁️ **Sync en la nube** con Supabase
- 👥 **Colaboración en tiempo real**
- 🔄 **Resolución de conflictos**
- 💾 **Backups automáticos**
- 📴 **Modo offline** con cola de cambios

### 🎯 Funcionalidades Avanzadas
- 🔍 **OCR**: Reconocimiento de texto en imágenes (Tesseract.js)
- 🎙️ **Audio**: Grabación sincronizada con notas
- 📐 **Plantillas**: Cornell, Bullet Journal, Kanban, y más
- 🎨 **Temas**: Claro, oscuro, sistema
- 🌍 **11 Idiomas**: Incluyendo RTL (árabe)
- 📊 **Analytics**: Métricas de uso (opcional)

---

## 🛠️ Stack Tecnológico

### Core
| Tecnología | Versión | Uso |
|------------|---------|-----|
| Expo SDK | 50 | Runtime y build system |
| React Native | 0.73 | Framework UI |
| TypeScript | 5.3 | Tipado estático |

### Gráficos y Animación
| Tecnología | Versión | Uso |
|------------|---------|-----|
| @shopify/react-native-skia | 0.1.230 | Canvas 2D GPU-acelerado |
| react-native-reanimated | 3.6 | Animaciones de UI |
| react-native-gesture-handler | 2.14 | Gestos táctiles |

### Estado y Datos
| Tecnología | Versión | Uso |
|------------|---------|-----|
| Zustand | 4.5 | Estado global |
| Immer | 10.0 | Inmutabilidad |
| TanStack Query | 5.17 | Fetching y caching |

### Servicios
| Tecnología | Versión | Uso |
|------------|---------|-----|
| Supabase | 2.39 | Backend y sync |
| Tesseract.js | 5.0 | OCR |
| pdf-lib | 1.17 | Manipulación PDF |
| expo-av | 13.10 | Audio |

---

## 📁 Estructura del Proyecto

```
pronote/
├── src/
│   ├── components/           # Componentes React
│   │   ├── drawing/         # Componentes de dibujo
│   │   ├── toolbar/         # Barras de herramientas
│   │   ├── panels/          # Paneles (capas, color)
│   │   ├── modals/          # Modales
│   │   ├── common/          # Componentes comunes
│   │   └── onboarding/      # Pantallas de bienvenida
│   ├── hooks/               # Custom hooks
│   │   ├── drawing/         # Hooks de dibujo
│   │   ├── gestures/        # Hooks de gestos
│   │   ├── storage/         # Hooks de almacenamiento
│   │   └── ui/              # Hooks de UI
│   ├── services/            # Servicios
│   │   ├── ocr/            # OCR (Tesseract)
│   │   ├── audio/          # Grabación de audio
│   │   ├── pdf/            # Exportación PDF
│   │   ├── sync/           # Sincronización cloud
│   │   ├── templates/      # Sistema de plantillas
│   │   ├── analytics/      # Métricas de uso
│   │   ├── storage/        # Almacenamiento local
│   │   ├── export/         # Exportación múltiples formatos
│   │   └── import/         # Importación
│   ├── store/               # Estado global (Zustand)
│   ├── types/               # Definiciones TypeScript
│   ├── utils/               # Utilidades
│   ├── i18n/                # Internacionalización
│   │   └── locales/         # Archivos de traducción
│   ├── constants/           # Constantes
│   ├── navigation/          # Navegación
│   ├── screens/             # Pantallas
│   └── assets/              # Recursos estáticos
├── App.tsx                  # Punto de entrada
├── package.json             # Dependencias
├── tsconfig.json            # Configuración TypeScript
├── babel.config.js          # Configuración Babel
├── metro.config.js          # Configuración Metro
└── app.json                 # Configuración Expo
```

---

## 🚀 Instalación

### Requisitos Previos
- Node.js 18+
- npm 9+ o yarn
- Expo CLI

### Paso a Paso

```bash
# 1. Clonar el repositorio
git clone https://github.com/tuusuario/pronote.git
cd pronote

# 2. Instalar dependencias
npm install

# 3. Configurar variables de entorno (opcional)
cp .env.example .env
# Editar .env con tus credenciales de Supabase

# 4. Iniciar servidor de desarrollo
npx expo start

# 5. Escanear QR con Expo Go
# iOS: App Store
# Android: Google Play
```

---

## 📱 Compilar para Producción

### Android (APK/AAB)

```bash
# Configurar EAS
npm install -g eas-cli
eas login

# Compilar APK (pruebas)
eas build -p android --profile preview

# Compilar AAB (Google Play)
eas build -p android --profile production
```

### iOS (IPA)

```bash
# Requiere Mac con Xcode
eas build -p ios --profile production
```

---

## 🔧 Configuración Avanzada

### Supabase (Sync en la nube)

1. Crear proyecto en [Supabase](https://supabase.com)
2. Copiar URL y anon key
3. Configurar en `.env`:

```env
SUPABASE_URL=https://tu-proyecto.supabase.co
SUPABASE_KEY=tu-anon-key
```

### OCR (Tesseract)

El OCR funciona localmente. Idiomas soportados:
- Inglés (eng)
- Español (spa)
- Francés (fra)
- Alemán (deu)
- Italiano (ita)
- Portugués (por)
- Ruso (rus)
- Chino (chi_sim)
- Japonés (jpn)
- Coreano (kor)
- Árabe (ara)

---

## 🎨 Sistema de Plantillas

### Plantillas Incluidas

| Plantilla | Categoría | Premium |
|-----------|-----------|---------|
| Cuaderno en blanco | Productividad | ❌ |
| Papel rayado | Educación | ❌ |
| Papel cuadriculado | Creativo | ❌ |
| Notas de reunión | Negocios | ❌ |
| Método Cornell | Estudio | ✅ |
| Bullet Journal | Planificación | ✅ |
| Tablero Kanban | Proyecto | ✅ |
| Planificador semanal | Planificación | ✅ |

### Crear Plantilla Personalizada

```typescript
import { templateService } from './src/services';

const myTemplate = await templateService.saveUserTemplate(
  document,
  'Mi Plantilla',
  'Descripción de mi plantilla'
);
```

---

## 📊 Analytics (Opcional)

ProNote incluye un sistema de analytics para entender el uso de la app:

```typescript
import { analyticsService } from './src/services';

// Registrar evento
analyticsService.trackEvent('feature_used', { feature: 'ocr' });

// Obtener métricas
const metrics = await analyticsService.getMetrics();
console.log(metrics.totalSessions);
```

**Nota**: Todos los datos se almacenan localmente. No se envía información a servidores externos sin consentimiento.

---

## 🧪 Testing

```bash
# Ejecutar tests
npm test

# Tests con watch
npm run test:watch

# Cobertura
npm run test:coverage
```

---

## 📚 Documentación de API

### Motor de Dibujo (useBrushEngine)

```typescript
import { useBrushEngine } from './src/hooks/drawing';

const brush = useBrushEngine({
  color: '#000000',
  strokeWidth: 3,
  smoothing: 0.7,
  velocitySensitivity: 0.5,
});

// Iniciar trazo
const stroke = brush.startStroke({ x: 100, y: 100, pressure: 0.5 });

// Actualizar
brush.updateStroke({ x: 110, y: 110, pressure: 0.6 });

// Finalizar
brush.endStroke();
```

### Gestos Avanzados (useAdvancedGestures)

```typescript
import { useAdvancedGestures } from './src/hooks/gestures';

const gestures = useAdvancedGestures({
  minScale: 0.1,
  maxScale: 5,
  enableRotation: true,
  enablePan: true,
}, {
  onGestureUpdate: (state) => {
    console.log(state.scale, state.rotation);
  },
});
```

---

## 🤝 Contribuir

1. Fork el repositorio
2. Crear rama (`git checkout -b feature/nueva-funcionalidad`)
3. Commit cambios (`git commit -am 'Agregar nueva funcionalidad'`)
4. Push a la rama (`git push origin feature/nueva-funcionalidad`)
5. Crear Pull Request

---

## 📄 Licencia

MIT License - Libre para uso personal y comercial.

---

## 🙏 Créditos

- [React Native Skia](https://shopify.github.io/react-native-skia/) - Motor gráfico
- [Expo](https://expo.dev/) - Plataforma de desarrollo
- [Supabase](https://supabase.com/) - Backend
- [Tesseract.js](https://tesseract.projectnaptha.com/) - OCR
- [Zustand](https://github.com/pmndrs/zustand) - Estado
- [d3-shape](https://github.com/d3/d3-shape) - Curvas matemáticas

---

## 📞 Soporte

- 📧 Email: support@pronote.app
- 💬 Discord: [Unirse](https://discord.gg/pronote)
- 🐛 Issues: [GitHub Issues](https://github.com/tuusuario/pronote/issues)

---

**¡Hecho con ❤️ para la comunidad de creativos!**
