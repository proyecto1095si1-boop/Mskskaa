/**
 * ProNote - Type Definitions
 * Sistema de capas estrictamente tipado para aplicación de toma de notas
 */

import { SkPath, SkImage, BlendMode, Paint } from "@shopify/react-native-skia";

// ============================================================================
// ENUMS Y TIPOS BÁSICOS
// ============================================================================

export type LayerType = 'ink' | 'text' | 'image' | 'sticker' | 'table';

export type ToolType = 
  | 'pen' 
  | 'highlighter' 
  | 'tape' 
  | 'eraser' 
  | 'lasso' 
  | 'ruler'
  | 'shape'
  | 'laser'
  | 'hand';

export type BlendModeType = 'srcOver' | 'multiply' | 'clear' | 'dstOut';

export type ShapeType = 'circle' | 'rectangle' | 'triangle' | 'line' | 'arrow' | 'none';

// ============================================================================
// INTERFACES BASE
// ============================================================================

/**
 * Nodo base que todas las capas deben implementar
 * Contiene propiedades transformables comunes
 */
export interface BaseNode {
  id: string;
  type: LayerType;
  x: number;
  y: number;
  rotation: number;
  scale: number;
  zIndex: number;
  locked: boolean;
  visible: boolean;
  opacity: number;
  createdAt: number;
  modifiedAt: number;
}

/**
 * Punto táctil con propiedades extendidas para cálculos de velocidad y presión
 */
export interface TouchPoint {
  x: number;
  y: number;
  timestamp: number;
  pressure: number;
  velocity: number;
}

/**
 * Representa un trazo de tinta con metadatos completos
 */
export interface InkStroke {
  path: SkPath;
  pathData: string; // SVG path string para serialización
  points: TouchPoint[];
  color: string;
  strokeWidth: number;
  toolType: 'pen' | 'highlighter' | 'tape' | 'laser';
  blendMode: BlendModeType;
  opacity: number;
  bounds: {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
  };
}

// ============================================================================
// NODOS ESPECÍFICOS POR TIPO DE CAPA
// ============================================================================

/**
 * Nodo de tinta/dibujo - Almacena trazos vectoriales
 */
export interface InkNode extends BaseNode {
  type: 'ink';
  strokes: InkStroke[];
  currentStroke: InkStroke | null;
  brushSettings: BrushSettings;
}

/**
 * Nodo de texto - Texto editable con formato
 */
export interface TextNode extends BaseNode {
  type: 'text';
  text: string;
  fontFamily: string;
  fontSize: number;
  fontWeight: 'normal' | 'bold' | 'light';
  color: string;
  backgroundColor: string | null;
  width: number;
  height: number;
  alignment: 'left' | 'center' | 'right';
  isEditing: boolean;
}

/**
 * Nodo de imagen - Referencia a imagen local
 */
export interface ImageNode extends BaseNode {
  type: 'image';
  uri: string; // file:// URI local
  fileName: string;
  aspectRatio: number;
  width: number;
  height: number;
  originalWidth: number;
  originalHeight: number;
  cropBounds?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

/**
 * Nodo de sticker - Elemento gráfico predefinido
 */
export interface StickerNode extends BaseNode {
  type: 'sticker';
  stickerId: string;
  category: string;
  uri: string;
  width: number;
  height: number;
}

/**
 * Celda de tabla individual
 */
export interface TableCell {
  row: number;
  col: number;
  content: string;
  backgroundColor: string;
  textColor: string;
  fontSize: number;
  alignment: 'left' | 'center' | 'right';
}

/**
 * Nodo de tabla - Cuadrícula editable
 */
export interface TableNode extends BaseNode {
  type: 'table';
  rows: number;
  cols: number;
  cells: TableCell[][];
  rowHeights: number[];
  colWidths: number[];
  borderColor: string;
  borderWidth: number;
  headerRow: boolean;
  headerBackgroundColor: string;
}

// ============================================================================
// TIPOS DE UNIÓN
// ============================================================================

export type Node = InkNode | TextNode | ImageNode | StickerNode | TableNode;

// ============================================================================
// CONFIGURACIÓN DE HERRAMIENTAS
// ============================================================================

/**
 * Configuración del pincel/brush
 */
export interface BrushSettings {
  color: string;
  strokeWidth: number;
  minStrokeWidth: number;
  maxStrokeWidth: number;
  opacity: number;
  toolType: 'pen' | 'highlighter' | 'tape' | 'laser';
  blendMode: BlendModeType;
  velocitySensitivity: number; // 0-1, qué tanto afecta la velocidad al ancho
  pressureSensitivity: number; // 0-1, qué tanto afecta la presión
  smoothing: number; // 0-1, nivel de suavizado Catmull-Rom
  lazyRadius: number; // Radio del pincel perezoso (estabilización)
}

/**
 * Configuración de la regla virtual
 */
export interface RulerSettings {
  x: number;
  y: number;
  angle: number;
  length: number;
  visible: boolean;
  snapDistance: number;
}

/**
 * Configuración del modo láser
 */
export interface LaserSettings {
  fadeDuration: number; // ms
  color: string;
  strokeWidth: number;
}

// ============================================================================
// ESTADO DE LA APLICACIÓN
// ============================================================================

/**
 * Estado de una página individual
 */
export interface Page {
  id: string;
  name: string;
  nodes: Node[];
  background: {
    type: 'blank' | 'lined' | 'grid' | 'dotted';
    color: string;
    lineColor: string;
    lineSpacing: number;
  };
  thumbnail: string | null;
  createdAt: number;
  modifiedAt: number;
}

/**
 * Estado de un documento/nota completa
 */
export interface Document {
  id: string;
  title: string;
  pages: Page[];
  currentPageIndex: number;
  tags: string[];
  favorite: boolean;
  createdAt: number;
  modifiedAt: number;
}

/**
 * Estado global de la aplicación
 */
export interface AppState {
  // Documentos
  documents: Document[];
  currentDocumentId: string | null;
  
  // Herramientas activas
  activeTool: ToolType;
  brushSettings: BrushSettings;
  rulerSettings: RulerSettings;
  laserSettings: LaserSettings;
  
  // Configuración de vista
  zoom: number;
  panX: number;
  panY: number;
  showGrid: boolean;
  showMinimap: boolean;
  
  // Selección
  selectedNodeIds: string[];
  selectionBounds: {
    x: number;
    y: number;
    width: number;
    height: number;
  } | null;
  
  // Historial para undo/redo
  history: HistoryState[];
  historyIndex: number;
  maxHistorySize: number;
  
  // Preferencias
  preferences: UserPreferences;
}

/**
 * Estado para historial (undo/redo)
 */
export interface HistoryState {
  type: 'add' | 'delete' | 'modify' | 'transform' | 'reorder';
  nodeIds: string[];
  previousState: Partial<Node>[];
  newState: Partial<Node>[];
  timestamp: number;
}

/**
 * Preferencias del usuario
 */
export interface UserPreferences {
  language: 'es' | 'en';
  theme: 'light' | 'dark' | 'system';
  palmRejection: boolean;
  stylusOnly: boolean;
  autoSave: boolean;
  autoSaveInterval: number;
  defaultBrushColor: string;
  defaultBrushSize: number;
  showTooltips: boolean;
  hapticFeedback: boolean;
}

// ============================================================================
// PROPIEDADES DE COMPONENTES
// ============================================================================

/**
 * Props para el componente Canvas principal
 */
export interface CanvasProps {
  page: Page;
  width: number;
  height: number;
  zoom: number;
  panX: number;
  panY: number;
  onNodeAdd: (node: Node) => void;
  onNodeUpdate: (id: string, updates: Partial<Node>) => void;
  onNodeDelete: (id: string) => void;
  onNodesSelect: (ids: string[]) => void;
}

/**
 * Props para renderizador de capas
 */
export interface LayerRendererProps {
  node: Node;
  isSelected: boolean;
  zoom: number;
  onTransform: (transform: TransformMatrix) => void;
}

/**
 * Matriz de transformación 2D
 */
export interface TransformMatrix {
  translateX: number;
  translateY: number;
  scale: number;
  rotation: number;
}

/**
 * Props para herramienta de zoombox
 */
export interface ZoomBoxProps {
  visible: boolean;
  position: 'bottom-left' | 'bottom-right' | 'top-left' | 'top-right';
  zoomLevel: number;
  sourceRect: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  onPositionChange: (x: number, y: number) => void;
}

// ============================================================================
// EVENTOS Y CALLBACKS
// ============================================================================

export interface TouchEvent {
  x: number;
  y: number;
  type: 'start' | 'move' | 'end' | 'cancel';
  timestamp: number;
  pressure: number;
  id: number;
}

export interface ToolProcessorResult {
  path?: SkPath;
  nodes?: Node[];
  shouldCommit: boolean;
  cursor?: 'default' | 'crosshair' | 'move' | 'resize' | 'rotate';
}

// ============================================================================
// UTILIDADES DE TIPO
// ============================================================================

export type Nullable<T> = T | null;
export type Optional<T> = T | undefined;

// Type guards
export const isInkNode = (node: Node): node is InkNode => node.type === 'ink';
export const isTextNode = (node: Node): node is TextNode => node.type === 'text';
export const isImageNode = (node: Node): node is ImageNode => node.type === 'image';
export const isStickerNode = (node: Node): node is StickerNode => node.type === 'sticker';
export const isTableNode = (node: Node): node is TableNode => node.type === 'table';
