/**
 * ProNote - Tool Processor
 * Motor matemático para procesamiento avanzado de herramientas de dibujo
 * Incluye: suavizado Catmull-Rom, ancho variable, reconocimiento de formas,
 * proyección vectorial, detección de colisiones y más.
 */

import { SkPath, Skia, PathOp } from "@shopify/react-native-skia";
import { line, curveCatmullRom, curveBasis } from "d3-shape";
import {
  TouchPoint,
  InkStroke,
  BrushSettings,
  RulerSettings,
  Node,
  InkNode,
  ToolType,
  ShapeType,
  ToolProcessorResult,
} from "@types/index";

// ============================================================================
// CONSTANTES Y CONFIGURACIÓN
// ============================================================================

const CONFIG = {
  // Suavizado
  CATMULL_ROM_ALPHA: 0.5,
  MIN_POINTS_FOR_SMOOTHING: 3,
  
  // Ancho variable
  VELOCITY_SCALE_FACTOR: 0.8,
  PRESSURE_SCALE_FACTOR: 0.5,
  MIN_VELOCITY: 0.5,
  MAX_VELOCITY: 20,
  
  // Lazy brush (pincel perezoso)
  LAZY_SMOOTHING_FACTOR: 0.15,
  
  // Reconocimiento de formas
  SHAPE_RECOGNITION_DELAY: 500, // ms
  CIRCLE_VARIANCE_THRESHOLD: 0.15,
  CORNER_ANGLE_THRESHOLD: 30, // grados
  MIN_SHAPE_POINTS: 10,
  
  // Lazo
  LASSO_CLOSE_THRESHOLD: 30, // píxeles
  
  // Borrador
  ERASER_WIDTH: 20,
};

// ============================================================================
// SISTEMA DE PUNTO PEREZOSO (LAZY BRUSH)
// ============================================================================

export class LazyBrush {
  private x: number = 0;
  private y: number = 0;
  private targetX: number = 0;
  private targetY: number = 0;
  private radius: number;

  constructor(radius: number = 5) {
    this.radius = radius;
  }

  setRadius(radius: number) {
    this.radius = radius;
  }

  update(targetX: number, targetY: number): { x: number; y: number; hasMoved: boolean } {
    this.targetX = targetX;
    this.targetY = targetY;

    const dx = this.targetX - this.x;
    const dy = this.targetY - this.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance > this.radius) {
      const angle = Math.atan2(dy, dx);
      this.x = this.targetX - Math.cos(angle) * this.radius;
      this.y = this.targetY - Math.sin(angle) * this.radius;
      return { x: this.x, y: this.y, hasMoved: true };
    }

    // Suavizado adicional
    this.x += (this.targetX - this.x) * CONFIG.LAZY_SMOOTHING_FACTOR;
    this.y += (this.targetY - this.y) * CONFIG.LAZY_SMOOTHING_FACTOR;

    return { x: this.x, y: this.y, hasMoved: distance > 0.5 };
  }

  reset(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.targetX = x;
    this.targetY = y;
  }

  getPosition() {
    return { x: this.x, y: this.y };
  }
}

// ============================================================================
// SUAVIZADO DE TRAZOS (CATMULL-ROM SPLINES)
// ============================================================================

export class StrokeSmoother {
  /**
   * Suaviza una serie de puntos usando splines Catmull-Rom
   */
  static catmullRom(points: TouchPoint[], alpha: number = CONFIG.CATMULL_ROM_ALPHA): TouchPoint[] {
    if (points.length < CONFIG.MIN_POINTS_FOR_SMOOTHING) return points;

    const smoothed: TouchPoint[] = [];
    const numSegments = 10; // Puntos por segmento

    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[Math.max(0, i - 1)];
      const p1 = points[i];
      const p2 = points[i + 1];
      const p3 = points[Math.min(points.length - 1, i + 2)];

      for (let t = 0; t < numSegments; t++) {
        const tt = t / numSegments;
        const point = this.interpolateCatmullRom(p0, p1, p2, p3, tt, alpha);
        smoothed.push(point);
      }
    }

    // Agregar último punto
    smoothed.push(points[points.length - 1]);

    return smoothed;
  }

  /**
   * Interpolación Catmull-Rom entre 4 puntos de control
   */
  private static interpolateCatmullRom(
    p0: TouchPoint,
    p1: TouchPoint,
    p2: TouchPoint,
    p3: TouchPoint,
    t: number,
    alpha: number
  ): TouchPoint {
    const t0 = 0;
    const t1 = this.getT(t0, alpha, p0, p1);
    const t2 = this.getT(t1, alpha, p1, p2);
    const t3 = this.getT(t2, alpha, p2, p3);

    const ttt = t1 + t * (t2 - t1);

    const A1 = this.multiplyPoint(this.subtractPoints(p0, p1), (t0 - ttt) / (t0 - t1));
    const A2 = this.multiplyPoint(this.subtractPoints(p2, p1), (t2 - ttt) / (t2 - t1));
    const A3 = this.addPoints(p1, this.addPoints(A1, A2));

    const B1 = this.multiplyPoint(this.subtractPoints(p1, p2), (t1 - ttt) / (t1 - t2));
    const B2 = this.multiplyPoint(this.subtractPoints(p3, p2), (t3 - ttt) / (t3 - t2));
    const B3 = this.addPoints(p2, this.addPoints(B1, B2));

    const C1 = this.multiplyPoint(this.subtractPoints(A3, B3), (t1 - ttt) / (t1 - t2));
    const C2 = this.addPoints(B3, C1);

    return {
      x: C2.x,
      y: C2.y,
      timestamp: p1.timestamp + t * (p2.timestamp - p1.timestamp),
      pressure: p1.pressure + t * (p2.pressure - p1.pressure),
      velocity: p1.velocity + t * (p2.velocity - p1.velocity),
    };
  }

  private static getT(t: number, alpha: number, p0: TouchPoint, p1: TouchPoint): number {
    const dx = p1.x - p0.x;
    const dy = p1.y - p0.y;
    const d = Math.sqrt(dx * dx + dy * dy);
    return Math.pow(d, alpha) + t;
  }

  private static subtractPoints(a: TouchPoint, b: TouchPoint): TouchPoint {
    return { ...a, x: a.x - b.x, y: a.y - b.y };
  }

  private static addPoints(a: TouchPoint, b: TouchPoint): TouchPoint {
    return { ...a, x: a.x + b.x, y: a.y + b.y };
  }

  private static multiplyPoint(p: TouchPoint, scalar: number): TouchPoint {
    return { ...p, x: p.x * scalar, y: p.y * scalar };
  }

  /**
   * Suavizado B-Spline como alternativa
   */
  static bSpline(points: TouchPoint[]): TouchPoint[] {
    if (points.length < 4) return points;

    const smoothed: TouchPoint[] = [];
    const numSegments = 10;

    for (let i = 1; i < points.length - 2; i++) {
      const p0 = points[i - 1];
      const p1 = points[i];
      const p2 = points[i + 1];
      const p3 = points[i + 2];

      for (let t = 0; t < numSegments; t++) {
        const tt = t / numSegments;
        const t2 = tt * tt;
        const t3 = t2 * tt;

        const x =
          ((-t3 + 3 * t2 - 3 * tt + 1) * p0.x +
            (3 * t3 - 6 * t2 + 4) * p1.x +
            (-3 * t3 + 3 * t2 + 3 * tt + 1) * p2.x +
            t3 * p3.x) /
          6;

        const y =
          ((-t3 + 3 * t2 - 3 * tt + 1) * p0.y +
            (3 * t3 - 6 * t2 + 4) * p1.y +
            (-3 * t3 + 3 * t2 + 3 * tt + 1) * p2.y +
            t3 * p3.y) /
          6;

        smoothed.push({
          x,
          y,
          timestamp: p1.timestamp + tt * (p2.timestamp - p1.timestamp),
          pressure: p1.pressure + tt * (p2.pressure - p1.pressure),
          velocity: p1.velocity + tt * (p2.velocity - p1.velocity),
        });
      }
    }

    return smoothed;
  }
}

// ============================================================================
// CÁLCULO DE ANCHO VARIABLE
// ============================================================================

export class VariableWidthCalculator {
  /**
   * Calcula el ancho del trazo basado en velocidad y presión
   */
  static calculateWidth(
    point: TouchPoint,
    baseWidth: number,
    settings: BrushSettings
  ): number {
    // Factor de velocidad (más rápido = más fino)
    const normalizedVelocity = this.normalizeVelocity(point.velocity);
    const velocityFactor =
      1 - normalizedVelocity * settings.velocitySensitivity * CONFIG.VELOCITY_SCALE_FACTOR;

    // Factor de presión (más presión = más grueso)
    const pressureFactor =
      0.5 + point.pressure * settings.pressureSensitivity * CONFIG.PRESSURE_SCALE_FACTOR;

    // Ancho final
    let width = baseWidth * velocityFactor * pressureFactor;

    // Clamp entre min y max
    return Math.max(
      settings.minStrokeWidth,
      Math.min(settings.maxStrokeWidth, width)
    );
  }

  /**
   * Normaliza la velocidad a un valor entre 0 y 1
   */
  private static normalizeVelocity(velocity: number): number {
    const clamped = Math.max(
      CONFIG.MIN_VELOCITY,
      Math.min(CONFIG.MAX_VELOCITY, velocity)
    );
    return (clamped - CONFIG.MIN_VELOCITY) / (CONFIG.MAX_VELOCITY - CONFIG.MIN_VELOCITY);
  }

  /**
   * Calcula velocidad entre dos puntos
   */
  static calculateVelocity(p1: TouchPoint, p2: TouchPoint): number {
    const dx = p2.x - p1.x;
    const dy = p2.y - p1.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const timeDelta = p2.timestamp - p1.timestamp;
    return timeDelta > 0 ? distance / timeDelta : 0;
  }
}

// ============================================================================
// PROYECCIÓN VECTORIAL (REGLA)
// ============================================================================

export class RulerProjection {
  /**
   * Proyecta un punto sobre la línea de la regla
   * Ecuación de línea: Ax + By + C = 0
   */
  static projectPoint(
    point: { x: number; y: number },
    ruler: RulerSettings
  ): { x: number; y: number; distance: number } {
    // Convertir ángulo a radianes
    const angleRad = (ruler.angle * Math.PI) / 180;

    // Vector dirección de la regla
    const dx = Math.cos(angleRad);
    const dy = Math.sin(angleRad);

    // Vector desde el origen de la regla al punto
    const vx = point.x - ruler.x;
    const vy = point.y - ruler.y;

    // Proyección escalar
    const projection = vx * dx + vy * dy;

    // Limitar a la longitud de la regla
    const clampedProjection = Math.max(0, Math.min(ruler.length, projection));

    // Punto proyectado
    const projectedX = ruler.x + clampedProjection * dx;
    const projectedY = ruler.y + clampedProjection * dy;

    // Distancia al punto original
    const distX = point.x - projectedX;
    const distY = point.y - projectedY;
    const distance = Math.sqrt(distX * distX + distY * distY);

    return { x: projectedX, y: projectedY, distance };
  }

  /**
   * Verifica si un punto está cerca de la regla (dentro de snapDistance)
   */
  static shouldSnap(
    point: { x: number; y: number },
    ruler: RulerSettings
  ): boolean {
    const { distance } = this.projectPoint(point, ruler);
    return distance <= ruler.snapDistance;
  }

  /**
   * Obtiene los puntos de inicio y fin de la regla
   */
  static getEndpoints(ruler: RulerSettings): {
    start: { x: number; y: number };
    end: { x: number; y: number };
  } {
    const angleRad = (ruler.angle * Math.PI) / 180;
    return {
      start: { x: ruler.x, y: ruler.y },
      end: {
        x: ruler.x + Math.cos(angleRad) * ruler.length,
        y: ruler.y + Math.sin(angleRad) * ruler.length,
      },
    };
  }
}

// ============================================================================
// RECONOCIMIENTO DE FORMAS
// ============================================================================

export class ShapeRecognizer {
  private static points: TouchPoint[] = [];
  private static startTime: number = 0;

  static startRecognition() {
    this.points = [];
    this.startTime = Date.now();
  }

  static addPoint(point: TouchPoint) {
    this.points.push(point);
  }

  /**
   * Intenta reconocer una forma de los puntos acumulados
   * Retorna la forma detectada o null si no coincide
   */
  static recognize(): {
    shape: ShapeType;
    confidence: number;
    params: Record<string, number>;
  } | null {
    if (this.points.length < CONFIG.MIN_SHAPE_POINTS) return null;

    // Verificar si es un círculo
    const circleResult = this.recognizeCircle();
    if (circleResult.confidence > 0.8) {
      return { shape: 'circle', confidence: circleResult.confidence, params: circleResult.params };
    }

    // Verificar si es un rectángulo
    const rectResult = this.recognizeRectangle();
    if (rectResult.confidence > 0.8) {
      return { shape: 'rectangle', confidence: rectResult.confidence, params: rectResult.params };
    }

    // Verificar si es una línea
    const lineResult = this.recognizeLine();
    if (lineResult.confidence > 0.9) {
      return { shape: 'line', confidence: lineResult.confidence, params: lineResult.params };
    }

    return null;
  }

  /**
   * Reconocimiento de círculos usando varianza de distancia al centro
   */
  private static recognizeCircle(): { confidence: number; params: Record<string, number> } {
    const center = this.calculateCentroid(this.points);
    const distances = this.points.map((p) =>
      Math.sqrt(Math.pow(p.x - center.x, 2) + Math.pow(p.y - center.y, 2))
    );

    const meanRadius = distances.reduce((a, b) => a + b, 0) / distances.length;
    const variance =
      distances.reduce((sum, d) => sum + Math.pow(d - meanRadius, 2), 0) / distances.length;
    const stdDev = Math.sqrt(variance);

    const relativeVariance = stdDev / meanRadius;
    const confidence = Math.max(0, 1 - relativeVariance / CONFIG.CIRCLE_VARIANCE_THRESHOLD);

    return {
      confidence,
      params: {
        cx: center.x,
        cy: center.y,
        radius: meanRadius,
      },
    };
  }

  /**
   * Reconocimiento de rectángulos usando detección de esquinas
   */
  private static recognizeRectangle(): { confidence: number; params: Record<string, number> } {
    // Encontrar puntos extremos
    const minX = Math.min(...this.points.map((p) => p.x));
    const maxX = Math.max(...this.points.map((p) => p.x));
    const minY = Math.min(...this.points.map((p) => p.y));
    const maxY = Math.max(...this.points.map((p) => p.y));

    const width = maxX - minX;
    const height = maxY - minY;
    const aspectRatio = width / height;

    // Verificar si los puntos siguen un patrón rectangular
    let cornerCount = 0;
    const angles = this.calculateAngles();

    for (const angle of angles) {
      if (Math.abs(angle - 90) < CONFIG.CORNER_ANGLE_THRESHOLD) {
        cornerCount++;
      }
    }

    // Un rectángulo debería tener al menos 4 esquinas de ~90 grados
    const expectedCorners = this.points.length / 4;
    const confidence = Math.min(1, cornerCount / expectedCorners);

    return {
      confidence,
      params: {
        x: minX,
        y: minY,
        width,
        height,
      },
    };
  }

  /**
   * Reconocimiento de líneas rectas
   */
  private static recognizeLine(): { confidence: number; params: Record<string, number> } {
    if (this.points.length < 2) return { confidence: 0, params: {} };

    const first = this.points[0];
    const last = this.points[this.points.length - 1];

    // Calcular desviación de los puntos respecto a la línea ideal
    const lineLength = Math.sqrt(
      Math.pow(last.x - first.x, 2) + Math.pow(last.y - first.y, 2)
    );

    if (lineLength < 10) return { confidence: 0, params: {} };

    let maxDeviation = 0;
    for (const point of this.points) {
      const deviation = this.pointToLineDistance(point, first, last);
      maxDeviation = Math.max(maxDeviation, deviation);
    }

    const confidence = Math.max(0, 1 - maxDeviation / (lineLength * 0.1));

    return {
      confidence,
      params: {
        x1: first.x,
        y1: first.y,
        x2: last.x,
        y2: last.y,
      },
    };
  }

  private static calculateCentroid(points: TouchPoint[]): { x: number; y: number } {
    const sumX = points.reduce((sum, p) => sum + p.x, 0);
    const sumY = points.reduce((sum, p) => sum + p.y, 0);
    return { x: sumX / points.length, y: sumY / points.length };
  }

  private static calculateAngles(): number[] {
    const angles: number[] = [];
    for (let i = 1; i < this.points.length - 1; i++) {
      const p1 = this.points[i - 1];
      const p2 = this.points[i];
      const p3 = this.points[i + 1];

      const angle1 = Math.atan2(p2.y - p1.y, p2.x - p1.x);
      const angle2 = Math.atan2(p3.y - p2.y, p3.x - p2.x);

      let angleDiff = Math.abs(((angle2 - angle1) * 180) / Math.PI);
      if (angleDiff > 180) angleDiff = 360 - angleDiff;

      angles.push(angleDiff);
    }
    return angles;
  }

  private static pointToLineDistance(
    point: TouchPoint,
    lineStart: TouchPoint,
    lineEnd: TouchPoint
  ): number {
    const A = lineEnd.y - lineStart.y;
    const B = lineStart.x - lineEnd.x;
    const C = lineEnd.x * lineStart.y - lineStart.x * lineEnd.y;

    return Math.abs(A * point.x + B * point.y + C) / Math.sqrt(A * A + B * B);
  }

  static clear() {
    this.points = [];
    this.startTime = 0;
  }
}

// ============================================================================
// LAZO DE SELECCIÓN (PUNTO EN POLÍGONO)
// ============================================================================

export class LassoSelector {
  /**
   * Algoritmo de ray casting para determinar si un punto está dentro de un polígono
   */
  static pointInPolygon(
    point: { x: number; y: number },
    polygon: { x: number; y: number }[]
  ): boolean {
    if (polygon.length < 3) return false;

    let inside = false;
    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
      const xi = polygon[i].x;
      const yi = polygon[i].y;
      const xj = polygon[j].x;
      const yj = polygon[j].y;

      const intersect =
        yi > point.y !== yj > point.y &&
        point.x < ((xj - xi) * (point.y - yi)) / (yj - yi) + xi;

      if (intersect) inside = !inside;
    }

    return inside;
  }

  /**
   * Verifica si un nodo está dentro del lazo
   */
  static nodeInLasso(node: Node, lassoPoints: { x: number; y: number }[]): boolean {
    return this.pointInPolygon({ x: node.x, y: node.y }, lassoPoints);
  }

  /**
   * Verifica si el lazo está cerrado (punto final cerca del inicial)
   */
  static isLassoClosed(points: { x: number; y: number }[]): boolean {
    if (points.length < 3) return false;

    const first = points[0];
    const last = points[points.length - 1];
    const distance = Math.sqrt(
      Math.pow(last.x - first.x, 2) + Math.pow(last.y - first.y, 2)
    );

    return distance <= CONFIG.LASSO_CLOSE_THRESHOLD;
  }

  /**
   * Calcula el bounding box del lazo
   */
  static getBounds(points: { x: number; y: number }[]): {
    x: number;
    y: number;
    width: number;
    height: number;
  } {
    const xs = points.map((p) => p.x);
    const ys = points.map((p) => p.y);

    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);

    return {
      x: minX,
      y: minY,
      width: maxX - minX,
      height: maxY - minY,
    };
  }
}

// ============================================================================
// BORRADOR (DETECCIÓN DE COLISIONES)
// ============================================================================

export class EraserEngine {
  /**
   * Verifica si el borrador intersecta con un trazo de tinta
   */
  static intersectsStroke(
    eraserPath: SkPath,
    stroke: InkStroke,
    eraserWidth: number = CONFIG.ERASER_WIDTH
  ): boolean {
    // Crear path del borrador con grosor
    const eraserPaint = Skia.Paint();
    eraserPaint.setStrokeWidth(eraserWidth);
    eraserPaint.setStyle(1); // Stroke

    // Usar operación de intersección de Skia
    const intersection = Skia.Path.MakeFromOp(
      eraserPath,
      stroke.path,
      PathOp.Intersect
    );

    if (!intersection) return false;

    // Verificar si hay intersección real
    return !intersection.isEmpty();
  }

  /**
   * Borra parte de un trazo dividiéndolo en segmentos
   */
  static eraseFromStroke(
    stroke: InkStroke,
    eraserPath: SkPath,
    eraserWidth: number = CONFIG.ERASER_WIDTH
  ): InkStroke[] {
    // Esta es una implementación simplificada
    // En producción, se necesitaría subdividir el path en puntos
    // y reconstruir los segmentos no borrados

    const remainingStrokes: InkStroke[] = [];

    // Verificar si el trazo completo debe borrarse
    if (this.intersectsStroke(eraserPath, stroke, eraserWidth)) {
      // Por ahora, si hay intersección, borramos todo el trazo
      // Implementación completa requeriría subdivisión del path
      return remainingStrokes;
    }

    return [stroke];
  }

  /**
   * Crea un path de máscara para borrado por píxeles
   */
  static createEraseMask(
    eraserPoints: { x: number; y: number }[],
    width: number
  ): SkPath {
    const path = Skia.Path.Make();
    if (eraserPoints.length === 0) return path;

    path.moveTo(eraserPoints[0].x, eraserPoints[0].y);
    for (let i = 1; i < eraserPoints.length; i++) {
      path.lineTo(eraserPoints[i].x, eraserPoints[i].y);
    }

    return path;
  }
}

// ============================================================================
// GENERACIÓN DE PATHS SKIA
// ============================================================================

export class PathGenerator {
  /**
   * Genera un SkPath desde puntos táctiles suavizados
   */
  static generatePathFromPoints(
    points: TouchPoint[],
    settings: BrushSettings
  ): SkPath {
    if (points.length === 0) return Skia.Path.Make();

    // Suavizar puntos
    const smoothed =
      settings.smoothing > 0
        ? StrokeSmoother.catmullRom(points, settings.smoothing)
        : points;

    const path = Skia.Path.Make();
    path.moveTo(smoothed[0].x, smoothed[0].y);

    // Generar path con curvas cuadráticas para suavizado
    for (let i = 1; i < smoothed.length - 1; i++) {
      const p0 = smoothed[i - 1];
      const p1 = smoothed[i];
      const p2 = smoothed[i + 1];

      // Punto de control para curva cuadrática
      const cpX = (p0.x + p1.x) / 2;
      const cpY = (p0.y + p1.y) / 2;

      path.quadTo(cpX, cpY, p1.x, p1.y);
    }

    // Último punto
    if (smoothed.length > 1) {
      const last = smoothed[smoothed.length - 1];
      path.lineTo(last.x, last.y);
    }

    return path;
  }

  /**
   * Genera path para forma reconocida
   */
  static generateShapePath(
    shape: ShapeType,
    params: Record<string, number>
  ): SkPath {
    const path = Skia.Path.Make();

    switch (shape) {
      case 'circle':
        path.addCircle(params.cx, params.cy, params.radius);
        break;

      case 'rectangle':
        path.addRect(
          Skia.XYWHRect(params.x, params.y, params.width, params.height)
        );
        break;

      case 'line':
        path.moveTo(params.x1, params.y1);
        path.lineTo(params.x2, params.y2);
        break;

      default:
        break;
    }

    return path;
  }

  /**
   * Genera path SVG string para serialización
   */
  static generateSVGPath(points: TouchPoint[]): string {
    if (points.length === 0) return '';

    let d = `M ${points[0].x.toFixed(2)} ${points[0].y.toFixed(2)}`;

    for (let i = 1; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      const cpX = (p1.x + p2.x) / 2;
      const cpY = (p1.y + p2.y) / 2;
      d += ` Q ${p1.x.toFixed(2)} ${p1.y.toFixed(2)} ${cpX.toFixed(2)} ${cpY.toFixed(2)}`;
    }

    if (points.length > 1) {
      const last = points[points.length - 1];
      d += ` L ${last.x.toFixed(2)} ${last.y.toFixed(2)}`;
    }

    return d;
  }
}

// ============================================================================
// PROCESADOR PRINCIPAL DE HERRAMIENTAS
// ============================================================================

export class ToolProcessor {
  private lazyBrush: LazyBrush;
  private currentPoints: TouchPoint[] = [];
  private isDrawing: boolean = false;

  constructor(lazyRadius: number = 5) {
    this.lazyBrush = new LazyBrush(lazyRadius);
  }

  /**
   * Procesa un evento táctil según la herramienta activa
   */
  processTouch(
    event: { x: number; y: number; type: 'start' | 'move' | 'end'; pressure?: number; timestamp: number },
    tool: ToolType,
    settings: BrushSettings,
    ruler?: RulerSettings
  ): ToolProcessorResult {
    const point: TouchPoint = {
      x: event.x,
      y: event.y,
      timestamp: event.timestamp,
      pressure: event.pressure || 0.5,
      velocity: 0,
    };

    switch (event.type) {
      case 'start':
        return this.handleTouchStart(point, tool, settings, ruler);
      case 'move':
        return this.handleTouchMove(point, tool, settings, ruler);
      case 'end':
        return this.handleTouchEnd(point, tool, settings);
      default:
        return { shouldCommit: false };
    }
  }

  private handleTouchStart(
    point: TouchPoint,
    tool: ToolType,
    settings: BrushSettings,
    ruler?: RulerSettings
  ): ToolProcessorResult {
    this.isDrawing = true;
    this.currentPoints = [point];
    this.lazyBrush.reset(point.x, point.y);

    if (tool === 'shape') {
      ShapeRecognizer.startRecognition();
      ShapeRecognizer.addPoint(point);
    }

    // Para regla, proyectar punto inicial si está cerca
    if (tool === 'pen' && ruler?.visible && RulerProjection.shouldSnap(point, ruler)) {
      const projected = RulerProjection.projectPoint(point, ruler);
      point.x = projected.x;
      point.y = projected.y;
    }

    return { shouldCommit: false, cursor: 'crosshair' };
  }

  private handleTouchMove(
    point: TouchPoint,
    tool: ToolType,
    settings: BrushSettings,
    ruler?: RulerSettings
  ): ToolProcessorResult {
    if (!this.isDrawing) return { shouldCommit: false };

    // Calcular velocidad
    if (this.currentPoints.length > 0) {
      const lastPoint = this.currentPoints[this.currentPoints.length - 1];
      point.velocity = VariableWidthCalculator.calculateVelocity(lastPoint, point);
    }

    this.currentPoints.push(point);

    // Aplicar lazy brush para herramientas de dibujo
    if (tool === 'pen' || tool === 'highlighter' || tool === 'tape') {
      const lazyPos = this.lazyBrush.update(point.x, point.y);
      if (!lazyPos.hasMoved) return { shouldCommit: false };

      // Actualizar último punto con posición lazy
      this.currentPoints[this.currentPoints.length - 1].x = lazyPos.x;
      this.currentPoints[this.currentPoints.length - 1].y = lazyPos.y;
    }

    // Proyección de regla
    if (tool === 'pen' && ruler?.visible && RulerProjection.shouldSnap(point, ruler)) {
      const projected = RulerProjection.projectPoint(point, ruler);
      this.currentPoints[this.currentPoints.length - 1].x = projected.x;
      this.currentPoints[this.currentPoints.length - 1].y = projected.y;
    }

    // Agregar punto al reconocedor de formas
    if (tool === 'shape') {
      ShapeRecognizer.addPoint(point);
    }

    // Generar path preview
    const path = PathGenerator.generatePathFromPoints(this.currentPoints, settings);

    return { path, shouldCommit: false, cursor: 'crosshair' };
  }

  private handleTouchEnd(
    point: TouchPoint,
    tool: ToolType,
    settings: BrushSettings
  ): ToolProcessorResult {
    if (!this.isDrawing) return { shouldCommit: false };

    this.isDrawing = false;

    // Reconocimiento de formas
    if (tool === 'shape') {
      const recognition = ShapeRecognizer.recognize();
      ShapeRecognizer.clear();

      if (recognition) {
        const shapePath = PathGenerator.generateShapePath(
          recognition.shape,
          recognition.params
        );
        return { path: shapePath, shouldCommit: true };
      }
    }

    // Generar path final
    const finalPath = PathGenerator.generatePathFromPoints(this.currentPoints, settings);

    this.currentPoints = [];

    return { path: finalPath, shouldCommit: true, cursor: 'default' };
  }

  /**
   * Actualiza el radio del lazy brush
   */
  setLazyRadius(radius: number) {
    this.lazyBrush.setRadius(radius);
  }

  /**
   * Cancela el dibujo actual
   */
  cancel() {
    this.isDrawing = false;
    this.currentPoints = [];
    ShapeRecognizer.clear();
  }

  /**
   * Verifica si está dibujando
   */
  isActive(): boolean {
    return this.isDrawing;
  }
}

export default ToolProcessor;
