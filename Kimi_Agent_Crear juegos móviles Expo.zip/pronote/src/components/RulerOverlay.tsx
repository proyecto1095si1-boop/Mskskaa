/**
 * ProNote - RulerOverlay
 * Componente de regla virtual con proyección vectorial
 */

import React, { memo, useMemo } from 'react';
import {
  Group,
  Rect,
  Line,
  Circle,
  Skia,
} from '@shopify/react-native-skia';

import { RulerSettings } from '@types/index';
import { RulerProjection } from '@utils/ToolProcessor';

// ============================================================================
// PROPS
// ============================================================================

interface RulerOverlayProps {
  settings: RulerSettings;
  zoom: number;
  panX: number;
  panY: number;
}

// ============================================================================
// COMPONENTE
// ============================================================================

export const RulerOverlay: React.FC<RulerOverlayProps> = memo(({
  settings,
  zoom,
  panX,
  panY,
}) => {
  const { start, end } = useMemo(() => {
    return RulerProjection.getEndpoints(settings);
  }, [settings]);

  // Transformar coordenadas según zoom y pan
  const transformX = (x: number) => x * zoom + panX;
  const transformY = (y: number) => y * zoom + panY;

  const transformedStart = {
    x: transformX(start.x),
    y: transformY(start.y),
  };

  const transformedEnd = {
    x: transformX(end.x),
    y: transformY(end.y),
  };

  // Longitud visual de la regla
  const visualLength = settings.length * zoom;

  // Marcas de medición
  const tickMarks = useMemo(() => {
    const marks: { x: number; y: number; angle: number; height: number }[] = [];
    const numTicks = Math.floor(settings.length / 10); // Cada 10 unidades
    const angleRad = (settings.angle * Math.PI) / 180;

    for (let i = 0; i <= numTicks; i++) {
      const distance = i * 10;
      const x = start.x + Math.cos(angleRad) * distance;
      const y = start.y + Math.sin(angleRad) * distance;
      
      // Altura de la marca (mayor cada 50 unidades)
      const height = i % 5 === 0 ? 15 : 8;

      marks.push({
        x: transformX(x),
        y: transformY(y),
        angle: settings.angle + 90,
        height,
      });
    }

    return marks;
  }, [settings, start, zoom, panX, panY]);

  if (!settings.visible) return null;

  return (
    <Group>
      {/* Línea principal de la regla */}
      <Line
        p1={transformedStart}
        p2={transformedEnd}
        color="rgba(158, 158, 158, 0.8)"
        strokeWidth={4 * zoom}
      />

      {/* Borde de la regla */}
      <Line
        p1={transformedStart}
        p2={transformedEnd}
        color="rgba(97, 97, 97, 0.9)"
        strokeWidth={6 * zoom}
      />

      {/* Marcas de medición */}
      {tickMarks.map((mark, index) => {
        const angleRad = (mark.angle * Math.PI) / 180;
        const endX = mark.x + Math.cos(angleRad) * mark.height * zoom;
        const endY = mark.y + Math.sin(angleRad) * mark.height * zoom;

        return (
          <Line
            key={`tick-${index}`}
            p1={{ x: mark.x, y: mark.y }}
            p2={{ x: endX, y: endY }}
            color="rgba(66, 66, 66, 0.9)"
            strokeWidth={index % 5 === 0 ? 2 * zoom : 1 * zoom}
          />
        );
      })}

      {/* Indicador de ángulo */}
      <Circle
        cx={transformedStart.x}
        cy={transformedStart.y}
        r={8 * zoom}
        color="rgba(33, 150, 243, 0.5)"
      />

      {/* Handle de rotación */}
      <Circle
        cx={transformedEnd.x}
        cy={transformedEnd.y}
        r={6 * zoom}
        color="rgba(33, 150, 243, 0.7)"
      />

      {/* Indicador de distancia de snap */}
      <Circle
        cx={(transformedStart.x + transformedEnd.x) / 2}
        cy={(transformedStart.y + transformedEnd.y) / 2}
        r={settings.snapDistance * zoom}
        color="rgba(33, 150, 243, 0.1)"
        style="stroke"
        strokeWidth={1}
      />

      {/* Texto de ángulo */}
      {/* Nota: En Skia nativo usaríamos Skia.Font, aquí simplificamos */}
      <Rect
        x={transformedStart.x - 20}
        y={transformedStart.y - 30}
        width={40}
        height={20}
        color="rgba(0, 0, 0, 0.7)"
      />
    </Group>
  );
});

export default RulerOverlay;
