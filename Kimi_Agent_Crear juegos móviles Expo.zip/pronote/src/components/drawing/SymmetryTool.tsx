/**
 * ProNote - SymmetryTool
 * Herramienta de simetría para dibujo mandala/espejo
 */

import React, { useCallback, useMemo } from 'react';
import { View, StyleSheet } from 'react-native';
import {
  Canvas,
  Group,
  Path,
  Circle,
  Line,
  vec,
  Skia,
} from '@shopify/react-native-skia';

export interface SymmetryConfig {
  enabled: boolean;
  type: 'mirror' | 'radial' | 'kaleidoscope';
  axes: number;
  centerX: number;
  centerY: number;
  showGuides: boolean;
}

interface SymmetryToolProps {
  width: number;
  height: number;
  config: SymmetryConfig;
  children?: React.ReactNode;
}

export const SymmetryTool: React.FC<SymmetryToolProps> = ({
  width,
  height,
  config,
  children,
}) => {
  const { enabled, type, axes, centerX, centerY, showGuides } = config;

  /**
   * Genera las líneas guía de simetría
   */
  const guideLines = useMemo(() => {
    if (!enabled || !showGuides) return [];

    const lines: Array<{ x1: number; y1: number; x2: number; y2: number }> = [];

    if (type === 'mirror') {
      // Línea vertical de espejo
      lines.push({
        x1: centerX,
        y1: 0,
        x2: centerX,
        y2: height,
      });
    } else if (type === 'radial' || type === 'kaleidoscope') {
      // Líneas radiales
      const angleStep = (2 * Math.PI) / axes;
      const maxRadius = Math.sqrt(width * width + height * height);

      for (let i = 0; i < axes; i++) {
        const angle = i * angleStep;
        lines.push({
          x1: centerX,
          y1: centerY,
          x2: centerX + Math.cos(angle) * maxRadius,
          y2: centerY + Math.sin(angle) * maxRadius,
        });
      }
    }

    return lines;
  }, [enabled, type, axes, centerX, centerY, showGuides, width, height]);

  /**
   * Aplica simetría a un punto
   */
  const applySymmetry = useCallback((
    point: { x: number; y: number },
    axisIndex: number
  ): { x: number; y: number } => {
    if (!enabled) return point;

    if (type === 'mirror') {
      // Reflejar en eje vertical
      return {
        x: 2 * centerX - point.x,
        y: point.y,
      };
    } else if (type === 'radial' || type === 'kaleidoscope') {
      // Rotar alrededor del centro
      const angleStep = (2 * Math.PI) / axes;
      const angle = axisIndex * angleStep;

      const dx = point.x - centerX;
      const dy = point.y - centerY;

      const cos = Math.cos(angle);
      const sin = Math.sin(angle);

      return {
        x: centerX + dx * cos - dy * sin,
        y: centerY + dx * sin + dy * cos,
      };
    }

    return point;
  }, [enabled, type, axes, centerX, centerY]);

  /**
   * Genera paths simétricos a partir de un path original
   */
  const generateSymmetricPaths = useCallback((originalPath: string): string[] => {
    if (!enabled) return [originalPath];

    const paths: string[] = [originalPath];

    if (type === 'mirror') {
      // Generar versión espejo
      // Nota: En implementación real, parsearíamos el SVG path
      // y aplicaríamos la transformación a cada comando
      paths.push(originalPath); // Placeholder
    } else if (type === 'radial' || type === 'kaleidoscope') {
      // Generar versiones rotadas
      for (let i = 1; i < axes; i++) {
        paths.push(originalPath); // Placeholder
      }
    }

    return paths;
  }, [enabled, type, axes]);

  if (!enabled) {
    return <>{children}</>;
  }

  return (
    <View style={styles.container}>
      <Canvas style={{ width, height }}>
        {/* Guías de simetría */}
        {showGuides && (
          <Group>
            {/* Círculo central */}
            <Circle
              cx={centerX}
              cy={centerY}
              r={5}
              color="rgba(100, 100, 100, 0.5)"
            />

            {/* Líneas de guía */}
            {guideLines.map((line, index) => (
              <Line
                key={`guide-${index}`}
                p1={vec(line.x1, line.y1)}
                p2={vec(line.x2, line.y2)}
                color="rgba(200, 200, 200, 0.5)"
                strokeWidth={1}
              />
            ))}

            {/* Círculo de referencia para radial */}
            {(type === 'radial' || type === 'kaleidoscope') && (
              <Circle
                cx={centerX}
                cy={centerY}
                r={Math.min(width, height) / 4}
                color="rgba(200, 200, 200, 0.3)"
                style="stroke"
                strokeWidth={1}
              />
            )}
          </Group>
        )}

        {/* Contenido */}
        {children}
      </Canvas>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default SymmetryTool;
