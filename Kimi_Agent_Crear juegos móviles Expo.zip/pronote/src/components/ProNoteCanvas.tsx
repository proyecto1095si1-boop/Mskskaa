/**
 * ProNote - ProNoteCanvas
 * Componente principal de lienzo usando React Native Skia
 * Renderiza nodos, maneja gestos táctiles y coordina herramientas
 */

import React, { useRef, useCallback, useEffect, useState } from 'react';
import { View, StyleSheet, Dimensions, GestureResponderEvent } from 'react-native';
import {
  Canvas,
  Path,
  Circle,
  Rect,
  Group,
  useTouchHandler,
  useValue,
  useComputedValue,
  Skia,
  Paint,
  StrokeCap,
  StrokeJoin,
  BlendMode as SkiaBlendMode,
  useCanvasRef,
  ImageSVG,
  SkPath,
} from '@shopify/react-native-skia';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  runOnJS,
} from 'react-native-reanimated';
import { v4 as uuidv4 } from 'uuid';

import { useDrawingStore } from '@store/useDrawingStore';
import { ToolProcessor, PathGenerator } from '@utils/ToolProcessor';
import {
  TouchPoint,
  InkNode,
  TextNode,
  ImageNode,
  TableNode,
  Node,
  ToolType,
  BrushSettings,
} from '@types/index';
import { LayerRenderer } from './LayerRenderer';
import { RulerOverlay } from './RulerOverlay';
import { GridBackground } from './GridBackground';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

// ============================================================================
// CONSTANTES
// ============================================================================

const CANVAS_WIDTH = 2000;
const CANVAS_HEIGHT = 3000;

const TOOL_COLORS: Record<ToolType, string> = {
  pen: '#000000',
  highlighter: '#FFEB3B',
  tape: '#FF9800',
  eraser: '#FFFFFF',
  lasso: '#2196F3',
  ruler: '#9E9E9E',
  shape: '#4CAF50',
  laser: '#F44336',
  hand: '#000000',
};

// ============================================================================
// COMPONENTE PRINCIPAL
// ============================================================================

interface ProNoteCanvasProps {
  width?: number;
  height?: number;
}

export const ProNoteCanvas: React.FC<ProNoteCanvasProps> = ({
  width = SCREEN_WIDTH,
  height = SCREEN_HEIGHT,
}) => {
  // ========================================================================
  // REFS Y ESTADO
  // ========================================================================
  
  const canvasRef = useCanvasRef();
  const toolProcessorRef = useRef<ToolProcessor | null>(null);
  const currentPathRef = useRef<SkPath | null>(null);
  
  // Valores reactivos de Skia (UI Thread)
  const currentPath = useValue(Skia.Path.Make());
  const isDrawing = useValue(false);
  const touchPosition = useValue({ x: 0, y: 0 });
  
  // Estado de React
  const [localNodes, setLocalNodes] = useState<Node[]>([]);
  
  // ========================================================================
  // STORE
  // ========================================================================
  
  const {
    // Estado
    activeTool,
    brushSettings,
    rulerSettings,
    zoom,
    panX,
    panY,
    showGrid,
    selectedNodeIds,
    
    // Acciones
    addNode,
    updateNode,
    deleteNode,
    selectNode,
    deselectAll,
    setPan,
    setZoom,
    getCurrentPage,
    getSelectedNodes,
  } = useDrawingStore();

  // ========================================================================
  // INICIALIZACIÓN
  // ========================================================================
  
  useEffect(() => {
    toolProcessorRef.current = new ToolProcessor(brushSettings.lazyRadius);
    
    // Cargar nodos de la página actual
    const page = getCurrentPage();
    if (page) {
      setLocalNodes(page.nodes);
    }
  }, []);

  useEffect(() => {
    // Actualizar nodos cuando cambia la página
    const page = getCurrentPage();
    if (page) {
      setLocalNodes(page.nodes);
    }
  }, [getCurrentPage()?.id]);

  useEffect(() => {
    if (toolProcessorRef.current) {
      toolProcessorRef.current.setLazyRadius(brushSettings.lazyRadius);
    }
  }, [brushSettings.lazyRadius]);

  // ========================================================================
  // GESTOS DE PINCH/ZOOM
  // ========================================================================
  
  const scale = useSharedValue(1);
  const savedScale = useSharedValue(1);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const savedTranslateX = useSharedValue(0);
  const savedTranslateY = useSharedValue(0);

  const pinchGesture = Gesture.Pinch()
    .onUpdate((e) => {
      const newScale = savedScale.value * e.scale;
      scale.value = Math.max(0.1, Math.min(5, newScale));
    })
    .onEnd(() => {
      savedScale.value = scale.value;
      runOnJS(setZoom)(scale.value);
    });

  const panGesture = Gesture.Pan()
    .enabled(activeTool === 'hand')
    .onUpdate((e) => {
      translateX.value = savedTranslateX.value + e.translationX;
      translateY.value = savedTranslateY.value + e.translationY;
    })
    .onEnd(() => {
      savedTranslateX.value = translateX.value;
      savedTranslateY.value = translateY.value;
      runOnJS(setPan)(translateX.value, translateY.value);
    });

  const composedGesture = Gesture.Simultaneous(pinchGesture, panGesture);

  // ========================================================================
  // MANEJO DE TOUCH PARA DIBUJO
  // ========================================================================
  
  const handleTouchStart = useCallback((x: number, y: number, pressure: number = 0.5) => {
    if (activeTool === 'hand') return;
    
    isDrawing.current = true;
    
    // Ajustar coordenadas según zoom y pan
    const adjustedX = (x - panX) / zoom;
    const adjustedY = (y - panY) / zoom;
    
    touchPosition.current = { x: adjustedX, y: adjustedY };
    
    const result = toolProcessorRef.current?.processTouch(
      {
        x: adjustedX,
        y: adjustedY,
        type: 'start',
        pressure,
        timestamp: Date.now(),
      },
      activeTool,
      brushSettings,
      rulerSettings
    );

    if (result?.path) {
      currentPath.current = result.path;
    }
  }, [activeTool, brushSettings, rulerSettings, zoom, panX, panY]);

  const handleTouchMove = useCallback((x: number, y: number, pressure: number = 0.5) => {
    if (!isDrawing.current || activeTool === 'hand') return;
    
    const adjustedX = (x - panX) / zoom;
    const adjustedY = (y - panY) / zoom;
    
    touchPosition.current = { x: adjustedX, y: adjustedY };
    
    const result = toolProcessorRef.current?.processTouch(
      {
        x: adjustedX,
        y: adjustedY,
        type: 'move',
        pressure,
        timestamp: Date.now(),
      },
      activeTool,
      brushSettings,
      rulerSettings
    );

    if (result?.path) {
      currentPath.current = result.path;
    }
  }, [activeTool, brushSettings, rulerSettings, zoom, panX, panY]);

  const handleTouchEnd = useCallback(() => {
    if (!isDrawing.current) return;
    
    isDrawing.current = false;
    
    const result = toolProcessorRef.current?.processTouch(
      {
        x: touchPosition.current.x,
        y: touchPosition.current.y,
        type: 'end',
        timestamp: Date.now(),
      },
      activeTool,
      brushSettings
    );

    if (result?.shouldCommit && currentPath.current) {
      // Crear nuevo nodo de tinta
      const newNode: InkNode = {
        id: uuidv4(),
        type: 'ink',
        x: 0,
        y: 0,
        rotation: 0,
        scale: 1,
        zIndex: 0,
        locked: false,
        visible: true,
        opacity: brushSettings.opacity,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
        strokes: [
          {
            path: currentPath.current,
            pathData: currentPath.current.toSVGString(),
            points: [], // Simplificado - en producción guardar puntos
            color: brushSettings.color,
            strokeWidth: brushSettings.strokeWidth,
            toolType: activeTool === 'highlighter' ? 'highlighter' : 'pen',
            blendMode: brushSettings.blendMode,
            opacity: brushSettings.opacity,
            bounds: currentPath.current.getBounds(),
          },
        ],
        currentStroke: null,
        brushSettings: { ...brushSettings },
      };

      addNode(newNode);
      
      // Limpiar path actual
      currentPath.current = Skia.Path.Make();
    }
  }, [activeTool, brushSettings, addNode]);

  // ========================================================================
  // HANDLER DE TOUCH SKIA
  // ========================================================================
  
  const touchHandler = useTouchHandler({
    onStart: ({ x, y }) => {
      handleTouchStart(x, y);
    },
    onActive: ({ x, y }) => {
      handleTouchMove(x, y);
    },
    onEnd: () => {
      handleTouchEnd();
    },
  });

  // ========================================================================
  // PAINTS PARA DIFERENTES HERRAMIENTAS
  // ========================================================================
  
  const getPaintForTool = useCallback((tool: ToolType): Paint => {
    const paint = Skia.Paint();
    
    switch (tool) {
      case 'pen':
        paint.setColor(Skia.Color(brushSettings.color));
        paint.setStrokeWidth(brushSettings.strokeWidth);
        paint.setStyle(0); // Fill (para paths con stroke)
        paint.setStrokeCap(StrokeCap.Round);
        paint.setStrokeJoin(StrokeJoin.Round);
        paint.setAntiAlias(true);
        break;
        
      case 'highlighter':
        paint.setColor(Skia.Color(brushSettings.color));
        paint.setStrokeWidth(brushSettings.strokeWidth * 3);
        paint.setStyle(0);
        paint.setStrokeCap(StrokeCap.Square);
        paint.setBlendMode(SkiaBlendMode.Multiply);
        paint.setAlphaf(brushSettings.opacity);
        break;
        
      case 'laser':
        paint.setColor(Skia.Color('#FF0000'));
        paint.setStrokeWidth(brushSettings.strokeWidth);
        paint.setStyle(0);
        paint.setStrokeCap(StrokeCap.Round);
        paint.setAlphaf(0.8);
        break;
        
      case 'eraser':
        paint.setBlendMode(SkiaBlendMode.Clear);
        paint.setStrokeWidth(brushSettings.strokeWidth * 5);
        paint.setStyle(0);
        break;
        
      default:
        paint.setColor(Skia.Color('#000000'));
        paint.setStrokeWidth(2);
        paint.setStyle(0);
    }
    
    return paint;
  }, [brushSettings]);

  // ========================================================================
  // RENDERIZADO DE NODOS
  // ========================================================================
  
  const renderNode = useCallback((node: Node) => {
    const isSelected = selectedNodeIds.includes(node.id);
    
    switch (node.type) {
      case 'ink':
        return (
          <Group
            key={node.id}
            transform={[
              { translateX: node.x },
              { translateY: node.y },
              { rotate: (node.rotation * Math.PI) / 180 },
              { scale: node.scale },
            ]}
            opacity={node.visible ? node.opacity : 0}
          >
            {node.strokes.map((stroke, index) => (
              <Path
                key={`${node.id}-stroke-${index}`}
                path={stroke.path}
                color={stroke.color}
                style="stroke"
                strokeWidth={stroke.strokeWidth}
                strokeCap="round"
                strokeJoin="round"
                blendMode={stroke.blendMode === 'multiply' ? 'multiply' : 'srcOver'}
                opacity={stroke.opacity}
              />
            ))}
            {isSelected && (
              <Rect
                x={-5}
                y={-5}
                width={100}
                height={100}
                color="#2196F3"
                style="stroke"
                strokeWidth={2}
              />
            )}
          </Group>
        );
        
      case 'text':
        const textNode = node as TextNode;
        return (
          <Group
            key={node.id}
            transform={[
              { translateX: node.x },
              { translateY: node.y },
            ]}
          >
            {textNode.backgroundColor && (
              <Rect
                x={0}
                y={0}
                width={textNode.width}
                height={textNode.height}
                color={textNode.backgroundColor}
              />
            )}
            {/* Texto renderizado como path simplificado */}
            <Rect
              x={0}
              y={0}
              width={textNode.width}
              height={textNode.height}
              color={textNode.color}
              style="stroke"
              strokeWidth={1}
            />
          </Group>
        );
        
      case 'image':
        // Las imágenes se renderizan con componente especializado
        return (
          <LayerRenderer
            key={node.id}
            node={node}
            isSelected={isSelected}
            zoom={zoom}
            onTransform={() => {}}
          />
        );
        
      case 'table':
        return (
          <Group
            key={node.id}
            transform={[
              { translateX: node.x },
              { translateY: node.y },
            ]}
          >
            {/* Renderizado simplificado de tabla */}
            <Rect
              x={0}
              y={0}
              width={200}
              height={150}
              color="#000000"
              style="stroke"
              strokeWidth={1}
            />
          </Group>
        );
        
      default:
        return null;
    }
  }, [selectedNodeIds, zoom]);

  // ========================================================================
  // RENDERIZADO DEL PATH ACTUAL (PREVIEW)
  // ========================================================================
  
  const currentPathPaint = useComputedValue(() => {
    return getPaintForTool(activeTool);
  }, [activeTool, brushSettings]);

  // ========================================================================
  // RENDER PRINCIPAL
  // ========================================================================
  
  return (
    <View style={[styles.container, { width, height }]}>
      <GestureDetector gesture={composedGesture}>
        <Animated.View style={[styles.canvasContainer, { width, height }]}>
          <Canvas
            ref={canvasRef}
            style={[styles.canvas, { width, height }]}
            onTouch={touchHandler}
          >
            {/* Fondo */}
            <Rect
              x={0}
              y={0}
              width={width}
              height={height}
              color="#FFFFFF"
            />
            
            {/* Grid de fondo */}
            {showGrid && (
              <GridBackground
                width={width}
                height={height}
                zoom={zoom}
                panX={panX}
                panY={panY}
              />
            )}
            
            {/* Grupo principal con transformaciones */}
            <Group
              transform={[
                { translateX: panX },
                { translateY: panY },
                { scale: zoom },
              ]}
            >
              {/* Nodos existentes */}
              {localNodes.map(renderNode)}
              
              {/* Path actual (preview mientras dibuja) */}
              {isDrawing.current && currentPath.current && (
                <Path
                  path={currentPath.current}
                  paint={currentPathPaint.current}
                />
              )}
            </Group>
            
            {/* Overlay de regla */}
            {rulerSettings.visible && (
              <RulerOverlay
                settings={rulerSettings}
                zoom={zoom}
                panX={panX}
                panY={panY}
              />
            )}
            
            {/* Indicador de posición */}
            <Circle
              cx={touchPosition.current.x * zoom + panX}
              cy={touchPosition.current.y * zoom + panY}
              r={activeTool === 'eraser' ? brushSettings.strokeWidth * 2.5 : 4}
              color={TOOL_COLORS[activeTool]}
              opacity={isDrawing.current ? 0.5 : 0}
              style="stroke"
              strokeWidth={1}
            />
          </Canvas>
        </Animated.View>
      </GestureDetector>
      
      {/* Información de debug */}
      <View style={styles.debugInfo}>
        <View style={styles.debugText}>
          {`Tool: ${activeTool} | Zoom: ${zoom.toFixed(2)}x | Nodes: ${localNodes.length}`}
        </View>
      </View>
    </View>
  );
};

// ============================================================================
// ESTILOS
// ============================================================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  canvasContainer: {
    flex: 1,
    overflow: 'hidden',
  },
  canvas: {
    flex: 1,
  },
  debugInfo: {
    position: 'absolute',
    bottom: 10,
    left: 10,
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  debugText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontFamily: 'monospace',
  },
});

export default ProNoteCanvas;
