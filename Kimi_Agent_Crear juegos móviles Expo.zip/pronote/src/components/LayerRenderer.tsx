/**
 * ProNote - LayerRenderer
 * Renderizador optimizado para cada tipo de nodo
 * Decide cómo pintar cada tipo de nodo usando primitivas de Skia
 */

import React, { memo, useMemo } from 'react';
import {
  Group,
  Path,
  Rect,
  Circle,
  Image as SkiaImage,
  Text as SkiaText,
  useImage,
  Skia,
  Paint,
  BlendMode as SkiaBlendMode,
} from '@shopify/react-native-skia';

import {
  Node,
  InkNode,
  TextNode,
  ImageNode,
  TableNode,
  StickerNode,
  TransformMatrix,
  isInkNode,
  isTextNode,
  isImageNode,
  isTableNode,
  isStickerNode,
} from '@types/index';

// ============================================================================
// PROPS
// ============================================================================

interface LayerRendererProps {
  node: Node;
  isSelected: boolean;
  zoom: number;
  onTransform: (transform: TransformMatrix) => void;
}

// ============================================================================
// RENDERIZADOR DE INK (TINTA)
// ============================================================================

const InkRenderer: React.FC<{ node: InkNode; isSelected: boolean }> = memo(({
  node,
  isSelected,
}) => {
  const selectionPaint = useMemo(() => {
    const paint = Skia.Paint();
    paint.setColor(Skia.Color('#2196F3'));
    paint.setStyle(1); // Stroke
    paint.setStrokeWidth(2 / node.scale);
    return paint;
  }, [node.scale]);

  if (!node.visible) return null;

  return (
    <Group
      transform={[
        { translateX: node.x },
        { translateY: node.y },
        { rotate: (node.rotation * Math.PI) / 180 },
        { scale: node.scale },
      ]}
      opacity={node.opacity}
    >
      {node.strokes.map((stroke, index) => {
        // Crear paint específico para este stroke
        const paint = Skia.Paint();
        paint.setColor(Skia.Color(stroke.color));
        paint.setStrokeWidth(stroke.strokeWidth);
        paint.setStyle(1); // Stroke
        paint.setStrokeCap(0); // Round
        paint.setStrokeJoin(0); // Round
        paint.setAntiAlias(true);
        
        // Aplicar blend mode
        if (stroke.blendMode === 'multiply') {
          paint.setBlendMode(SkiaBlendMode.Multiply);
        }
        
        paint.setAlphaf(stroke.opacity);

        return (
          <Path
            key={`${node.id}-stroke-${index}`}
            path={stroke.path}
            paint={paint}
          />
        );
      })}

      {/* Indicador de selección */}
      {isSelected && node.strokes.length > 0 && (
        <>
          {(() => {
            // Calcular bounds de todos los strokes
            let minX = Infinity, minY = Infinity;
            let maxX = -Infinity, maxY = -Infinity;
            
            node.strokes.forEach(stroke => {
              const bounds = stroke.path.getBounds();
              minX = Math.min(minX, bounds.x);
              minY = Math.min(minY, bounds.y);
              maxX = Math.max(maxX, bounds.x + bounds.width);
              maxY = Math.max(maxY, bounds.y + bounds.height);
            });

            return (
              <Rect
                x={minX - 5}
                y={minY - 5}
                width={maxX - minX + 10}
                height={maxY - minY + 10}
                paint={selectionPaint}
              />
            );
          })()}
          
          {/* Handles de transformación */}
          <Circle cx={-10} cy={-10} r={5} color="#2196F3" />
          <Circle cx={10} cy={-10} r={5} color="#2196F3" />
          <Circle cx={-10} cy={10} r={5} color="#2196F3" />
          <Circle cx={10} cy={10} r={5} color="#2196F3" />
        </>
      )}
    </Group>
  );
});

// ============================================================================
// RENDERIZADOR DE TEXTO
// ============================================================================

const TextRenderer: React.FC<{ node: TextNode; isSelected: boolean }> = memo(({
  node,
  isSelected,
}) => {
  if (!node.visible) return null;

  // En una implementación completa, usaríamos Skia.Font para renderizar texto
  // Por ahora, usamos un rectángulo representativo

  return (
    <Group
      transform={[
        { translateX: node.x },
        { translateY: node.y },
        { rotate: (node.rotation * Math.PI) / 180 },
        { scale: node.scale },
      ]}
      opacity={node.opacity}
    >
      {/* Fondo */}
      {node.backgroundColor && (
        <Rect
          x={0}
          y={0}
          width={node.width}
          height={node.height}
          color={node.backgroundColor}
        />
      )}

      {/* Representación del texto como área */}
      <Rect
        x={0}
        y={0}
        width={node.width}
        height={node.height}
        color={node.color}
        style="stroke"
        strokeWidth={1}
      />

      {/* Indicador de modo edición */}
      {node.isEditing && (
        <Rect
          x={-2}
          y={-2}
          width={node.width + 4}
          height={node.height + 4}
          color="#4CAF50"
          style="stroke"
          strokeWidth={2}
        />
      )}

      {/* Selección */}
      {isSelected && (
        <Rect
          x={-4}
          y={-4}
          width={node.width + 8}
          height={node.height + 8}
          color="#2196F3"
          style="stroke"
          strokeWidth={2}
        />
      )}
    </Group>
  );
});

// ============================================================================
// RENDERIZADOR DE IMAGEN
// ============================================================================

const ImageRenderer: React.FC<{ node: ImageNode; isSelected: boolean }> = memo(({
  node,
  isSelected,
}) => {
  const image = useImage(node.uri);

  if (!node.visible || !image) return null;

  const width = node.width || node.originalWidth;
  const height = node.height || node.originalHeight;

  return (
    <Group
      transform={[
        { translateX: node.x },
        { translateY: node.y },
        { rotate: (node.rotation * Math.PI) / 180 },
        { scale: node.scale },
      ]}
      opacity={node.opacity}
    >
      <SkiaImage
        image={image}
        x={0}
        y={0}
        width={width}
        height={height}
        fit="contain"
      />

      {/* Selección */}
      {isSelected && (
        <Rect
          x={-4}
          y={-4}
          width={width + 8}
          height={height + 8}
          color="#2196F3"
          style="stroke"
          strokeWidth={2}
        />
      )}
    </Group>
  );
});

// ============================================================================
// RENDERIZADOR DE TABLA
// ============================================================================

const TableRenderer: React.FC<{ node: TableNode; isSelected: boolean }> = memo(({
  node,
  isSelected,
}) => {
  if (!node.visible) return null;

  const cellWidth = 100;
  const cellHeight = 40;
  const totalWidth = node.cols * cellWidth;
  const totalHeight = node.rows * cellHeight;

  return (
    <Group
      transform={[
        { translateX: node.x },
        { translateY: node.y },
        { rotate: (node.rotation * Math.PI) / 180 },
        { scale: node.scale },
      ]}
      opacity={node.opacity}
    >
      {/* Fondo de tabla */}
      <Rect
        x={0}
        y={0}
        width={totalWidth}
        height={totalHeight}
        color="#FFFFFF"
      />

      {/* Líneas horizontales */}
      {Array.from({ length: node.rows + 1 }).map((_, i) => (
        <Rect
          key={`h-${i}`}
          x={0}
          y={i * cellHeight}
          width={totalWidth}
          height={node.borderWidth}
          color={node.borderColor}
        />
      ))}

      {/* Líneas verticales */}
      {Array.from({ length: node.cols + 1 }).map((_, i) => (
        <Rect
          key={`v-${i}`}
          x={i * cellWidth}
          y={0}
          width={node.borderWidth}
          height={totalHeight}
          color={node.borderColor}
        />
      ))}

      {/* Header row */}
      {node.headerRow && (
        <Rect
          x={0}
          y={0}
          width={totalWidth}
          height={cellHeight}
          color={node.headerBackgroundColor}
        />
      )}

      {/* Selección */}
      {isSelected && (
        <Rect
          x={-4}
          y={-4}
          width={totalWidth + 8}
          height={totalHeight + 8}
          color="#2196F3"
          style="stroke"
          strokeWidth={2}
        />
      )}
    </Group>
  );
});

// ============================================================================
// RENDERIZADOR DE STICKER
// ============================================================================

const StickerRenderer: React.FC<{ node: StickerNode; isSelected: boolean }> = memo(({
  node,
  isSelected,
}) => {
  const image = useImage(node.uri);

  if (!node.visible || !image) return null;

  return (
    <Group
      transform={[
        { translateX: node.x },
        { translateY: node.y },
        { rotate: (node.rotation * Math.PI) / 180 },
        { scale: node.scale },
      ]}
      opacity={node.opacity}
    >
      <SkiaImage
        image={image}
        x={0}
        y={0}
        width={node.width}
        height={node.height}
        fit="contain"
      />

      {/* Selección */}
      {isSelected && (
        <Rect
          x={-4}
          y={-4}
          width={node.width + 8}
          height={node.height + 8}
          color="#2196F3"
          style="stroke"
          strokeWidth={2}
        />
      )}
    </Group>
  );
});

// ============================================================================
// COMPONENTE PRINCIPAL
// ============================================================================

export const LayerRenderer: React.FC<LayerRendererProps> = memo(({
  node,
  isSelected,
  zoom,
  onTransform,
}) => {
  // Seleccionar el renderizador apropiado según el tipo de nodo
  if (isInkNode(node)) {
    return <InkRenderer node={node} isSelected={isSelected} />;
  }

  if (isTextNode(node)) {
    return <TextRenderer node={node} isSelected={isSelected} />;
  }

  if (isImageNode(node)) {
    return <ImageRenderer node={node} isSelected={isSelected} />;
  }

  if (isTableNode(node)) {
    return <TableRenderer node={node} isSelected={isSelected} />;
  }

  if (isStickerNode(node)) {
    return <StickerRenderer node={node} isSelected={isSelected} />;
  }

  // Tipo desconocido
  return null;
});

// ============================================================================
// LISTA DE CAPAS OPTIMIZADA
// ============================================================================

interface LayerListProps {
  nodes: Node[];
  selectedIds: string[];
  zoom: number;
  onNodeTransform: (id: string, transform: TransformMatrix) => void;
}

export const LayerList: React.FC<LayerListProps> = memo(({
  nodes,
  selectedIds,
  zoom,
  onNodeTransform,
}) => {
  // Ordenar nodos por zIndex
  const sortedNodes = useMemo(() => {
    return [...nodes].sort((a, b) => a.zIndex - b.zIndex);
  }, [nodes]);

  return (
    <>
      {sortedNodes.map((node) => (
        <LayerRenderer
          key={node.id}
          node={node}
          isSelected={selectedIds.includes(node.id)}
          zoom={zoom}
          onTransform={(transform) => onNodeTransform(node.id, transform)}
        />
      ))}
    </>
  );
});

export default LayerRenderer;
