/**
 * ProNote - TopBar
 * Barra superior con título, navegación y acciones principales
 */

import React, { memo, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';

import { useDrawingStore } from '@store/useDrawingStore';

// ============================================================================
// PROPS
// ============================================================================

interface TopBarProps {
  onToggleLayerPanel: () => void;
  onToggleColorPicker: () => void;
}

// ============================================================================
// COMPONENTE
// ============================================================================

export const TopBar: React.FC<TopBarProps> = memo(({
  onToggleLayerPanel,
  onToggleColorPicker,
}) => {
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  
  const {
    getCurrentDocument,
    updateDocumentTitle,
    undo,
    redo,
    canUndo,
    canRedo,
    saveToFile,
    addPage,
    getCurrentPage,
    zoomIn,
    zoomOut,
    resetZoom,
    showGrid,
    toggleGrid,
  } = useDrawingStore();

  const doc = getCurrentDocument();
  const page = getCurrentPage();

  const handleTitleSubmit = useCallback((newTitle: string) => {
    if (doc) {
      updateDocumentTitle(doc.id, newTitle);
    }
    setIsEditingTitle(false);
  }, [doc, updateDocumentTitle]);

  const handleSave = useCallback(async () => {
    try {
      const path = await saveToFile();
      Alert.alert('Guardado', `Documento guardado en:\n${path}`);
    } catch (error) {
      Alert.alert('Error', 'No se pudo guardar el documento');
    }
  }, [saveToFile]);

  const handleAddPage = useCallback(() => {
    addPage();
  }, [addPage]);

  return (
    <View style={styles.container}>
      {/* Sección izquierda - Navegación */}
      <View style={styles.leftSection}>
        <TouchableOpacity
          style={[styles.iconButton, !canUndo() && styles.iconButtonDisabled]}
          onPress={undo}
          disabled={!canUndo()}
        >
          <Text style={styles.icon}>↩️</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.iconButton, !canRedo() && styles.iconButtonDisabled]}
          onPress={redo}
          disabled={!canRedo()}
        >
          <Text style={styles.icon}>↪️</Text>
        </TouchableOpacity>

        <View style={styles.divider} />

        <TouchableOpacity
          style={styles.iconButton}
          onPress={zoomOut}
        >
          <Text style={styles.icon}>🔍−</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.iconButton}
          onPress={resetZoom}
        >
          <Text style={styles.zoomText}>100%</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.iconButton}
          onPress={zoomIn}
        >
          <Text style={styles.icon}>🔍+</Text>
        </TouchableOpacity>
      </View>

      {/* Sección central - Título */}
      <View style={styles.centerSection}>
        {isEditingTitle ? (
          <TextInput
            style={styles.titleInput}
            defaultValue={doc?.title || 'Sin título'}
            onSubmitEditing={(e) => handleTitleSubmit(e.nativeEvent.text)}
            onBlur={() => setIsEditingTitle(false)}
            autoFocus
            selectTextOnFocus
          />
        ) : (
          <TouchableOpacity onPress={() => setIsEditingTitle(true)}>
            <Text style={styles.title} numberOfLines={1}>
              {doc?.title || 'Sin título'}
            </Text>
            {page && (
              <Text style={styles.pageInfo}>
                Página {doc?.currentPageIndex! + 1} de {doc?.pages.length}
              </Text>
            )}
          </TouchableOpacity>
        )}
      </View>

      {/* Sección derecha - Acciones */}
      <View style={styles.rightSection}>
        <TouchableOpacity
          style={[styles.iconButton, showGrid && styles.iconButtonActive]}
          onPress={toggleGrid}
        >
          <Text style={styles.icon}>⊞</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.iconButton}
          onPress={onToggleColorPicker}
        >
          <Text style={styles.icon}>🎨</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.iconButton}
          onPress={onToggleLayerPanel}
        >
          <Text style={styles.icon}>☰</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.iconButton}
          onPress={handleAddPage}
        >
          <Text style={styles.icon}>➕</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.iconButton, styles.saveButton]}
          onPress={handleSave}
        >
          <Text style={styles.saveIcon}>💾</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
});

// ============================================================================
// ESTILOS
// ============================================================================

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    paddingHorizontal: 8,
    paddingVertical: 8,
    height: 56,
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  centerSection: {
    flex: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    flex: 1,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 2,
  },
  iconButtonActive: {
    backgroundColor: '#E3F2FD',
  },
  iconButtonDisabled: {
    opacity: 0.3,
  },
  icon: {
    fontSize: 20,
  },
  zoomText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
  },
  divider: {
    width: 1,
    height: 24,
    backgroundColor: '#E0E0E0',
    marginHorizontal: 8,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    textAlign: 'center',
  },
  titleInput: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    textAlign: 'center',
    borderBottomWidth: 2,
    borderBottomColor: '#2196F3',
    paddingHorizontal: 16,
    minWidth: 200,
  },
  pageInfo: {
    fontSize: 11,
    color: '#999',
    textAlign: 'center',
    marginTop: 2,
  },
  saveButton: {
    backgroundColor: '#E3F2FD',
    marginLeft: 8,
  },
  saveIcon: {
    fontSize: 20,
  },
});

export default TopBar;
