/**
 * ProNote - GridBackground
 * Fondo con cuadrícula, líneas o puntos para el lienzo
 */

import React, { memo, useMemo } from 'react';
import {
  Group,
  Rect,
  Line,
  Circle,
} from '@shopify/react-native-skia';

import { Page } from '@types/index';

// ============================================================================
// PROPS
// ============================================================================

interface GridBackgroundProps {
  width: number;
  height: number;
  zoom: number;
  panX: number;
  panY: number;
  type?: Page['background']['type'];
  lineSpacing?: number;
  lineColor?: string;
  backgroundColor?: string;
}

// ============================================================================
// COMPONENTE
// ============================================================================

export const GridBackground: React.FC<GridBackgroundProps> = memo(({
  width,
  height,
  zoom,
  panX,
  panY,
  type = 'blank',
  lineSpacing = 30,
  lineColor = '#E0E0E0',
  backgroundColor = '#FFFFFF',
}) => {
  // Calcular líneas visibles basadas en zoom y pan
  const visibleLines = useMemo(() => {
    const lines: { x1: number; y1: number; x2: number; y2: number }[] = [];
    
    // Espaciado ajustado por zoom
    const spacing = lineSpacing * zoom;
    
    // Calcular rango visible
    const startX = Math.floor(-panX / spacing) * spacing;
    const startY = Math.floor(-panY / spacing) * spacing;
    const endX = startX + width + spacing * 2;
    const endY = startY + height + spacing * 2;

    if (type === 'grid' || type === 'lined') {
      // Líneas horizontales
      for (let y = startY; y < endY; y += spacing) {
        lines.push({
          x1: 0,
          y1: y + panY,
          x2: width,
          y2: y + panY,
        });
      }
    }

    if (type === 'grid') {
      // Líneas verticales
      for (let x = startX; x < endX; x += spacing) {
        lines.push({
          x1: x + panX,
          y1: 0,
          x2: x + panX,
          y2: height,
        });
      }
    }

    return lines;
  }, [width, height, zoom, panX, panY, lineSpacing, type]);

  // Calcular puntos para fondo dotted
  const visibleDots = useMemo(() => {
    if (type !== 'dotted') return [];

    const dots: { x: number; y: number }[] = [];
    const spacing = lineSpacing * zoom;
    
    const startX = Math.floor(-panX / spacing) * spacing;
    const startY = Math.floor(-panY / spacing) * spacing;
    const endX = startX + width + spacing * 2;
    const endY = startY + height + spacing * 2;

    for (let x = startX; x < endX; x += spacing) {
      for (let y = startY; y < endY; y += spacing) {
        dots.push({
          x: x + panX,
          y: y + panY,
        });
      }
    }

    return dots;
  }, [width, height, zoom, panX, panY, lineSpacing, type]);

  if (type === 'blank') {
    return (
      <Rect
        x={0}
        y={0}
        width={width}
        height={height}
        color={backgroundColor}
      />
    );
  }

  return (
    <Group>
      {/* Fondo base */}
      <Rect
        x={0}
        y={0}
        width={width}
        height={height}
        color={backgroundColor}
      />

      {/* Líneas */}
      {visibleLines.map((line, index) => (
        <Line
          key={`line-${index}`}
          p1={{ x: line.x1, y: line.y1 }}
          p2={{ x: line.x2, y: line.y2 }}
          color={lineColor}
          strokeWidth={1}
        />
      ))}

      {/* Puntos */}
      {visibleDots.map((dot, index) => (
        <Circle
          key={`dot-${index}`}
          cx={dot.x}
          cy={dot.y}
          r={1.5}
          color={lineColor}
        />
      ))}

      {/* Margen para papel lined */}
      {type === 'lined' && (
        <Line
          p1={{ x: 80 * zoom + panX, y: 0 }}
          p2={{ x: 80 * zoom + panX, y: height }}
          color="#FF0000"
          strokeWidth={1}
        />
      )}
    </Group>
  );
});

export default GridBackground;
