/**
 * ProNote - LayerPanel
 * Panel lateral para gestión de capas/nodos
 */

import React, { memo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Animated,
} from 'react-native';

import { useDrawingStore } from '@store/useDrawingStore';
import { Node, isInkNode, isTextNode, isImageNode, isTableNode } from '@types/index';

// ============================================================================
// PROPS
// ============================================================================

interface LayerPanelProps {
  onClose: () => void;
}

// ============================================================================
// COMPONENTE DE ITEM DE CAPA
// ============================================================================

interface LayerItemProps {
  node: Node;
  index: number;
  isSelected: boolean;
  onSelect: () => void;
  onToggleVisibility: () => void;
  onToggleLock: () => void;
  onDelete: () => void;
}

const LayerItem: React.FC<LayerItemProps> = memo(({
  node,
  index,
  isSelected,
  onSelect,
  onToggleVisibility,
  onToggleLock,
  onDelete,
}) => {
  const getIcon = () => {
    if (isInkNode(node)) return '✏️';
    if (isTextNode(node)) return '📝';
    if (isImageNode(node)) return '🖼️';
    if (isTableNode(node)) return '⊞';
    return '📄';
  };

  const getLabel = () => {
    if (isInkNode(node)) return 'Trazo';
    if (isTextNode(node)) return 'Texto';
    if (isImageNode(node)) return 'Imagen';
    if (isTableNode(node)) return 'Tabla';
    return 'Capa';
  };

  return (
    <TouchableOpacity
      style={[
        styles.layerItem,
        isSelected && styles.layerItemSelected,
      ]}
      onPress={onSelect}
      activeOpacity={0.7}
    >
      <Text style={styles.layerIcon}>{getIcon()}</Text>
      
      <View style={styles.layerInfo}>
        <Text style={styles.layerName} numberOfLines={1}>
          {getLabel()} {index + 1}
        </Text>
        <Text style={styles.layerDetails}>
          {node.locked ? '🔒' : '🔓'} {node.visible ? '👁' : '🚫'}
        </Text>
      </View>

      <View style={styles.layerActions}>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={onToggleVisibility}
        >
          <Text style={styles.actionIcon}>
            {node.visible ? '👁' : '🚫'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={onToggleLock}
        >
          <Text style={styles.actionIcon}>
            {node.locked ? '🔒' : '🔓'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionButton, styles.deleteButton]}
          onPress={onDelete}
        >
          <Text style={styles.deleteIcon}>🗑</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
});

// ============================================================================
// COMPONENTE PRINCIPAL
// ============================================================================

export const LayerPanel: React.FC<LayerPanelProps> = memo(({ onClose }) => {
  const {
    getCurrentPage,
    selectedNodeIds,
    selectNode,
    deselectAll,
    toggleNodeVisibility,
    lockNode,
    unlockNode,
    deleteNode,
    reorderNodes,
    duplicateNode,
    getHighestZIndex,
  } = useDrawingStore();

  const page = getCurrentPage();
  const nodes = page?.nodes || [];

  // Ordenar por zIndex (de mayor a menor para mostrar arriba las de encima)
  const sortedNodes = [...nodes].sort((a, b) => b.zIndex - a.zIndex);

  const handleSelect = useCallback((nodeId: string) => {
    selectNode(nodeId, true);
  }, [selectNode]);

  const handleToggleVisibility = useCallback((node: Node) => {
    toggleNodeVisibility(node.id);
  }, [toggleNodeVisibility]);

  const handleToggleLock = useCallback((node: Node) => {
    if (node.locked) {
      unlockNode(node.id);
    } else {
      lockNode(node.id);
    }
  }, [lockNode, unlockNode]);

  const handleDelete = useCallback((nodeId: string) => {
    deleteNode(nodeId);
  }, [deleteNode]);

  const handleMoveUp = useCallback((node: Node) => {
    const newZIndex = node.zIndex + 1;
    reorderNodes(node.id, newZIndex);
  }, [reorderNodes]);

  const handleMoveDown = useCallback((node: Node) => {
    const newZIndex = Math.max(0, node.zIndex - 1);
    reorderNodes(node.id, newZIndex);
  }, [reorderNodes]);

  const handleDuplicate = useCallback((nodeId: string) => {
    duplicateNode(nodeId);
  }, [duplicateNode]);

  const handleSelectAll = useCallback(() => {
    nodes.forEach((node) => {
      if (!node.locked) {
        selectNode(node.id, true);
      }
    });
  }, [nodes, selectNode]);

  const handleDeleteSelected = useCallback(() => {
    selectedNodeIds.forEach((id) => deleteNode(id));
  }, [selectedNodeIds, deleteNode]);

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Capas</Text>
        <TouchableOpacity onPress={onClose} style={styles.closeButton}>
          <Text style={styles.closeIcon}>✕</Text>
        </TouchableOpacity>
      </View>

      {/* Acciones globales */}
      <View style={styles.globalActions}>
        <TouchableOpacity
          style={styles.globalButton}
          onPress={handleSelectAll}
        >
          <Text style={styles.globalButtonText}>Seleccionar todo</Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.globalButton, styles.deleteSelectedButton]}
          onPress={handleDeleteSelected}
          disabled={selectedNodeIds.length === 0}
        >
          <Text style={styles.globalButtonText}>
            Eliminar ({selectedNodeIds.length})
          </Text>
        </TouchableOpacity>
      </View>

      {/* Lista de capas */}
      <ScrollView style={styles.layerList}>
        {sortedNodes.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>No hay capas</Text>
            <Text style={styles.emptySubtext}>
              Dibuja algo para crear una capa
            </Text>
          </View>
        ) : (
          sortedNodes.map((node, index) => (
            <LayerItem
              key={node.id}
              node={node}
              index={nodes.length - index - 1}
              isSelected={selectedNodeIds.includes(node.id)}
              onSelect={() => handleSelect(node.id)}
              onToggleVisibility={() => handleToggleVisibility(node)}
              onToggleLock={() => handleToggleLock(node)}
              onDelete={() => handleDelete(node.id)}
            />
          ))
        )}
      </ScrollView>

      {/* Contador */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          {nodes.length} capa{nodes.length !== 1 ? 's' : ''}
        </Text>
        <Text style={styles.footerText}>
          {selectedNodeIds.length} seleccionada{selectedNodeIds.length !== 1 ? 's' : ''}
        </Text>
      </View>
    </View>
  );
});

// ============================================================================
// ESTILOS
// ============================================================================

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    width: 280,
    backgroundColor: '#FFFFFF',
    borderLeftWidth: 1,
    borderLeftColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: { width: -2, height: 0 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
  },
  closeButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F5F5F5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeIcon: {
    fontSize: 16,
    color: '#666',
    fontWeight: '600',
  },
  globalActions: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    gap: 8,
  },
  globalButton: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
    alignItems: 'center',
  },
  deleteSelectedButton: {
    backgroundColor: '#FFEBEE',
  },
  globalButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
  },
  layerList: {
    flex: 1,
  },
  layerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  layerItemSelected: {
    backgroundColor: '#E3F2FD',
  },
  layerIcon: {
    fontSize: 20,
    marginRight: 10,
  },
  layerInfo: {
    flex: 1,
  },
  layerName: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
  },
  layerDetails: {
    fontSize: 11,
    color: '#999',
    marginTop: 2,
  },
  layerActions: {
    flexDirection: 'row',
    gap: 4,
  },
  actionButton: {
    width: 28,
    height: 28,
    borderRadius: 4,
    backgroundColor: '#F5F5F5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionIcon: {
    fontSize: 14,
  },
  deleteButton: {
    backgroundColor: '#FFEBEE',
  },
  deleteIcon: {
    fontSize: 14,
    color: '#F44336',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#999',
  },
  emptySubtext: {
    fontSize: 12,
    color: '#BBB',
    marginTop: 4,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    backgroundColor: '#FAFAFA',
  },
  footerText: {
    fontSize: 12,
    color: '#666',
  },
});

export default LayerPanel;
