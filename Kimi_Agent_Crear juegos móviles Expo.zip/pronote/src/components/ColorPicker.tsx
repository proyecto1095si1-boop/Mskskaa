/**
 * ProNote - ColorPicker
 * Selector de color para herramientas de dibujo
 */

import React, { memo, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
} from 'react-native';

import { useDrawingStore } from '@store/useDrawingStore';

// ============================================================================
// PALETA DE COLORES PREDEFINIDOS
// ============================================================================

const PRESET_COLORS = [
  // Negros y grises
  '#000000', '#333333', '#666666', '#999999', '#CCCCCC', '#FFFFFF',
  
  // Rojos
  '#FF0000', '#FF4444', '#FF8888', '#FFAAAA',
  
  // Naranjas
  '#FF6600', '#FF8844', '#FFAA88',
  
  // Amarillos
  '#FFCC00', '#FFDD44', '#FFEE88', '#FFFFAA',
  
  // Verdes
  '#00FF00', '#44FF44', '#88FF88', '#00CC00', '#008800',
  
  // Cyan/Aguamarina
  '#00FFFF', '#44FFFF', '#88FFFF', '#00CCCC',
  
  // Azules
  '#0000FF', '#4444FF', '#8888FF', '#0000CC', '#000088',
  
  // Púrpuras
  '#8800FF', '#AA44FF', '#CC88FF', '#6600CC',
  
  // Rosas/Magenta
  '#FF00FF', '#FF44FF', '#FF88FF', '#CC00CC',
  
  // Marrones
  '#8B4513', '#A0522D', '#CD853F', '#DEB887',
];

// Colores de resaltador (translúcidos)
const HIGHLIGHTER_COLORS = [
  'rgba(255, 255, 0, 0.4)',
  'rgba(255, 200, 0, 0.4)',
  'rgba(255, 150, 0, 0.4)',
  'rgba(0, 255, 0, 0.4)',
  'rgba(0, 200, 255, 0.4)',
  'rgba(150, 100, 255, 0.4)',
  'rgba(255, 100, 200, 0.4)',
  'rgba(255, 100, 100, 0.4)',
];

// ============================================================================
// PROPS
// ============================================================================

interface ColorPickerProps {
  onClose: () => void;
}

// ============================================================================
// COMPONENTE
// ============================================================================

export const ColorPicker: React.FC<ColorPickerProps> = memo(({ onClose }) => {
  const { brushSettings, setBrushColor, updateBrushSettings, activeTool } = useDrawingStore();
  
  const [customColor, setCustomColor] = useState(brushSettings.color);
  const [activeTab, setActiveTab] = useState<'preset' | 'custom' | 'highlighter'>('preset');

  const handleColorSelect = useCallback((color: string) => {
    setBrushColor(color);
    updateBrushSettings({ color });
  }, [setBrushColor, updateBrushSettings]);

  const handleCustomColorSubmit = useCallback(() => {
    if (customColor.match(/^#[0-9A-Fa-f]{6}$/)) {
      handleColorSelect(customColor);
    }
  }, [customColor, handleColorSelect]);

  const isHighlighter = activeTool === 'highlighter';
  const colorsToShow = isHighlighter && activeTab === 'highlighter' 
    ? HIGHLIGHTER_COLORS 
    : PRESET_COLORS;

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>Color</Text>
        <TouchableOpacity onPress={onClose} style={styles.closeButton}>
          <Text style={styles.closeIcon}>✕</Text>
        </TouchableOpacity>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'preset' && styles.tabActive]}
          onPress={() => setActiveTab('preset')}
        >
          <Text style={[styles.tabText, activeTab === 'preset' && styles.tabTextActive]}>
            Predefinidos
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeTab === 'custom' && styles.tabActive]}
          onPress={() => setActiveTab('custom')}
        >
          <Text style={[styles.tabText, activeTab === 'custom' && styles.tabTextActive]}>
            Personalizado
          </Text>
        </TouchableOpacity>
        
        {isHighlighter && (
          <TouchableOpacity
            style={[styles.tab, activeTab === 'highlighter' && styles.tabActive]}
            onPress={() => setActiveTab('highlighter')}
          >
            <Text style={[styles.tabText, activeTab === 'highlighter' && styles.tabTextActive]}>
              Resaltador
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Preview del color actual */}
      <View style={styles.previewSection}>
        <View style={styles.previewLabel}>
          <Text style={styles.previewText}>Color actual:</Text>
        </View>
        <View
          style={[
            styles.colorPreview,
            { backgroundColor: brushSettings.color },
          ]}
        />
        <Text style={styles.colorCode}>{brushSettings.color}</Text>
      </View>

      {/* Contenido según tab */}
      {activeTab === 'custom' ? (
        <View style={styles.customSection}>
          <Text style={styles.customLabel}>Ingresa color HEX:</Text>
          <TextInput
            style={styles.customInput}
            value={customColor}
            onChangeText={setCustomColor}
            placeholder="#000000"
            placeholderTextColor="#999"
            autoCapitalize="characters"
            maxLength={7}
          />
          <TouchableOpacity
            style={styles.customButton}
            onPress={handleCustomColorSubmit}
          >
            <Text style={styles.customButtonText}>Aplicar</Text>
          </TouchableOpacity>
          
          {/* Preview del color personalizado */}
          <View style={styles.customPreview}>
            <Text style={styles.customPreviewLabel}>Vista previa:</Text>
            <View
              style={[
                styles.customPreviewBox,
                { backgroundColor: customColor.match(/^#[0-9A-Fa-f]{6}$/) ? customColor : '#CCC' },
              ]}
            />
          </View>
        </View>
      ) : (
        <ScrollView style={styles.colorGrid} contentContainerStyle={styles.colorGridContent}>
          {colorsToShow.map((color, index) => (
            <TouchableOpacity
              key={`${color}-${index}`}
              style={[
                styles.colorButton,
                brushSettings.color === color && styles.colorButtonSelected,
              ]}
              onPress={() => handleColorSelect(color)}
            >
              <View style={[styles.colorSwatch, { backgroundColor: color }]} />
              {brushSettings.color === color && (
                <View style={styles.selectedIndicator}>
                  <Text style={styles.selectedCheck}>✓</Text>
                </View>
              )}
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      {/* Información de opacidad */}
      <View style={styles.opacitySection}>
        <Text style={styles.opacityLabel}>Opacidad: {(brushSettings.opacity * 100).toFixed(0)}%</Text>
        <View style={styles.opacityBar}>
          <View
            style={[
              styles.opacityFill,
              { width: `${brushSettings.opacity * 100}%` },
            ]}
          />
        </View>
      </View>
    </View>
  );
});

// ============================================================================
// ESTILOS
// ============================================================================

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 280,
    backgroundColor: '#FFFFFF',
    borderRightWidth: 1,
    borderRightColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 0 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
  },
  closeButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F5F5F5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeIcon: {
    fontSize: 16,
    color: '#666',
    fontWeight: '600',
  },
  tabs: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  tabActive: {
    borderBottomWidth: 2,
    borderBottomColor: '#2196F3',
  },
  tabText: {
    fontSize: 13,
    fontWeight: '500',
    color: '#666',
  },
  tabTextActive: {
    color: '#2196F3',
    fontWeight: '600',
  },
  previewSection: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    backgroundColor: '#FAFAFA',
  },
  previewLabel: {
    marginRight: 12,
  },
  previewText: {
    fontSize: 14,
    color: '#666',
  },
  colorPreview: {
    width: 40,
    height: 40,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    marginRight: 12,
  },
  colorCode: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    fontFamily: 'monospace',
  },
  colorGrid: {
    flex: 1,
  },
  colorGridContent: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 12,
    gap: 8,
  },
  colorButton: {
    width: 44,
    height: 44,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: 'transparent',
    overflow: 'hidden',
    position: 'relative',
  },
  colorButtonSelected: {
    borderColor: '#2196F3',
  },
  colorSwatch: {
    flex: 1,
    borderRadius: 6,
  },
  selectedIndicator: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedCheck: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  customSection: {
    padding: 16,
  },
  customLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  customInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    fontFamily: 'monospace',
    color: '#333',
    backgroundColor: '#FAFAFA',
  },
  customButton: {
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 12,
  },
  customButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  customPreview: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 20,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
  customPreviewLabel: {
    fontSize: 14,
    color: '#666',
    marginRight: 12,
  },
  customPreviewBox: {
    width: 60,
    height: 60,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  opacitySection: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    backgroundColor: '#FAFAFA',
  },
  opacityLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 6,
  },
  opacityBar: {
    height: 6,
    backgroundColor: '#E0E0E0',
    borderRadius: 3,
    overflow: 'hidden',
  },
  opacityFill: {
    height: '100%',
    backgroundColor: '#2196F3',
    borderRadius: 3,
  },
});

export default ColorPicker;
