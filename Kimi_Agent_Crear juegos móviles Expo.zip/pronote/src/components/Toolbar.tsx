/**
 * ProNote - Toolbar
 * Barra de herramientas inferior con selección de herramientas
 */

import React, { memo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

import { useDrawingStore } from '@store/useDrawingStore';
import { ToolType } from '@types/index';

// ============================================================================
// DEFINICIÓN DE HERRAMIENTAS
// ============================================================================

interface ToolDefinition {
  id: ToolType;
  label: string;
  icon: string;
  shortcut?: string;
}

const TOOLS: ToolDefinition[] = [
  { id: 'hand', label: 'Mano', icon: '✋', shortcut: 'H' },
  { id: 'pen', label: 'Pluma', icon: '✏️', shortcut: 'P' },
  { id: 'highlighter', label: 'Resaltador', icon: '🖍️', shortcut: 'M' },
  { id: 'eraser', label: 'Borrador', icon: '🧼', shortcut: 'E' },
  { id: 'laser', label: 'Láser', icon: '🔴', shortcut: 'L' },
  { id: 'shape', label: 'Formas', icon: '⬜', shortcut: 'S' },
  { id: 'ruler', label: 'Regla', icon: '📏', shortcut: 'R' },
  { id: 'lasso', label: 'Lazo', icon: '➰', shortcut: 'O' },
  { id: 'tape', label: 'Cinta', icon: '📎', shortcut: 'T' },
];

// ============================================================================
// COMPONENTE
// ============================================================================

export const Toolbar: React.FC = memo(() => {
  const { activeTool, setActiveTool, brushSettings, updateBrushSettings } = useDrawingStore();

  const handleToolPress = (toolId: ToolType) => {
    setActiveTool(toolId);
  };

  const handleSizeChange = (delta: number) => {
    const newSize = Math.max(1, Math.min(50, brushSettings.strokeWidth + delta));
    updateBrushSettings({ strokeWidth: newSize });
  };

  return (
    <View style={styles.container}>
      {/* Selector de tamaño */}
      <View style={styles.sizeSelector}>
        <TouchableOpacity
          style={styles.sizeButton}
          onPress={() => handleSizeChange(-1)}
        >
          <Text style={styles.sizeButtonText}>−</Text>
        </TouchableOpacity>
        
        <View style={styles.sizeDisplay}>
          <View
            style={[
              styles.sizePreview,
              { width: brushSettings.strokeWidth, height: brushSettings.strokeWidth },
            ]}
          />
          <Text style={styles.sizeText}>{brushSettings.strokeWidth.toFixed(0)}</Text>
        </View>
        
        <TouchableOpacity
          style={styles.sizeButton}
          onPress={() => handleSizeChange(1)}
        >
          <Text style={styles.sizeButtonText}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Scroll de herramientas */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.toolsScroll}
      >
        {TOOLS.map((tool) => (
          <TouchableOpacity
            key={tool.id}
            style={[
              styles.toolButton,
              activeTool === tool.id && styles.toolButtonActive,
            ]}
            onPress={() => handleToolPress(tool.id)}
            activeOpacity={0.7}
          >
            <Text style={styles.toolIcon}>{tool.icon}</Text>
            <Text
              style={[
                styles.toolLabel,
                activeTool === tool.id && styles.toolLabelActive,
              ]}
            >
              {tool.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Indicador de herramienta activa */}
      <View style={styles.activeIndicator}>
        <Text style={styles.activeText}>
          {TOOLS.find((t) => t.id === activeTool)?.label}
        </Text>
      </View>
    </View>
  );
});

// ============================================================================
// ESTILOS
// ============================================================================

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    paddingVertical: 8,
    paddingHorizontal: 8,
  },
  sizeSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
    paddingHorizontal: 16,
  },
  sizeButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F5F5F5',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  sizeButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  sizeDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 16,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    minWidth: 80,
    justifyContent: 'center',
  },
  sizePreview: {
    borderRadius: 100,
    backgroundColor: '#000',
    marginRight: 8,
  },
  sizeText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  toolsScroll: {
    paddingHorizontal: 8,
    gap: 8,
  },
  toolButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: '#F5F5F5',
    marginHorizontal: 4,
    minWidth: 64,
  },
  toolButtonActive: {
    backgroundColor: '#E3F2FD',
    borderWidth: 2,
    borderColor: '#2196F3',
  },
  toolIcon: {
    fontSize: 24,
    marginBottom: 4,
  },
  toolLabel: {
    fontSize: 11,
    color: '#666',
    fontWeight: '500',
  },
  toolLabelActive: {
    color: '#2196F3',
    fontWeight: '700',
  },
  activeIndicator: {
    alignItems: 'center',
    marginTop: 4,
  },
  activeText: {
    fontSize: 12,
    color: '#999',
    fontWeight: '500',
  },
});

export default Toolbar;
