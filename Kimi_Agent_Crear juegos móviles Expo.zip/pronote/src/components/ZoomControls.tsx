/**
 * ProNote - ZoomControls
 * Controles flotantes para zoom y navegación
 */

import React, { memo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';

import { useDrawingStore } from '@store/useDrawingStore';

// ============================================================================
// COMPONENTE
// ============================================================================

export const ZoomControls: React.FC = memo(() => {
  const {
    zoom,
    zoomIn,
    zoomOut,
    resetZoom,
    fitToScreen,
    panX,
    panY,
    resetPan,
    showMinimap,
    toggleMinimap,
  } = useDrawingStore();

  const zoomPercentage = Math.round(zoom * 100);

  return (
    <View style={styles.container}>
      {/* Controles de zoom */}
      <View style={styles.zoomGroup}>
        <TouchableOpacity
          style={styles.button}
          onPress={zoomOut}
          activeOpacity={0.7}
        >
          <Text style={styles.buttonIcon}>−</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.zoomDisplay}
          onPress={resetZoom}
          activeOpacity={0.7}
        >
          <Text style={styles.zoomText}>{zoomPercentage}%</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={zoomIn}
          activeOpacity={0.7}
        >
          <Text style={styles.buttonIcon}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Separador */}
      <View style={styles.divider} />

      {/* Controles de navegación */}
      <View style={styles.navGroup}>
        <TouchableOpacity
          style={styles.button}
          onPress={resetPan}
          activeOpacity={0.7}
        >
          <Text style={styles.buttonIcon}>⌖</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.button}
          onPress={fitToScreen}
          activeOpacity={0.7}
        >
          <Text style={styles.buttonIcon}>⛶</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, showMinimap && styles.buttonActive]}
          onPress={toggleMinimap}
          activeOpacity={0.7}
        >
          <Text style={styles.buttonIcon}>🗺</Text>
        </TouchableOpacity>
      </View>

      {/* Info de posición */}
      <View style={styles.positionInfo}>
        <Text style={styles.positionText}>
          X: {Math.round(panX)} Y: {Math.round(panY)}
        </Text>
      </View>
    </View>
  );
});

// ============================================================================
// ESTILOS
// ============================================================================

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 80,
    right: 16,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 4,
    padding: 8,
    minWidth: 56,
  },
  zoomGroup: {
    alignItems: 'center',
  },
  navGroup: {
    alignItems: 'center',
    marginTop: 4,
  },
  button: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#F5F5F5',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 2,
  },
  buttonActive: {
    backgroundColor: '#E3F2FD',
  },
  buttonIcon: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
  },
  zoomDisplay: {
    width: 56,
    height: 32,
    backgroundColor: '#E3F2FD',
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 4,
  },
  zoomText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#2196F3',
  },
  divider: {
    width: 32,
    height: 1,
    backgroundColor: '#E0E0E0',
    marginVertical: 8,
    alignSelf: 'center',
  },
  positionInfo: {
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    alignItems: 'center',
  },
  positionText: {
    fontSize: 10,
    color: '#999',
    fontFamily: 'monospace',
  },
});

export default ZoomControls;
