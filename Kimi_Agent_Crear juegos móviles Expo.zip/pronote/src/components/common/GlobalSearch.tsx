/**
 * ProNote - GlobalSearch
 * Búsqueda global en documentos, notas y contenido
 */

import React, { useState, useCallback, useMemo, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  Modal,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import Fuse from 'fuse.js';
import { useTranslation } from 'react-i18next';

import { useDrawingStore } from '@store/useDrawingStore';
import { Document, Page, Node, isTextNode, isInkNode } from '@types/index';

export interface SearchResult {
  id: string;
  type: 'document' | 'page' | 'node' | 'text';
  title: string;
  subtitle?: string;
  documentId: string;
  pageId?: string;
  nodeId?: string;
  preview?: string;
  matchScore: number;
}

interface GlobalSearchProps {
  visible: boolean;
  onClose: () => void;
  onResultSelect: (result: SearchResult) => void;
}

export const GlobalSearch: React.FC<GlobalSearchProps> = ({
  visible,
  onClose,
  onResultSelect,
}) => {
  const { t } = useTranslation();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [selectedFilters, setSelectedFilters] = useState<Set<string>>(new Set());

  const { documents } = useDrawingStore();

  // Configuración de Fuse para búsqueda difusa
  const fuseOptions = useMemo(() => ({
    keys: ['title', 'content', 'tags'],
    threshold: 0.4,
    includeScore: true,
  }), []);

  // Preparar datos para búsqueda
  const searchData = useMemo(() => {
    const items: Array<{
      id: string;
      type: string;
      title: string;
      content: string;
      tags: string[];
      documentId: string;
      pageId?: string;
      nodeId?: string;
    }> = [];

    documents.forEach((doc) => {
      // Documento
      items.push({
        id: doc.id,
        type: 'document',
        title: doc.title,
        content: '',
        tags: doc.tags,
        documentId: doc.id,
      });

      // Páginas
      doc.pages.forEach((page) => {
        items.push({
          id: page.id,
          type: 'page',
          title: page.name,
          content: '',
          tags: [],
          documentId: doc.id,
          pageId: page.id,
        });

        // Nodos
        page.nodes.forEach((node) => {
          let content = '';
          
          if (isTextNode(node)) {
            content = node.text;
          } else if (isInkNode(node)) {
            content = 'Dibujo a mano alzada';
          }

          items.push({
            id: node.id,
            type: 'node',
            title: `Nodo ${node.type}`,
            content,
            tags: [],
            documentId: doc.id,
            pageId: page.id,
            nodeId: node.id,
          });
        });
      });
    });

    return items;
  }, [documents]);

  const fuse = useMemo(() => new Fuse(searchData, fuseOptions), [searchData, fuseOptions]);

  // Realizar búsqueda
  useEffect(() => {
    if (query.length < 2) {
      setResults([]);
      return;
    }

    const searchResults = fuse.search(query);
    
    const formattedResults: SearchResult[] = searchResults.map((result) => ({
      id: result.item.id,
      type: result.item.type as SearchResult['type'],
      title: result.item.title,
      subtitle: result.item.content.substring(0, 100),
      documentId: result.item.documentId,
      pageId: result.item.pageId,
      nodeId: result.item.nodeId,
      preview: result.item.content,
      matchScore: result.score || 1,
    }));

    setResults(formattedResults);
  }, [query, fuse]);

  const handleResultPress = useCallback((result: SearchResult) => {
    onResultSelect(result);
    onClose();
    setQuery('');
  }, [onResultSelect, onClose]);

  const toggleFilter = useCallback((filter: string) => {
    setSelectedFilters((prev) => {
      const newFilters = new Set(prev);
      if (newFilters.has(filter)) {
        newFilters.delete(filter);
      } else {
        newFilters.add(filter);
      }
      return newFilters;
    });
  }, []);

  const filteredResults = useMemo(() => {
    if (selectedFilters.size === 0) return results;
    return results.filter((result) => selectedFilters.has(result.type));
  }, [results, selectedFilters]);

  const renderResult = useCallback(({ item }: { item: SearchResult }) => (
    <TouchableOpacity
      style={styles.resultItem}
      onPress={() => handleResultPress(item)}
    >
      <View style={styles.resultIcon}>
        <Text style={styles.resultIconText}>
          {item.type === 'document' ? '📄' :
           item.type === 'page' ? '📃' :
           item.type === 'text' ? '📝' : '✏️'}
        </Text>
      </View>
      <View style={styles.resultContent}>
        <Text style={styles.resultTitle} numberOfLines={1}>
          {item.title}
        </Text>
        {item.subtitle && (
          <Text style={styles.resultSubtitle} numberOfLines={2}>
            {item.subtitle}
          </Text>
        )}
        <View style={styles.resultMeta}>
          <Text style={styles.resultType}>
            {t(`search.types.${item.type}`)}
          </Text>
          <Text style={styles.resultScore}>
            {Math.round((1 - item.matchScore) * 100)}% match
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  ), [handleResultPress, t]);

  const filters = ['document', 'page', 'node', 'text'];

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
      >
        <View style={styles.content}>
          {/* Header */}
          <View style={styles.header}>
            <TextInput
              style={styles.searchInput}
              placeholder={t('search.placeholder')}
              placeholderTextColor="#999"
              value={query}
              onChangeText={setQuery}
              autoFocus
            />
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Text style={styles.closeText}>✕</Text>
            </TouchableOpacity>
          </View>

          {/* Filtros */}
          <View style={styles.filtersContainer}>
            {filters.map((filter) => (
              <TouchableOpacity
                key={filter}
                style={[
                  styles.filterButton,
                  selectedFilters.has(filter) && styles.filterButtonActive,
                ]}
                onPress={() => toggleFilter(filter)}
              >
                <Text
                  style={[
                    styles.filterText,
                    selectedFilters.has(filter) && styles.filterTextActive,
                  ]}
                >
                  {t(`search.types.${filter}`)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Resultados */}
          {filteredResults.length > 0 ? (
            <FlatList
              data={filteredResults}
              renderItem={renderResult}
              keyExtractor={(item) => item.id}
              contentContainerStyle={styles.resultsList}
            />
          ) : query.length >= 2 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>
                {t('search.noResults')}
              </Text>
            </View>
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.emptyText}>
                {t('search.startTyping')}
              </Text>
            </View>
          )}

          {/* Stats */}
          <View style={styles.footer}>
            <Text style={styles.statsText}>
              {t('search.resultsCount', { count: filteredResults.length })}
            </Text>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  content: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    marginTop: 50,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  searchInput: {
    flex: 1,
    height: 44,
    fontSize: 16,
    color: '#333',
  },
  closeButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeText: {
    fontSize: 20,
    color: '#666',
  },
  filtersContainer: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    gap: 8,
  },
  filterButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#F5F5F5',
  },
  filterButtonActive: {
    backgroundColor: '#E3F2FD',
  },
  filterText: {
    fontSize: 13,
    color: '#666',
  },
  filterTextActive: {
    color: '#2196F3',
    fontWeight: '600',
  },
  resultsList: {
    padding: 8,
  },
  resultItem: {
    flexDirection: 'row',
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#FAFAFA',
    marginBottom: 8,
  },
  resultIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: '#E3F2FD',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  resultIconText: {
    fontSize: 20,
  },
  resultContent: {
    flex: 1,
  },
  resultTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  resultSubtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  resultMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  resultType: {
    fontSize: 12,
    color: '#999',
  },
  resultScore: {
    fontSize: 12,
    color: '#4CAF50',
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
  },
  footer: {
    padding: 12,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    alignItems: 'center',
  },
  statsText: {
    fontSize: 12,
    color: '#999',
  },
});

export default GlobalSearch;
