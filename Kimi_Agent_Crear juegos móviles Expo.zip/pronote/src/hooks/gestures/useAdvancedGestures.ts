/**
 * ProNote - useAdvancedGestures Hook
 * Gestos avanzados: pinch, rotate, pan con física
 */

import { useRef, useCallback, useMemo } from 'react';
import {
  Gesture,
  GestureType,
  GestureUpdateEvent,
  PanGestureHandlerEventPayload,
  PinchGestureHandlerEventPayload,
  RotationGestureHandlerEventPayload,
} from 'react-native-gesture-handler';
import { runOnJS, useSharedValue, useAnimatedReaction } from 'react-native-reanimated';

export interface GestureState {
  scale: number;
  rotation: number;
  translationX: number;
  translationY: number;
  focalX: number;
  focalY: number;
  velocityX: number;
  velocityY: number;
}

export interface GestureCallbacks {
  onGestureStart?: (state: GestureState) => void;
  onGestureUpdate?: (state: GestureState) => void;
  onGestureEnd?: (state: GestureState) => void;
  onTap?: (x: number, y: number) => void;
  onDoubleTap?: (x: number, y: number) => void;
  onLongPress?: (x: number, y: number) => void;
}

export interface AdvancedGestureConfig {
  minScale?: number;
  maxScale?: number;
  enableRotation?: boolean;
  enablePan?: boolean;
  enablePinch?: boolean;
  doubleTapScale?: number;
  friction?: number;
}

export function useAdvancedGestures(
  config: AdvancedGestureConfig = {},
  callbacks: GestureCallbacks = {}
) {
  const {
    minScale = 0.1,
    maxScale = 5,
    enableRotation = true,
    enablePan = true,
    enablePinch = true,
    doubleTapScale = 2,
    friction = 0.9,
  } = config;

  // Valores compartidos para animaciones
  const scale = useSharedValue(1);
  const savedScale = useSharedValue(1);
  const rotation = useSharedValue(0);
  const savedRotation = useSharedValue(0);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const savedTranslateX = useSharedValue(0);
  const savedTranslateY = useSharedValue(0);
  const focalX = useSharedValue(0);
  const focalY = useSharedValue(0);

  // Estado para callbacks de JS
  const stateRef = useRef<GestureState>({
    scale: 1,
    rotation: 0,
    translationX: 0,
    translationY: 0,
    focalX: 0,
    focalY: 0,
    velocityX: 0,
    velocityY: 0,
  });

  const updateState = useCallback(() => {
    stateRef.current = {
      scale: scale.value,
      rotation: rotation.value,
      translationX: translateX.value,
      translationY: translateY.value,
      focalX: focalX.value,
      focalY: focalY.value,
      velocityX: 0,
      velocityY: 0,
    };
  }, []);

  // Gesture de Pinch (zoom)
  const pinchGesture = useMemo(() => {
    if (!enablePinch) return null;

    return Gesture.Pinch()
      .onStart(() => {
        savedScale.value = scale.value;
      })
      .onUpdate((event: GestureUpdateEvent<PinchGestureHandlerEventPayload>) => {
        const newScale = savedScale.value * event.scale;
        scale.value = Math.max(minScale, Math.min(maxScale, newScale));
        focalX.value = event.focalX;
        focalY.value = event.focalY;

        runOnJS(updateState)();
        if (callbacks.onGestureUpdate) {
          runOnJS(callbacks.onGestureUpdate)(stateRef.current);
        }
      })
      .onEnd(() => {
        savedScale.value = scale.value;
        if (callbacks.onGestureEnd) {
          runOnJS(callbacks.onGestureEnd)(stateRef.current);
        }
      });
  }, [enablePinch, minScale, maxScale, callbacks]);

  // Gesture de Rotación
  const rotationGesture = useMemo(() => {
    if (!enableRotation) return null;

    return Gesture.Rotation()
      .onStart(() => {
        savedRotation.value = rotation.value;
      })
      .onUpdate((event: GestureUpdateEvent<RotationGestureHandlerEventPayload>) => {
        rotation.value = savedRotation.value + event.rotation;

        runOnJS(updateState)();
        if (callbacks.onGestureUpdate) {
          runOnJS(callbacks.onGestureUpdate)(stateRef.current);
        }
      })
      .onEnd(() => {
        savedRotation.value = rotation.value;
        if (callbacks.onGestureEnd) {
          runOnJS(callbacks.onGestureEnd)(stateRef.current);
        }
      });
  }, [enableRotation, callbacks]);

  // Gesture de Pan (arrastre)
  const panGesture = useMemo(() => {
    if (!enablePan) return null;

    return Gesture.Pan()
      .onStart(() => {
        savedTranslateX.value = translateX.value;
        savedTranslateY.value = translateY.value;

        if (callbacks.onGestureStart) {
          runOnJS(callbacks.onGestureStart)(stateRef.current);
        }
      })
      .onUpdate((event: GestureUpdateEvent<PanGestureHandlerEventPayload>) => {
        translateX.value = savedTranslateX.value + event.translationX;
        translateY.value = savedTranslateY.value + event.translationY;

        runOnJS(updateState)();
        if (callbacks.onGestureUpdate) {
          runOnJS(callbacks.onGestureUpdate)(stateRef.current);
        }
      })
      .onEnd((event: GestureUpdateEvent<PanGestureHandlerEventPayload>) => {
        // Aplicar fricción para desaceleración
        const velocityX = event.velocityX * friction;
        const velocityY = event.velocityY * friction;

        // Aquí se podría agregar animación de decaimiento
        savedTranslateX.value = translateX.value;
        savedTranslateY.value = translateY.value;

        stateRef.current.velocityX = velocityX;
        stateRef.current.velocityY = velocityY;

        if (callbacks.onGestureEnd) {
          runOnJS(callbacks.onGestureEnd)(stateRef.current);
        }
      });
  }, [enablePan, friction, callbacks]);

  // Gesture de Tap
  const tapGesture = useMemo(() => {
    return Gesture.Tap()
      .onEnd((event) => {
        if (callbacks.onTap) {
          runOnJS(callbacks.onTap)(event.x, event.y);
        }
      });
  }, [callbacks]);

  // Gesture de Double Tap
  const doubleTapGesture = useMemo(() => {
    return Gesture.Tap()
      .numberOfTaps(2)
      .onEnd((event) => {
        // Zoom al punto del double tap
        const newScale = scale.value === 1 ? doubleTapScale : 1;
        scale.value = newScale;
        savedScale.value = newScale;

        if (newScale === 1) {
          translateX.value = 0;
          translateY.value = 0;
          savedTranslateX.value = 0;
          savedTranslateY.value = 0;
        }

        if (callbacks.onDoubleTap) {
          runOnJS(callbacks.onDoubleTap)(event.x, event.y);
        }
      });
  }, [doubleTapScale, callbacks]);

  // Gesture de Long Press
  const longPressGesture = useMemo(() => {
    return Gesture.LongPress()
      .onEnd((event) => {
        if (callbacks.onLongPress) {
          runOnJS(callbacks.onLongPress)(event.x, event.y);
        }
      });
  }, [callbacks]);

  // Combinar gestos
  const composedGesture = useMemo(() => {
    const gestures: (GestureType | null)[] = [
      pinchGesture,
      rotationGesture,
      panGesture,
      tapGesture,
      doubleTapGesture,
      longPressGesture,
    ].filter(Boolean) as GestureType[];

    if (gestures.length === 0) return null;

    return Gesture.Simultaneous(...gestures);
  }, [pinchGesture, rotationGesture, panGesture, tapGesture, doubleTapGesture, longPressGesture]);

  // Resetear transformaciones
  const resetTransform = useCallback(() => {
    scale.value = 1;
    savedScale.value = 1;
    rotation.value = 0;
    savedRotation.value = 0;
    translateX.value = 0;
    translateY.value = 0;
    savedTranslateX.value = 0;
    savedTranslateY.value = 0;
  }, []);

  // Ajustar a pantalla
  const fitToScreen = useCallback((contentWidth: number, contentHeight: number, screenWidth: number, screenHeight: number) => {
    const scaleX = screenWidth / contentWidth;
    const scaleY = screenHeight / contentHeight;
    const newScale = Math.min(scaleX, scaleY, 1);

    scale.value = newScale;
    savedScale.value = newScale;
    translateX.value = (screenWidth - contentWidth * newScale) / 2;
    translateY.value = (screenHeight - contentHeight * newScale) / 2;
    savedTranslateX.value = translateX.value;
    savedTranslateY.value = translateY.value;
  }, []);

  // Transformar punto de pantalla a coordenadas del contenido
  const screenToContent = useCallback((screenX: number, screenY: number) => {
    const contentX = (screenX - translateX.value) / scale.value;
    const contentY = (screenY - translateY.value) / scale.value;
    return { x: contentX, y: contentY };
  }, []);

  // Transformar punto del contenido a coordenadas de pantalla
  const contentToScreen = useCallback((contentX: number, contentY: number) => {
    const screenX = contentX * scale.value + translateX.value;
    const screenY = contentY * scale.value + translateY.value;
    return { x: screenX, y: screenY };
  }, []);

  return {
    // Gestos
    gesture: composedGesture,
    pinchGesture,
    rotationGesture,
    panGesture,
    tapGesture,
    doubleTapGesture,
    longPressGesture,

    // Valores animados
    animatedValues: {
      scale,
      rotation,
      translateX,
      translateY,
      focalX,
      focalY,
    },

    // Funciones
    resetTransform,
    fitToScreen,
    screenToContent,
    contentToScreen,

    // Estado
    getState: () => stateRef.current,
  };
}

export default useAdvancedGestures;
