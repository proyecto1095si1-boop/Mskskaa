/**
 * ProNote - useBrushEngine Hook
 * Motor de pinceles avanzado con física y dinámicas
 */

import { useRef, useCallback, useMemo } from 'react';
import { Skia, SkPath, Paint, StrokeCap, StrokeJoin } from '@shopify/react-native-skia';
import { BrushSettings, TouchPoint } from '@types/index';
import { StrokeSmoother, VariableWidthCalculator } from '@utils/ToolProcessor';

export interface BrushStroke {
  path: SkPath;
  points: TouchPoint[];
  paint: Paint;
  bounds: {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
  };
}

export interface BrushEngineState {
  isDrawing: boolean;
  currentStroke: BrushStroke | null;
  strokes: BrushStroke[];
}

export interface BrushEngineConfig {
  smoothing: number;
  velocitySensitivity: number;
  pressureSensitivity: number;
  minWidth: number;
  maxWidth: number;
  lazyRadius: number;
}

export function useBrushEngine(settings: BrushSettings) {
  const stateRef = useRef<BrushEngineState>({
    isDrawing: false,
    currentStroke: null,
    strokes: [],
  });

  const lazyBrushRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const pointsBufferRef = useRef<TouchPoint[]>([]);

  /**
   * Crea un paint configurado según los settings
   */
  const createPaint = useCallback((): Paint => {
    const paint = Skia.Paint();
    paint.setColor(Skia.Color(settings.color));
    paint.setStrokeWidth(settings.strokeWidth);
    paint.setStyle(1); // Stroke
    paint.setStrokeCap(StrokeCap.Round);
    paint.setStrokeJoin(StrokeJoin.Round);
    paint.setAntiAlias(true);
    
    if (settings.blendMode === 'multiply') {
      paint.setBlendMode(2); // Multiply
    }
    
    paint.setAlphaf(settings.opacity);
    return paint;
  }, [settings]);

  /**
   * Inicia un nuevo trazo
   */
  const startStroke = useCallback((point: TouchPoint): BrushStroke => {
    const path = Skia.Path.Make();
    path.moveTo(point.x, point.y);

    // Inicializar lazy brush
    lazyBrushRef.current = {
      x: point.x,
      y: point.y,
      targetX: point.x,
      targetY: point.y,
    };

    pointsBufferRef.current = [point];

    const stroke: BrushStroke = {
      path,
      points: [point],
      paint: createPaint(),
      bounds: {
        minX: point.x,
        minY: point.y,
        maxX: point.x,
        maxY: point.y,
      },
    };

    stateRef.current.currentStroke = stroke;
    stateRef.current.isDrawing = true;

    return stroke;
  }, [createPaint]);

  /**
   * Actualiza el trazo actual con un nuevo punto
   */
  const updateStroke = useCallback((point: TouchPoint): BrushStroke | null => {
    if (!stateRef.current.isDrawing || !stateRef.current.currentStroke) {
      return null;
    }

    const stroke = stateRef.current.currentStroke;

    // Aplicar lazy brush
    lazyBrushRef.current.targetX = point.x;
    lazyBrushRef.current.targetY = point.y;

    const dx = lazyBrushRef.current.targetX - lazyBrushRef.current.x;
    const dy = lazyBrushRef.current.targetY - lazyBrushRef.current.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance < settings.lazyRadius) {
      // Suavizado adicional
      lazyBrushRef.current.x += dx * 0.15;
      lazyBrushRef.current.y += dy * 0.15;
    } else {
      const angle = Math.atan2(dy, dx);
      lazyBrushRef.current.x = lazyBrushRef.current.targetX - Math.cos(angle) * settings.lazyRadius;
      lazyBrushRef.current.y = lazyBrushRef.current.targetY - Math.sin(angle) * settings.lazyRadius;
    }

    // Actualizar punto con posición lazy
    const lazyPoint: TouchPoint = {
      ...point,
      x: lazyBrushRef.current.x,
      y: lazyBrushRef.current.y,
    };

    // Calcular velocidad
    const lastPoint = stroke.points[stroke.points.length - 1];
    const timeDelta = point.timestamp - lastPoint.timestamp;
    const distDelta = Math.sqrt(
      Math.pow(point.x - lastPoint.x, 2) + Math.pow(point.y - lastPoint.y, 2)
    );
    lazyPoint.velocity = timeDelta > 0 ? distDelta / timeDelta : 0;

    stroke.points.push(lazyPoint);
    pointsBufferRef.current.push(lazyPoint);

    // Suavizar puntos si tenemos suficientes
    if (pointsBufferRef.current.length >= 3 && settings.smoothing > 0) {
      const smoothed = StrokeSmoother.catmullRom(
        pointsBufferRef.current,
        settings.smoothing
      );

      // Reconstruir path con puntos suavizados
      stroke.path = Skia.Path.Make();
      stroke.path.moveTo(smoothed[0].x, smoothed[0].y);

      for (let i = 1; i < smoothed.length - 1; i++) {
        const p0 = smoothed[i - 1];
        const p1 = smoothed[i];
        const p2 = smoothed[i + 1];

        const cpX = (p0.x + p1.x) / 2;
        const cpY = (p0.y + p1.y) / 2;

        stroke.path.quadTo(cpX, cpY, p1.x, p1.y);
      }

      if (smoothed.length > 1) {
        const last = smoothed[smoothed.length - 1];
        stroke.path.lineTo(last.x, last.y);
      }

      // Mantener solo últimos puntos en buffer
      if (pointsBufferRef.current.length > 5) {
        pointsBufferRef.current = pointsBufferRef.current.slice(-3);
      }
    } else {
      // Agregar punto directamente sin suavizado
      stroke.path.lineTo(lazyPoint.x, lazyPoint.y);
    }

    // Actualizar bounds
    stroke.bounds.minX = Math.min(stroke.bounds.minX, lazyPoint.x);
    stroke.bounds.minY = Math.min(stroke.bounds.minY, lazyPoint.y);
    stroke.bounds.maxX = Math.max(stroke.bounds.maxX, lazyPoint.x);
    stroke.bounds.maxY = Math.max(stroke.bounds.maxY, lazyPoint.y);

    // Actualizar ancho del stroke según velocidad
    if (settings.velocitySensitivity > 0) {
      const width = VariableWidthCalculator.calculateWidth(
        lazyPoint,
        settings.strokeWidth,
        settings
      );
      stroke.paint.setStrokeWidth(width);
    }

    return stroke;
  }, [settings]);

  /**
   * Finaliza el trazo actual
   */
  const endStroke = useCallback((): BrushStroke | null => {
    if (!stateRef.current.isDrawing || !stateRef.current.currentStroke) {
      return null;
    }

    const stroke = stateRef.current.currentStroke;
    stateRef.current.strokes.push(stroke);
    stateRef.current.currentStroke = null;
    stateRef.current.isDrawing = false;
    pointsBufferRef.current = [];

    return stroke;
  }, []);

  /**
   * Cancela el trazo actual
   */
  const cancelStroke = useCallback((): void => {
    stateRef.current.currentStroke = null;
    stateRef.current.isDrawing = false;
    pointsBufferRef.current = [];
  }, []);

  /**
   * Obtiene todos los trazos completados
   */
  const getCompletedStrokes = useCallback((): BrushStroke[] => {
    return stateRef.current.strokes;
  }, []);

  /**
   * Limpia todos los trazos
   */
  const clearStrokes = useCallback((): void => {
    stateRef.current.strokes = [];
    stateRef.current.currentStroke = null;
    stateRef.current.isDrawing = false;
  }, []);

  /**
   * Elimina el último trazo (undo)
   */
  const undoLastStroke = useCallback((): BrushStroke | null => {
    if (stateRef.current.strokes.length === 0) return null;
    return stateRef.current.strokes.pop() || null;
  }, []);

  /**
   * Verifica si está dibujando
   */
  const isDrawing = useCallback((): boolean => {
    return stateRef.current.isDrawing;
  }, []);

  return useMemo(() => ({
    startStroke,
    updateStroke,
    endStroke,
    cancelStroke,
    getCompletedStrokes,
    clearStrokes,
    undoLastStroke,
    isDrawing,
    get currentStroke() {
      return stateRef.current.currentStroke;
    },
    get strokes() {
      return stateRef.current.strokes;
    },
  }), [
    startStroke,
    updateStroke,
    endStroke,
    cancelStroke,
    getCompletedStrokes,
    clearStrokes,
    undoLastStroke,
    isDrawing,
  ]);
}

export default useBrushEngine;
