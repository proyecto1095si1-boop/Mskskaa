/**
 * ProNote - Drawing Store
 * Estado global con Zustand + Immer para inmutabilidad
 * Gestiona documentos, páginas, nodos y herramientas
 */

import { create } from 'zustand';
import { immer } from 'zustand/middleware/immer';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import { v4 as uuidv4 } from 'uuid';

import {
  AppState,
  Document,
  Page,
  Node,
  InkNode,
  TextNode,
  ImageNode,
  TableNode,
  StickerNode,
  ToolType,
  BrushSettings,
  RulerSettings,
  LaserSettings,
  UserPreferences,
  HistoryState,
  ShapeType,
  BlendModeType,
} from '@types/index';

// ============================================================================
// ESTADO INICIAL
// ============================================================================

const defaultBrushSettings: BrushSettings = {
  color: '#000000',
  strokeWidth: 3,
  minStrokeWidth: 1,
  maxStrokeWidth: 20,
  opacity: 1,
  toolType: 'pen',
  blendMode: 'srcOver',
  velocitySensitivity: 0.5,
  pressureSensitivity: 0.3,
  smoothing: 0.7,
  lazyRadius: 5,
};

const defaultRulerSettings: RulerSettings = {
  x: 100,
  y: 100,
  angle: 0,
  length: 300,
  visible: false,
  snapDistance: 20,
};

const defaultLaserSettings: LaserSettings = {
  fadeDuration: 2000,
  color: '#FF0000',
  strokeWidth: 3,
};

const defaultPreferences: UserPreferences = {
  language: 'es',
  theme: 'system',
  palmRejection: true,
  stylusOnly: false,
  autoSave: true,
  autoSaveInterval: 30000,
  defaultBrushColor: '#000000',
  defaultBrushSize: 3,
  showTooltips: true,
  hapticFeedback: true,
};

const createDefaultPage = (): Page => ({
  id: uuidv4(),
  name: 'Página 1',
  nodes: [],
  background: {
    type: 'blank',
    color: '#FFFFFF',
    lineColor: '#E0E0E0',
    lineSpacing: 30,
  },
  thumbnail: null,
  createdAt: Date.now(),
  modifiedAt: Date.now(),
});

const createDefaultDocument = (): Document => ({
  id: uuidv4(),
  title: 'Nota sin título',
  pages: [createDefaultPage()],
  currentPageIndex: 0,
  tags: [],
  favorite: false,
  createdAt: Date.now(),
  modifiedAt: Date.now(),
});

const initialState: Omit<AppState, 'history' | 'historyIndex' | 'maxHistorySize'> = {
  documents: [],
  currentDocumentId: null,
  activeTool: 'pen',
  brushSettings: defaultBrushSettings,
  rulerSettings: defaultRulerSettings,
  laserSettings: defaultLaserSettings,
  zoom: 1,
  panX: 0,
  panY: 0,
  showGrid: false,
  showMinimap: false,
  selectedNodeIds: [],
  selectionBounds: null,
  preferences: defaultPreferences,
};

// ============================================================================
// ACCIONES DEL STORE
// ============================================================================

interface DrawingActions {
  // Documentos
  createDocument: () => string;
  loadDocument: (id: string) => void;
  deleteDocument: (id: string) => void;
  updateDocumentTitle: (id: string, title: string) => void;
  toggleDocumentFavorite: (id: string) => void;
  
  // Páginas
  addPage: () => void;
  deletePage: (index: number) => void;
  setCurrentPage: (index: number) => void;
  reorderPages: (fromIndex: number, toIndex: number) => void;
  updatePageBackground: (type: Page['background']['type']) => void;
  
  // Nodos
  addNode: (node: Node) => void;
  updateNode: (id: string, updates: Partial<Node>) => void;
  deleteNode: (id: string) => void;
  deleteSelectedNodes: () => void;
  duplicateNode: (id: string) => void;
  reorderNodes: (nodeId: string, newZIndex: number) => void;
  lockNode: (id: string) => void;
  unlockNode: (id: string) => void;
  toggleNodeVisibility: (id: string) => void;
  
  // Selección
  selectNode: (id: string, multi?: boolean) => void;
  deselectNode: (id: string) => void;
  deselectAll: () => void;
  selectAll: () => void;
  selectNodesInBounds: (bounds: { x: number; y: number; width: number; height: number }) => void;
  
  // Herramientas
  setActiveTool: (tool: ToolType) => void;
  updateBrushSettings: (settings: Partial<BrushSettings>) => void;
  setBrushColor: (color: string) => void;
  setBrushSize: (size: number) => void;
  updateRulerSettings: (settings: Partial<RulerSettings>) => void;
  updateLaserSettings: (settings: Partial<LaserSettings>) => void;
  
  // Vista
  setZoom: (zoom: number) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  resetZoom: () => void;
  setPan: (x: number, y: number) => void;
  panBy: (dx: number, dy: number) => void;
  resetPan: () => void;
  toggleGrid: () => void;
  toggleMinimap: () => void;
  fitToScreen: () => void;
  
  // Historial (Undo/Redo)
  undo: () => void;
  redo: () => void;
  canUndo: () => boolean;
  canRedo: () => boolean;
  pushHistory: (action: Omit<HistoryState, 'timestamp'>) => void;
  clearHistory: () => void;
  
  // Preferencias
  updatePreferences: (prefs: Partial<UserPreferences>) => void;
  setLanguage: (lang: UserPreferences['language']) => void;
  setTheme: (theme: UserPreferences['theme']) => void;
  
  // Persistencia
  saveToFile: () => Promise<string>;
  loadFromFile: (uri: string) => Promise<void>;
  exportToImage: () => Promise<string>;
  exportToPDF: () => Promise<string>;
  
  // Utilidades
  getCurrentDocument: () => Document | null;
  getCurrentPage: () => Page | null;
  getSelectedNodes: () => Node[];
  getNodeById: (id: string) => Node | undefined;
  getNodesByType: <T extends Node>(type: T['type']) => T[];
  getHighestZIndex: () => number;
}

// ============================================================================
// STORE CON ZUSTAND + IMMER
// ============================================================================

export const useDrawingStore = create<AppState & DrawingActions>()(
  immer(
    persist(
      (set, get) => ({
        // Estado inicial
        ...initialState,
        history: [],
        historyIndex: -1,
        maxHistorySize: 50,

        // ========================================================================
        // DOCUMENTOS
        // ========================================================================
        
        createDocument: () => {
          const newDoc = createDefaultDocument();
          set((state) => {
            state.documents.push(newDoc);
            state.currentDocumentId = newDoc.id;
          });
          return newDoc.id;
        },

        loadDocument: (id) => {
          set((state) => {
            state.currentDocumentId = id;
          });
        },

        deleteDocument: (id) => {
          set((state) => {
            state.documents = state.documents.filter((d) => d.id !== id);
            if (state.currentDocumentId === id) {
              state.currentDocumentId = state.documents[0]?.id || null;
            }
          });
        },

        updateDocumentTitle: (id, title) => {
          set((state) => {
            const doc = state.documents.find((d) => d.id === id);
            if (doc) {
              doc.title = title;
              doc.modifiedAt = Date.now();
            }
          });
        },

        toggleDocumentFavorite: (id) => {
          set((state) => {
            const doc = state.documents.find((d) => d.id === id);
            if (doc) {
              doc.favorite = !doc.favorite;
            }
          });
        },

        // ========================================================================
        // PÁGINAS
        // ========================================================================

        addPage: () => {
          set((state) => {
            const doc = state.documents.find((d) => d.id === state.currentDocumentId);
            if (doc) {
              const newPage = createDefaultPage();
              newPage.name = `Página ${doc.pages.length + 1}`;
              doc.pages.push(newPage);
              doc.currentPageIndex = doc.pages.length - 1;
              doc.modifiedAt = Date.now();
            }
          });
        },

        deletePage: (index) => {
          set((state) => {
            const doc = state.documents.find((d) => d.id === state.currentDocumentId);
            if (doc && doc.pages.length > 1) {
              doc.pages.splice(index, 1);
              if (doc.currentPageIndex >= index) {
                doc.currentPageIndex = Math.max(0, doc.currentPageIndex - 1);
              }
              doc.modifiedAt = Date.now();
            }
          });
        },

        setCurrentPage: (index) => {
          set((state) => {
            const doc = state.documents.find((d) => d.id === state.currentDocumentId);
            if (doc && index >= 0 && index < doc.pages.length) {
              doc.currentPageIndex = index;
            }
          });
        },

        reorderPages: (fromIndex, toIndex) => {
          set((state) => {
            const doc = state.documents.find((d) => d.id === state.currentDocumentId);
            if (doc) {
              const [moved] = doc.pages.splice(fromIndex, 1);
              doc.pages.splice(toIndex, 0, moved);
              doc.currentPageIndex = toIndex;
            }
          });
        },

        updatePageBackground: (type) => {
          set((state) => {
            const page = get().getCurrentPage();
            if (page) {
              page.background.type = type;
              page.modifiedAt = Date.now();
            }
          });
        },

        // ========================================================================
        // NODOS
        // ========================================================================

        addNode: (node) => {
          set((state) => {
            const page = get().getCurrentPage();
            if (page) {
              // Asignar zIndex automáticamente
              const maxZ = get().getHighestZIndex();
              node.zIndex = maxZ + 1;
              page.nodes.push(node);
              page.modifiedAt = Date.now();
              
              // Agregar al historial
              get().pushHistory({
                type: 'add',
                nodeIds: [node.id],
                previousState: [],
                newState: [node],
              });
            }
          });
        },

        updateNode: (id, updates) => {
          set((state) => {
            const page = get().getCurrentPage();
            if (page) {
              const node = page.nodes.find((n) => n.id === id);
              if (node && !node.locked) {
                const previousState = { ...node };
                Object.assign(node, updates, { modifiedAt: Date.now() });
                
                get().pushHistory({
                  type: 'modify',
                  nodeIds: [id],
                  previousState: [previousState],
                  newState: [{ ...node }],
                });
              }
            }
          });
        },

        deleteNode: (id) => {
          set((state) => {
            const page = get().getCurrentPage();
            if (page) {
              const nodeIndex = page.nodes.findIndex((n) => n.id === id);
              if (nodeIndex !== -1) {
                const deletedNode = page.nodes[nodeIndex];
                page.nodes.splice(nodeIndex, 1);
                page.modifiedAt = Date.now();
                
                // Remover de selección si estaba seleccionado
                state.selectedNodeIds = state.selectedNodeIds.filter((sid) => sid !== id);
                
                get().pushHistory({
                  type: 'delete',
                  nodeIds: [id],
                  previousState: [deletedNode],
                  newState: [],
                });
              }
            }
          });
        },

        deleteSelectedNodes: () => {
          const { selectedNodeIds, deleteNode } = get();
          selectedNodeIds.forEach((id) => deleteNode(id));
          set((state) => {
            state.selectedNodeIds = [];
          });
        },

        duplicateNode: (id) => {
          const page = get().getCurrentPage();
          if (page) {
            const node = page.nodes.find((n) => n.id === id);
            if (node) {
              const duplicated = JSON.parse(JSON.stringify(node));
              duplicated.id = uuidv4();
              duplicated.x += 20;
              duplicated.y += 20;
              duplicated.createdAt = Date.now();
              duplicated.modifiedAt = Date.now();
              get().addNode(duplicated);
            }
          }
        },

        reorderNodes: (nodeId, newZIndex) => {
          set((state) => {
            const page = get().getCurrentPage();
            if (page) {
              const node = page.nodes.find((n) => n.id === nodeId);
              if (node) {
                node.zIndex = newZIndex;
                page.nodes.sort((a, b) => a.zIndex - b.zIndex);
                page.modifiedAt = Date.now();
              }
            }
          });
        },

        lockNode: (id) => {
          set((state) => {
            const page = get().getCurrentPage();
            if (page) {
              const node = page.nodes.find((n) => n.id === id);
              if (node) {
                node.locked = true;
              }
            }
          });
        },

        unlockNode: (id) => {
          set((state) => {
            const page = get().getCurrentPage();
            if (page) {
              const node = page.nodes.find((n) => n.id === id);
              if (node) {
                node.locked = false;
              }
            }
          });
        },

        toggleNodeVisibility: (id) => {
          set((state) => {
            const page = get().getCurrentPage();
            if (page) {
              const node = page.nodes.find((n) => n.id === id);
              if (node) {
                node.visible = !node.visible;
              }
            }
          });
        },

        // ========================================================================
        // SELECCIÓN
        // ========================================================================

        selectNode: (id, multi = false) => {
          set((state) => {
            if (multi) {
              if (state.selectedNodeIds.includes(id)) {
                state.selectedNodeIds = state.selectedNodeIds.filter((sid) => sid !== id);
              } else {
                state.selectedNodeIds.push(id);
              }
            } else {
              state.selectedNodeIds = [id];
            }
            get().updateSelectionBounds();
          });
        },

        deselectNode: (id) => {
          set((state) => {
            state.selectedNodeIds = state.selectedNodeIds.filter((sid) => sid !== id);
            get().updateSelectionBounds();
          });
        },

        deselectAll: () => {
          set((state) => {
            state.selectedNodeIds = [];
            state.selectionBounds = null;
          });
        },

        selectAll: () => {
          set((state) => {
            const page = get().getCurrentPage();
            if (page) {
              state.selectedNodeIds = page.nodes.filter((n) => !n.locked).map((n) => n.id);
              get().updateSelectionBounds();
            }
          });
        },

        selectNodesInBounds: (bounds) => {
          set((state) => {
            const page = get().getCurrentPage();
            if (page) {
              state.selectedNodeIds = page.nodes
                .filter((n) => {
                  if (n.locked) return false;
                  return (
                    n.x >= bounds.x &&
                    n.x <= bounds.x + bounds.width &&
                    n.y >= bounds.y &&
                    n.y <= bounds.y + bounds.height
                  );
                })
                .map((n) => n.id);
              get().updateSelectionBounds();
            }
          });
        },

        updateSelectionBounds: () => {
          const state = get();
          const selectedNodes = state.getSelectedNodes();
          if (selectedNodes.length === 0) {
            set((s) => {
              s.selectionBounds = null;
            });
            return;
          }

          let minX = Infinity;
          let minY = Infinity;
          let maxX = -Infinity;
          let maxY = -Infinity;

          selectedNodes.forEach((node) => {
            minX = Math.min(minX, node.x);
            minY = Math.min(minY, node.y);
            // Estimación simple del tamaño
            maxX = Math.max(maxX, node.x + 100);
            maxY = Math.max(maxY, node.y + 100);
          });

          set((s) => {
            s.selectionBounds = {
              x: minX,
              y: minY,
              width: maxX - minX,
              height: maxY - minY,
            };
          });
        },

        // ========================================================================
        // HERRAMIENTAS
        // ========================================================================

        setActiveTool: (tool) => {
          set((state) => {
            state.activeTool = tool;
            // Actualizar brush settings según la herramienta
            if (tool === 'highlighter') {
              state.brushSettings.blendMode = 'multiply';
              state.brushSettings.opacity = 0.4;
            } else if (tool === 'pen') {
              state.brushSettings.blendMode = 'srcOver';
              state.brushSettings.opacity = 1;
            }
          });
        },

        updateBrushSettings: (settings) => {
          set((state) => {
            Object.assign(state.brushSettings, settings);
          });
        },

        setBrushColor: (color) => {
          set((state) => {
            state.brushSettings.color = color;
          });
        },

        setBrushSize: (size) => {
          set((state) => {
            state.brushSettings.strokeWidth = size;
          });
        },

        updateRulerSettings: (settings) => {
          set((state) => {
            Object.assign(state.rulerSettings, settings);
          });
        },

        updateLaserSettings: (settings) => {
          set((state) => {
            Object.assign(state.laserSettings, settings);
          });
        },

        // ========================================================================
        // VISTA
        // ========================================================================

        setZoom: (zoom) => {
          set((state) => {
            state.zoom = Math.max(0.1, Math.min(5, zoom));
          });
        },

        zoomIn: () => {
          set((state) => {
            state.zoom = Math.min(5, state.zoom * 1.2);
          });
        },

        zoomOut: () => {
          set((state) => {
            state.zoom = Math.max(0.1, state.zoom / 1.2);
          });
        },

        resetZoom: () => {
          set((state) => {
            state.zoom = 1;
          });
        },

        setPan: (x, y) => {
          set((state) => {
            state.panX = x;
            state.panY = y;
          });
        },

        panBy: (dx, dy) => {
          set((state) => {
            state.panX += dx;
            state.panY += dy;
          });
        },

        resetPan: () => {
          set((state) => {
            state.panX = 0;
            state.panY = 0;
          });
        },

        toggleGrid: () => {
          set((state) => {
            state.showGrid = !state.showGrid;
          });
        },

        toggleMinimap: () => {
          set((state) => {
            state.showMinimap = !state.showMinimap;
          });
        },

        fitToScreen: () => {
          set((state) => {
            state.zoom = 1;
            state.panX = 0;
            state.panY = 0;
          });
        },

        // ========================================================================
        // HISTORIAL (UNDO/REDO)
        // ========================================================================

        pushHistory: (action) => {
          set((state) => {
            // Eliminar estados futuros si estamos en medio del historial
            if (state.historyIndex < state.history.length - 1) {
              state.history = state.history.slice(0, state.historyIndex + 1);
            }
            
            state.history.push({
              ...action,
              timestamp: Date.now(),
            });
            
            // Limitar tamaño del historial
            if (state.history.length > state.maxHistorySize) {
              state.history.shift();
            } else {
              state.historyIndex++;
            }
          });
        },

        undo: () => {
          const { historyIndex, history } = get();
          if (historyIndex >= 0) {
            const action = history[historyIndex];
            set((state) => {
              const page = get().getCurrentPage();
              if (page) {
                // Revertir la acción
                switch (action.type) {
                  case 'add':
                    page.nodes = page.nodes.filter((n) => !action.nodeIds.includes(n.id));
                    break;
                  case 'delete':
                    action.previousState.forEach((node) => {
                      page.nodes.push(node as Node);
                    });
                    break;
                  case 'modify':
                    action.nodeIds.forEach((id, i) => {
                      const node = page.nodes.find((n) => n.id === id);
                      if (node && action.previousState[i]) {
                        Object.assign(node, action.previousState[i]);
                      }
                    });
                    break;
                }
                state.historyIndex--;
              }
            });
          }
        },

        redo: () => {
          const { historyIndex, history } = get();
          if (historyIndex < history.length - 1) {
            const action = history[historyIndex + 1];
            set((state) => {
              const page = get().getCurrentPage();
              if (page) {
                // Reaplicar la acción
                switch (action.type) {
                  case 'add':
                    action.newState.forEach((node) => {
                      page.nodes.push(node as Node);
                    });
                    break;
                  case 'delete':
                    page.nodes = page.nodes.filter((n) => !action.nodeIds.includes(n.id));
                    break;
                  case 'modify':
                    action.nodeIds.forEach((id, i) => {
                      const node = page.nodes.find((n) => n.id === id);
                      if (node && action.newState[i]) {
                        Object.assign(node, action.newState[i]);
                      }
                    });
                    break;
                }
                state.historyIndex++;
              }
            });
          }
        },

        canUndo: () => get().historyIndex >= 0,
        canRedo: () => get().historyIndex < get().history.length - 1,

        clearHistory: () => {
          set((state) => {
            state.history = [];
            state.historyIndex = -1;
          });
        },

        // ========================================================================
        // PREFERENCIAS
        // ========================================================================

        updatePreferences: (prefs) => {
          set((state) => {
            Object.assign(state.preferences, prefs);
          });
        },

        setLanguage: (lang) => {
          set((state) => {
            state.preferences.language = lang;
          });
        },

        setTheme: (theme) => {
          set((state) => {
            state.preferences.theme = theme;
          });
        },

        // ========================================================================
        // PERSISTENCIA
        // ========================================================================

        saveToFile: async () => {
          const state = get();
          const doc = state.getCurrentDocument();
          if (!doc) throw new Error('No document open');

          const notesDir = FileSystem.documentDirectory + 'notes/';
          const assetsDir = notesDir + 'assets/';
          
          // Asegurar directorios existen
          await FileSystem.makeDirectoryAsync(notesDir, { intermediates: true });
          await FileSystem.makeDirectoryAsync(assetsDir, { intermediates: true });

          // Preparar datos para serialización
          const dataToSave = {
            ...doc,
            pages: doc.pages.map((page) => ({
              ...page,
              nodes: page.nodes.map((node) => {
                if (node.type === 'image') {
                  // Copiar imagen a assets si es necesario
                  return { ...node, uri: node.fileName };
                }
                return node;
              }),
            })),
          };

          const jsonPath = notesDir + `${doc.id}.json`;
          await FileSystem.writeAsStringAsync(
            jsonPath,
            JSON.stringify(dataToSave, null, 2)
          );

          return jsonPath;
        },

        loadFromFile: async (uri) => {
          const content = await FileSystem.readAsStringAsync(uri);
          const doc = JSON.parse(content) as Document;
          
          set((state) => {
            const existingIndex = state.documents.findIndex((d) => d.id === doc.id);
            if (existingIndex >= 0) {
              state.documents[existingIndex] = doc;
            } else {
              state.documents.push(doc);
            }
            state.currentDocumentId = doc.id;
          });
        },

        exportToImage: async () => {
          // Implementación en servicio separado
          return '';
        },

        exportToPDF: async () => {
          // Implementación en servicio separado
          return '';
        },

        // ========================================================================
        // UTILIDADES
        // ========================================================================

        getCurrentDocument: () => {
          const state = get();
          return state.documents.find((d) => d.id === state.currentDocumentId) || null;
        },

        getCurrentPage: () => {
          const doc = get().getCurrentDocument();
          if (!doc) return null;
          return doc.pages[doc.currentPageIndex] || null;
        },

        getSelectedNodes: () => {
          const page = get().getCurrentPage();
          if (!page) return [];
          return page.nodes.filter((n) => get().selectedNodeIds.includes(n.id));
        },

        getNodeById: (id) => {
          const page = get().getCurrentPage();
          return page?.nodes.find((n) => n.id === id);
        },

        getNodesByType: <T extends Node>(type: T['type']): T[] => {
          const page = get().getCurrentPage();
          if (!page) return [];
          return page.nodes.filter((n) => n.type === type) as T[];
        },

        getHighestZIndex: () => {
          const page = get().getCurrentPage();
          if (!page || page.nodes.length === 0) return 0;
          return Math.max(...page.nodes.map((n) => n.zIndex));
        },
      }),
      {
        name: 'pronote-storage',
        storage: createJSONStorage(() => AsyncStorage),
        partialize: (state) => ({
          documents: state.documents,
          currentDocumentId: state.currentDocumentId,
          preferences: state.preferences,
          brushSettings: state.brushSettings,
        }),
      }
    )
  )
);

export default useDrawingStore;
