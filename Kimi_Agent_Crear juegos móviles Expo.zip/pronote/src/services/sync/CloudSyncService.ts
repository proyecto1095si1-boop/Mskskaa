/**
 * ProNote - Cloud Sync Service
 * Sincronización de notas en la nube con Supabase
 */

import { createClient, SupabaseClient, RealtimeChannel } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import { Document, Page, Node } from '@types/index';

export interface SyncConfig {
  supabaseUrl: string;
  supabaseKey: string;
  autoSync: boolean;
  syncInterval: number;
  syncOnWifiOnly: boolean;
  conflictResolution: 'local' | 'remote' | 'newest' | 'manual';
}

export interface SyncStatus {
  isSyncing: boolean;
  lastSync: number | null;
  pendingChanges: number;
  conflicts: SyncConflict[];
  error: string | null;
}

export interface SyncConflict {
  documentId: string;
  localVersion: Document;
  remoteVersion: Document;
  localModifiedAt: number;
  remoteModifiedAt: number;
}

export interface CollaborationSession {
  id: string;
  documentId: string;
  participants: Array<{
    id: string;
    name: string;
    avatar?: string;
    cursor?: { x: number; y: number };
    selection?: string[];
  }>;
  isActive: boolean;
}

class CloudSyncService {
  private supabase: SupabaseClient | null = null;
  private config: SyncConfig | null = null;
  private realtimeChannels: Map<string, RealtimeChannel> = new Map();
  private syncIntervalId: NodeJS.Timeout | null = null;
  private status: SyncStatus = {
    isSyncing: false,
    lastSync: null,
    pendingChanges: 0,
    conflicts: [],
    error: null,
  };
  private listeners: Set<(status: SyncStatus) => void> = new Set();
  private offlineQueue: Array<{ type: string; data: any }> = [];

  /**
   * Inicializa el servicio de sincronización
   */
  async initialize(config: SyncConfig): Promise<void> {
    this.config = config;
    
    try {
      this.supabase = createClient(config.supabaseUrl, config.supabaseKey, {
        auth: {
          storage: AsyncStorage,
          autoRefreshToken: true,
          persistSession: true,
          detectSessionInUrl: false,
        },
      });

      // Configurar sincronización automática
      if (config.autoSync) {
        this.startAutoSync(config.syncInterval);
      }

      // Escuchar cambios de conectividad
      this.setupNetworkListener();
    } catch (error) {
      console.error('Error initializing cloud sync:', error);
      throw error;
    }
  }

  /**
   * Inicia sesión de usuario
   */
  async signIn(email: string, password: string): Promise<{ user: any; error: any }> {
    if (!this.supabase) {
      throw new Error('Sync service not initialized');
    }

    const { data, error } = await this.supabase.auth.signInWithPassword({
      email,
      password,
    });

    return { user: data.user, error };
  }

  /**
   * Registra un nuevo usuario
   */
  async signUp(email: string, password: string, metadata?: any): Promise<{ user: any; error: any }> {
    if (!this.supabase) {
      throw new Error('Sync service not initialized');
    }

    const { data, error } = await this.supabase.auth.signUp({
      email,
      password,
      options: { data: metadata },
    });

    return { user: data.user, error };
  }

  /**
   * Cierra sesión
   */
  async signOut(): Promise<void> {
    if (!this.supabase) return;

    await this.supabase.auth.signOut();
    this.stopAutoSync();
    this.realtimeChannels.forEach((channel) => channel.unsubscribe());
    this.realtimeChannels.clear();
  }

  /**
   * Sincroniza todos los documentos
   */
  async syncAll(): Promise<void> {
    if (!this.supabase || this.status.isSyncing) return;

    this.updateStatus({ isSyncing: true, error: null });

    try {
      // Obtener documentos locales
      const localDocsJson = await AsyncStorage.getItem('pronote-documents');
      const localDocs: Document[] = localDocsJson ? JSON.parse(localDocsJson) : [];

      // Obtener documentos remotos
      const { data: remoteDocs, error } = await this.supabase
        .from('documents')
        .select('*')
        .eq('user_id', (await this.supabase.auth.getUser()).data.user?.id);

      if (error) throw error;

      // Resolver conflictos y sincronizar
      for (const localDoc of localDocs) {
        const remoteDoc = remoteDocs?.find((d: any) => d.id === localDoc.id);

        if (!remoteDoc) {
          // Documento nuevo local - subir
          await this.uploadDocument(localDoc);
        } else if (localDoc.modifiedAt > remoteDoc.modified_at) {
          // Local más nuevo - subir
          await this.uploadDocument(localDoc);
        } else if (remoteDoc.modified_at > localDoc.modifiedAt) {
          // Remoto más nuevo - descargar
          await this.downloadDocument(remoteDoc);
        }
      }

      // Descargar documentos nuevos del servidor
      for (const remoteDoc of remoteDocs || []) {
        const localDoc = localDocs.find((d) => d.id === remoteDoc.id);
        if (!localDoc) {
          await this.downloadDocument(remoteDoc);
        }
      }

      this.updateStatus({
        isSyncing: false,
        lastSync: Date.now(),
        pendingChanges: 0,
      });
    } catch (error: any) {
      this.updateStatus({ isSyncing: false, error: error.message });
      throw error;
    }
  }

  /**
   * Sube un documento al servidor
   */
  private async uploadDocument(document: Document): Promise<void> {
    if (!this.supabase) return;

    const user = (await this.supabase.auth.getUser()).data.user;
    if (!user) throw new Error('User not authenticated');

    // Subir metadatos del documento
    const { error: docError } = await this.supabase.from('documents').upsert({
      id: document.id,
      user_id: user.id,
      title: document.title,
      tags: document.tags,
      favorite: document.favorite,
      created_at: new Date(document.createdAt).toISOString(),
      modified_at: new Date(document.modifiedAt).toISOString(),
    });

    if (docError) throw docError;

    // Subir páginas
    for (const page of document.pages) {
      const { error: pageError } = await this.supabase.from('pages').upsert({
        id: page.id,
        document_id: document.id,
        name: page.name,
        background: page.background,
        created_at: new Date(page.createdAt).toISOString(),
        modified_at: new Date(page.modifiedAt).toISOString(),
      });

      if (pageError) throw pageError;

      // Subir nodos de la página
      for (const node of page.nodes) {
        await this.uploadNode(node, page.id);
      }
    }
  }

  /**
   * Sube un nodo al servidor
   */
  private async uploadNode(node: Node, pageId: string): Promise<void> {
    if (!this.supabase) return;

    const { error } = await this.supabase.from('nodes').upsert({
      id: node.id,
      page_id: pageId,
      type: node.type,
      data: JSON.stringify(node),
      created_at: new Date(node.createdAt).toISOString(),
      modified_at: new Date(node.modifiedAt).toISOString(),
    });

    if (error) throw error;

    // Si es una imagen, subir el archivo
    if (node.type === 'image') {
      const imageNode = node as any;
      await this.uploadFile(imageNode.uri, `images/${node.id}`);
    }
  }

  /**
   * Descarga un documento del servidor
   */
  private async downloadDocument(remoteDoc: any): Promise<void> {
    if (!this.supabase) return;

    // Obtener páginas
    const { data: pages, error: pagesError } = await this.supabase
      .from('pages')
      .select('*')
      .eq('document_id', remoteDoc.id);

    if (pagesError) throw pagesError;

    // Obtener nodos de cada página
    const documentPages: Page[] = [];
    for (const page of pages || []) {
      const { data: nodes, error: nodesError } = await this.supabase
        .from('nodes')
        .select('*')
        .eq('page_id', page.id);

      if (nodesError) throw nodesError;

      documentPages.push({
        ...page,
        nodes: nodes?.map((n: any) => JSON.parse(n.data)) || [],
        createdAt: new Date(page.created_at).getTime(),
        modifiedAt: new Date(page.modified_at).getTime(),
      });
    }

    const document: Document = {
      id: remoteDoc.id,
      title: remoteDoc.title,
      pages: documentPages,
      currentPageIndex: 0,
      tags: remoteDoc.tags || [],
      favorite: remoteDoc.favorite || false,
      createdAt: new Date(remoteDoc.created_at).getTime(),
      modifiedAt: new Date(remoteDoc.modified_at).getTime(),
    };

    // Guardar localmente
    const localDocsJson = await AsyncStorage.getItem('pronote-documents');
    const localDocs: Document[] = localDocsJson ? JSON.parse(localDocsJson) : [];
    
    const existingIndex = localDocs.findIndex((d) => d.id === document.id);
    if (existingIndex >= 0) {
      localDocs[existingIndex] = document;
    } else {
      localDocs.push(document);
    }

    await AsyncStorage.setItem('pronote-documents', JSON.stringify(localDocs));
  }

  /**
   * Sube un archivo al storage
   */
  async uploadFile(localUri: string, remotePath: string): Promise<string> {
    if (!this.supabase) throw new Error('Sync service not initialized');

    const fileContent = await FileSystem.readAsStringAsync(localUri, {
      encoding: FileSystem.EncodingType.Base64,
    });

    const { data, error } = await this.supabase.storage
      .from('pronote-files')
      .upload(remotePath, Buffer.from(fileContent, 'base64'), {
        contentType: 'application/octet-stream',
        upsert: true,
      });

    if (error) throw error;

    // Obtener URL pública
    const { data: urlData } = await this.supabase.storage
      .from('pronote-files')
      .getPublicUrl(remotePath);

    return urlData.publicUrl;
  }

  /**
   * Descarga un archivo del storage
   */
  async downloadFile(remotePath: string, localPath: string): Promise<void> {
    if (!this.supabase) throw new Error('Sync service not initialized');

    const { data, error } = await this.supabase.storage
      .from('pronote-files')
      .download(remotePath);

    if (error) throw error;

    const base64Content = Buffer.from(await data.arrayBuffer()).toString('base64');
    await FileSystem.writeAsStringAsync(localPath, base64Content, {
      encoding: FileSystem.EncodingType.Base64,
    });
  }

  /**
   * Inicia sincronización automática
   */
  startAutoSync(intervalMs: number = 30000): void {
    this.stopAutoSync();
    this.syncIntervalId = setInterval(() => {
      this.syncAll();
    }, intervalMs);
  }

  /**
   * Detiene sincronización automática
   */
  stopAutoSync(): void {
    if (this.syncIntervalId) {
      clearInterval(this.syncIntervalId);
      this.syncIntervalId = null;
    }
  }

  /**
   * Configura listener de red
   */
  private setupNetworkListener(): void {
    // En React Native, usar NetInfo para detectar cambios de conectividad
    // Cuando vuelve la conexión, procesar cola offline
  }

  /**
   * Agrega cambio a la cola offline
   */
  queueChange(type: string, data: any): void {
    this.offlineQueue.push({ type, data });
    this.updateStatus({ pendingChanges: this.offlineQueue.length });
  }

  /**
   * Procesa cola offline
   */
  async processOfflineQueue(): Promise<void> {
    while (this.offlineQueue.length > 0) {
      const change = this.offlineQueue.shift();
      if (change) {
        try {
          // Procesar cambio
          await this.syncAll();
        } catch (error) {
          // Reinsertar en cola si falla
          this.offlineQueue.unshift(change);
          break;
        }
      }
    }
    this.updateStatus({ pendingChanges: this.offlineQueue.length });
  }

  /**
   * Inicia sesión de colaboración en tiempo real
   */
  async startCollaboration(documentId: string, onUpdate: (update: any) => void): Promise<void> {
    if (!this.supabase) return;

    const channel = this.supabase.channel(`document:${documentId}`);
    
    channel
      .on('presence', { event: 'sync' }, () => {
        const state = channel.presenceState();
        // Actualizar lista de participantes
      })
      .on('broadcast', { event: 'cursor' }, (payload) => {
        onUpdate({ type: 'cursor', data: payload });
      })
      .on('broadcast', { event: 'stroke' }, (payload) => {
        onUpdate({ type: 'stroke', data: payload });
      })
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await channel.track({ user: (await this.supabase?.auth.getUser())?.data.user });
        }
      });

    this.realtimeChannels.set(documentId, channel);
  }

  /**
   * Envía actualización de cursor
   */
  async sendCursorUpdate(documentId: string, position: { x: number; y: number }): Promise<void> {
    const channel = this.realtimeChannels.get(documentId);
    if (!channel) return;

    await channel.send({
      type: 'broadcast',
      event: 'cursor',
      payload: { position },
    });
  }

  /**
   * Envía trazo en tiempo real
   */
  async sendStrokeUpdate(documentId: string, stroke: any): Promise<void> {
    const channel = this.realtimeChannels.get(documentId);
    if (!channel) return;

    await channel.send({
      type: 'broadcast',
      event: 'stroke',
      payload: { stroke },
    });
  }

  /**
   * Detiene colaboración
   */
  stopCollaboration(documentId: string): void {
    const channel = this.realtimeChannels.get(documentId);
    if (channel) {
      channel.unsubscribe();
      this.realtimeChannels.delete(documentId);
    }
  }

  /**
   * Resuelve un conflicto de sincronización
   */
  async resolveConflict(conflict: SyncConflict, resolution: 'local' | 'remote' | 'merge'): Promise<void> {
    const index = this.status.conflicts.indexOf(conflict);
    if (index < 0) return;

    if (resolution === 'local') {
      await this.uploadDocument(conflict.localVersion);
    } else if (resolution === 'remote') {
      await this.downloadDocument(conflict.remoteVersion);
    }
    // merge requeriría UI para combinar cambios

    const newConflicts = [...this.status.conflicts];
    newConflicts.splice(index, 1);
    this.updateStatus({ conflicts: newConflicts });
  }

  /**
   * Obtiene estado de sincronización
   */
  getStatus(): SyncStatus {
    return { ...this.status };
  }

  /**
   * Suscribe a cambios de estado
   */
  subscribe(listener: (status: SyncStatus) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /**
   * Actualiza estado y notifica listeners
   */
  private updateStatus(updates: Partial<SyncStatus>): void {
    this.status = { ...this.status, ...updates };
    this.listeners.forEach((listener) => listener(this.status));
  }

  /**
   * Exporta todos los datos del usuario
   */
  async exportUserData(): Promise<{ json: string; files: string[] }> {
    if (!this.supabase) throw new Error('Sync service not initialized');

    const user = (await this.supabase.auth.getUser()).data.user;
    if (!user) throw new Error('User not authenticated');

    // Obtener todos los documentos
    const { data: documents, error } = await this.supabase
      .from('documents')
      .select('*')
      .eq('user_id', user.id);

    if (error) throw error;

    // Obtener lista de archivos
    const { data: files } = await this.supabase.storage
      .from('pronote-files')
      .list(user.id);

    return {
      json: JSON.stringify(documents, null, 2),
      files: files?.map((f) => f.name) || [],
    };
  }

  /**
   * Elimina todos los datos del usuario (GDPR)
   */
  async deleteUserData(): Promise<void> {
    if (!this.supabase) throw new Error('Sync service not initialized');

    const user = (await this.supabase.auth.getUser()).data.user;
    if (!user) throw new Error('User not authenticated');

    // Eliminar documentos
    await this.supabase.from('documents').delete().eq('user_id', user.id);

    // Eliminar archivos
    await this.supabase.storage.from('pronote-files').remove([user.id]);

    // Eliminar cuenta
    await this.supabase.auth.admin.deleteUser(user.id);
  }
}

export const cloudSyncService = new CloudSyncService();
export default CloudSyncService;
