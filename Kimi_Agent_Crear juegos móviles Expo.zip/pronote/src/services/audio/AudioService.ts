/**
 * ProNote - Audio Service
 * Grabación y reproducción de audio sincronizado con notas
 */

import { Audio } from 'expo-av';
import * as FileSystem from 'expo-file-system';
import { Recording, RecordingStatus } from 'expo-av/build/Audio';

export interface AudioNote {
  id: string;
  uri: string;
  duration: number;
  createdAt: number;
  pageId: string;
  nodeId?: string;
  timestamp?: number; // Timestamp en la nota donde se grabó
  transcription?: string;
}

export interface AudioRecordingOptions {
  quality?: Audio.RecordingOptions;
  maxDuration?: number;
  onStatusUpdate?: (status: RecordingStatus) => void;
}

export interface AudioPlaybackOptions {
  position?: number;
  rate?: number;
  shouldCorrectPitch?: boolean;
  volume?: number;
  isMuted?: boolean;
  isLooping?: boolean;
  onPlaybackStatusUpdate?: (status: Audio.PlaybackStatus) => void;
}

class AudioService {
  private recording: Recording | null = null;
  private playback: Audio.Sound | null = null;
  private recordings: Map<string, AudioNote> = new Map();
  private isRecording: boolean = false;
  private isPlaying: boolean = false;

  /**
   * Solicita permisos de audio
   */
  async requestPermissions(): Promise<boolean> {
    try {
      const { status } = await Audio.requestPermissionsAsync();
      return status === 'granted';
    } catch (error) {
      console.error('Error requesting audio permissions:', error);
      return false;
    }
  }

  /**
   * Configura el modo de audio
   */
  async configureAudioMode(mode: 'recording' | 'playback'): Promise<void> {
    try {
      if (mode === 'recording') {
        await Audio.setAudioModeAsync({
          allowsRecordingIOS: true,
          playsInSilentModeIOS: true,
          staysActiveInBackground: true,
          shouldDuckAndroid: true,
        });
      } else {
        await Audio.setAudioModeAsync({
          allowsRecordingIOS: false,
          playsInSilentModeIOS: true,
          staysActiveInBackground: true,
          shouldDuckAndroid: true,
        });
      }
    } catch (error) {
      console.error('Error configuring audio mode:', error);
      throw error;
    }
  }

  /**
   * Inicia la grabación de audio
   */
  async startRecording(options: AudioRecordingOptions = {}): Promise<string> {
    try {
      const hasPermission = await this.requestPermissions();
      if (!hasPermission) {
        throw new Error('Audio recording permission not granted');
      }

      await this.configureAudioMode('recording');

      // Crear nueva grabación
      const { recording } = await Audio.Recording.createAsync(
        options.quality || Audio.RecordingOptionsPresets.HIGH_QUALITY,
        options.onStatusUpdate
      );

      this.recording = recording;
      this.isRecording = true;

      return recording.getURI() || '';
    } catch (error) {
      console.error('Error starting recording:', error);
      throw error;
    }
  }

  /**
   * Detiene la grabación y guarda el archivo
   */
  async stopRecording(pageId: string, nodeId?: string): Promise<AudioNote> {
    if (!this.recording) {
      throw new Error('No active recording');
    }

    try {
      await this.recording.stopAndUnloadAsync();
      
      const uri = this.recording.getURI();
      if (!uri) {
        throw new Error('Recording URI not available');
      }

      const status = await this.recording.getStatusAsync();
      const durationMillis = (status as RecordingStatus).durationMillis || 0;

      // Crear objeto AudioNote
      const audioNote: AudioNote = {
        id: `audio_${Date.now()}`,
        uri,
        duration: durationMillis,
        createdAt: Date.now(),
        pageId,
        nodeId,
        timestamp: Date.now(),
      };

      // Guardar en el mapa
      this.recordings.set(audioNote.id, audioNote);

      // Limpiar
      this.recording = null;
      this.isRecording = false;

      return audioNote;
    } catch (error) {
      console.error('Error stopping recording:', error);
      throw error;
    }
  }

  /**
   * Pausa la grabación actual
   */
  async pauseRecording(): Promise<void> {
    if (!this.recording) return;

    try {
      await this.recording.pauseAsync();
    } catch (error) {
      console.error('Error pausing recording:', error);
      throw error;
    }
  }

  /**
   * Reanuda la grabación pausada
   */
  async resumeRecording(): Promise<void> {
    if (!this.recording) return;

    try {
      await this.recording.startAsync();
    } catch (error) {
      console.error('Error resuming recording:', error);
      throw error;
    }
  }

  /**
   * Reproduce un audio
   */
  async playAudio(audioNote: AudioNote, options: AudioPlaybackOptions = {}): Promise<void> {
    try {
      // Detener reproducción actual si existe
      await this.stopPlayback();

      await this.configureAudioMode('playback');

      // Crear nuevo objeto de sonido
      const { sound } = await Audio.Sound.createAsync(
        { uri: audioNote.uri },
        {
          shouldPlay: true,
          positionMillis: options.position || 0,
          rate: options.rate || 1.0,
          shouldCorrectPitch: options.shouldCorrectPitch ?? true,
          volume: options.volume || 1.0,
          isMuted: options.isMuted || false,
          isLooping: options.isLooping || false,
        },
        options.onPlaybackStatusUpdate
      );

      this.playback = sound;
      this.isPlaying = true;

      // Configurar listener de estado
      this.playback.setOnPlaybackStatusUpdate((status) => {
        if (status.isLoaded && status.didJustFinish) {
          this.isPlaying = false;
        }
        options.onPlaybackStatusUpdate?.(status);
      });
    } catch (error) {
      console.error('Error playing audio:', error);
      throw error;
    }
  }

  /**
   * Pausa la reproducción
   */
  async pausePlayback(): Promise<void> {
    if (!this.playback) return;

    try {
      await this.playback.pauseAsync();
      this.isPlaying = false;
    } catch (error) {
      console.error('Error pausing playback:', error);
      throw error;
    }
  }

  /**
   * Reanuda la reproducción
   */
  async resumePlayback(): Promise<void> {
    if (!this.playback) return;

    try {
      await this.playback.playAsync();
      this.isPlaying = true;
    } catch (error) {
      console.error('Error resuming playback:', error);
      throw error;
    }
  }

  /**
   * Detiene la reproducción
   */
  async stopPlayback(): Promise<void> {
    if (!this.playback) return;

    try {
      await this.playback.stopAsync();
      await this.playback.unloadAsync();
      this.playback = null;
      this.isPlaying = false;
    } catch (error) {
      console.error('Error stopping playback:', error);
      throw error;
    }
  }

  /**
   * Busca a una posición específica
   */
  async seekTo(positionMillis: number): Promise<void> {
    if (!this.playback) return;

    try {
      await this.playback.setPositionAsync(positionMillis);
    } catch (error) {
      console.error('Error seeking:', error);
      throw error;
    }
  }

  /**
   * Obtiene el estado actual de reproducción
   */
  async getPlaybackStatus(): Promise<Audio.PlaybackStatus | null> {
    if (!this.playback) return null;

    try {
      return await this.playback.getStatusAsync();
    } catch (error) {
      console.error('Error getting playback status:', error);
      return null;
    }
  }

  /**
   * Elimina una grabación
   */
  async deleteRecording(audioId: string): Promise<void> {
    const audioNote = this.recordings.get(audioId);
    if (!audioNote) return;

    try {
      await FileSystem.deleteAsync(audioNote.uri, { idempotent: true });
      this.recordings.delete(audioId);
    } catch (error) {
      console.error('Error deleting recording:', error);
      throw error;
    }
  }

  /**
   * Exporta una grabación a formato específico
   */
  async exportRecording(audioId: string, format: 'm4a' | 'wav' | 'mp3'): Promise<string> {
    const audioNote = this.recordings.get(audioId);
    if (!audioNote) {
      throw new Error('Recording not found');
    }

    // En producción, aquí se convertiría el formato usando ffmpeg o similar
    // Por ahora, simplemente copiamos el archivo
    
    const outputPath = FileSystem.cacheDirectory + `exported_${audioId}.${format}`;
    
    try {
      await FileSystem.copyAsync({
        from: audioNote.uri,
        to: outputPath,
      });
      
      return outputPath;
    } catch (error) {
      console.error('Error exporting recording:', error);
      throw error;
    }
  }

  /**
   * Obtiene todas las grabaciones
   */
  getAllRecordings(): AudioNote[] {
    return Array.from(this.recordings.values());
  }

  /**
   * Obtiene grabaciones de una página específica
   */
  getRecordingsByPage(pageId: string): AudioNote[] {
    return Array.from(this.recordings.values()).filter(
      (recording) => recording.pageId === pageId
    );
  }

  /**
   * Verifica si está grabando
   */
  getIsRecording(): boolean {
    return this.isRecording;
  }

  /**
   * Verifica si está reproduciendo
   */
  getIsPlaying(): boolean {
    return this.isPlaying;
  }

  /**
   * Sincroniza audio con posición en el lienzo
   * Útil para "audio notes" que se activan al tocar cierta área
   */
  async syncAudioWithPosition(
    audioId: string,
    canvasPosition: { x: number; y: number }
  ): Promise<void> {
    const audioNote = this.recordings.get(audioId);
    if (!audioNote) return;

    // Actualizar el timestamp/posición asociada
    audioNote.timestamp = Date.now();
    
    // En una implementación completa, aquí se vincularía
    // el audio con un nodo específico en el canvas
  }

  /**
   * Transcribe audio a texto (requiere servicio de STT)
   */
  async transcribeAudio(audioId: string, language: string = 'es-ES'): Promise<string> {
    const audioNote = this.recordings.get(audioId);
    if (!audioNote) {
      throw new Error('Recording not found');
    }

    // En producción, usaría Google Speech-to-Text, Azure Speech, o similar
    console.warn('Speech-to-Text requires backend service');
    return '';
  }

  /**
   * Libera todos los recursos
   */
  async cleanup(): Promise<void> {
    if (this.recording) {
      await this.recording.stopAndUnloadAsync();
      this.recording = null;
    }

    if (this.playback) {
      await this.playback.unloadAsync();
      this.playback = null;
    }

    this.isRecording = false;
    this.isPlaying = false;
  }
}

export const audioService = new AudioService();
export default AudioService;
