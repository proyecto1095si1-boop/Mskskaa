/**
 * ProNote - Template Service
 * Sistema de plantillas para notas predefinidas
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Document, Page, Node, TableNode, TextNode } from '@types/index';
import { v4 as uuidv4 } from 'uuid';

export interface Template {
  id: string;
  name: string;
  description: string;
  category: TemplateCategory;
  thumbnail?: string;
  document: Partial<Document>;
  isPremium: boolean;
  tags: string[];
  createdAt: number;
  author?: string;
  downloads: number;
  rating: number;
}

export type TemplateCategory =
  | 'productivity'
  | 'education'
  | 'business'
  | 'creative'
  | 'planner'
  | 'journal'
  | 'meeting'
  | 'study'
  | 'project'
  | 'custom';

export interface TemplateFilter {
  category?: TemplateCategory;
  search?: string;
  isPremium?: boolean;
  tags?: string[];
  sortBy?: 'popular' | 'newest' | 'rating' | 'name';
}

class TemplateService {
  private templates: Map<string, Template> = new Map();
  private userTemplates: Set<string> = new Set();
  private favorites: Set<string> = new Set();
  private readonly STORAGE_KEY = 'pronote-templates';
  private readonly FAVORITES_KEY = 'pronote-template-favorites';

  constructor() {
    this.loadBuiltInTemplates();
    this.loadUserTemplates();
  }

  /**
   * Carga las plantillas integradas
   */
  private loadBuiltInTemplates(): void {
    // Plantilla: Cuaderno de notas simple
    this.addTemplate({
      id: 'blank-notebook',
      name: 'Cuaderno en blanco',
      description: 'Página en blanco para notas libres',
      category: 'productivity',
      isPremium: false,
      tags: ['blank', 'simple', 'notes'],
      createdAt: Date.now(),
      downloads: 10000,
      rating: 4.5,
      document: {
        title: 'Notas',
        pages: [{
          id: uuidv4(),
          name: 'Página 1',
          nodes: [],
          background: {
            type: 'blank',
            color: '#FFFFFF',
            lineColor: '#E0E0E0',
            lineSpacing: 30,
          },
          thumbnail: null,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        }],
      },
    });

    // Plantilla: Líneas (ruled)
    this.addTemplate({
      id: 'lined-paper',
      name: 'Papel rayado',
      description: 'Página con líneas para escritura',
      category: 'education',
      isPremium: false,
      tags: ['lined', 'writing', 'school'],
      createdAt: Date.now(),
      downloads: 8500,
      rating: 4.7,
      document: {
        title: 'Notas rayadas',
        pages: [{
          id: uuidv4(),
          name: 'Página 1',
          nodes: [],
          background: {
            type: 'lined',
            color: '#FFFFFF',
            lineColor: '#AEC7EA',
            lineSpacing: 30,
          },
          thumbnail: null,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        }],
      },
    });

    // Plantilla: Cuadrícula
    this.addTemplate({
      id: 'grid-paper',
      name: 'Papel cuadriculado',
      description: 'Cuadrícula para dibujos técnicos y diagramas',
      category: 'creative',
      isPremium: false,
      tags: ['grid', 'drawing', 'technical'],
      createdAt: Date.now(),
      downloads: 7200,
      rating: 4.6,
      document: {
        title: 'Cuadrícula',
        pages: [{
          id: uuidv4(),
          name: 'Página 1',
          nodes: [],
          background: {
            type: 'grid',
            color: '#FFFFFF',
            lineColor: '#E0E0E0',
            lineSpacing: 20,
          },
          thumbnail: null,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        }],
      },
    });

    // Plantilla: Reunión
    this.addTemplate({
      id: 'meeting-notes',
      name: 'Notas de reunión',
      description: 'Estructura para tomar notas de reuniones',
      category: 'business',
      isPremium: false,
      tags: ['meeting', 'business', 'professional'],
      createdAt: Date.now(),
      downloads: 5400,
      rating: 4.8,
      document: {
        title: 'Reunión - ' + new Date().toLocaleDateString(),
        pages: [{
          id: uuidv4(),
          name: 'Página 1',
          nodes: this.createMeetingNotesNodes(),
          background: {
            type: 'blank',
            color: '#FFFFFF',
            lineColor: '#E0E0E0',
            lineSpacing: 30,
          },
          thumbnail: null,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        }],
      },
    });

    // Plantilla: Cornell Notes
    this.addTemplate({
      id: 'cornell-notes',
      name: 'Método Cornell',
      description: 'Sistema Cornell para tomar notas de estudio',
      category: 'study',
      isPremium: true,
      tags: ['cornell', 'study', 'learning', 'education'],
      createdAt: Date.now(),
      downloads: 3200,
      rating: 4.9,
      document: {
        title: 'Notas Cornell',
        pages: [{
          id: uuidv4(),
          name: 'Página 1',
          nodes: this.createCornellNotesNodes(),
          background: {
            type: 'lined',
            color: '#FFFFFF',
            lineColor: '#AEC7EA',
            lineSpacing: 25,
          },
          thumbnail: null,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        }],
      },
    });

    // Plantilla: Bullet Journal
    this.addTemplate({
      id: 'bullet-journal',
      name: 'Bullet Journal',
      description: 'Plantilla para sistema Bullet Journal',
      category: 'planner',
      isPremium: true,
      tags: ['bujo', 'journal', 'planner', 'organization'],
      createdAt: Date.now(),
      downloads: 4800,
      rating: 4.7,
      document: {
        title: 'Bullet Journal - ' + new Date().toLocaleDateString('es', { month: 'long', year: 'numeric' }),
        pages: [{
          id: uuidv4(),
          name: 'Índice',
          nodes: this.createBulletJournalNodes(),
          background: {
            type: 'dotted',
            color: '#FFFFFF',
            lineColor: '#CCCCCC',
            lineSpacing: 15,
          },
          thumbnail: null,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        }],
      },
    });

    // Plantilla: Kanban Board
    this.addTemplate({
      id: 'kanban-board',
      name: 'Tablero Kanban',
      description: 'Tablero Kanban para gestión de tareas',
      category: 'project',
      isPremium: true,
      tags: ['kanban', 'agile', 'project', 'tasks'],
      createdAt: Date.now(),
      downloads: 2800,
      rating: 4.6,
      document: {
        title: 'Proyecto Kanban',
        pages: [{
          id: uuidv4(),
          name: 'Tablero',
          nodes: this.createKanbanNodes(),
          background: {
            type: 'blank',
            color: '#F5F5F5',
            lineColor: '#E0E0E0',
            lineSpacing: 30,
          },
          thumbnail: null,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        }],
      },
    });

    // Plantilla: Calendario Semanal
    this.addTemplate({
      id: 'weekly-planner',
      name: 'Planificador semanal',
      description: 'Vista semanal para planificación',
      category: 'planner',
      isPremium: true,
      tags: ['weekly', 'planner', 'calendar', 'organization'],
      createdAt: Date.now(),
      downloads: 3600,
      rating: 4.5,
      document: {
        title: 'Semana del ' + new Date().toLocaleDateString(),
        pages: [{
          id: uuidv4(),
          name: 'Semana',
          nodes: this.createWeeklyPlannerNodes(),
          background: {
            type: 'grid',
            color: '#FFFFFF',
            lineColor: '#E0E0E0',
            lineSpacing: 30,
          },
          thumbnail: null,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        }],
      },
    });
  }

  /**
   * Crea nodos para plantilla de reuniones
   */
  private createMeetingNotesNodes(): Node[] {
    const nodes: Node[] = [];
    const now = Date.now();

    // Título
    nodes.push({
      id: uuidv4(),
      type: 'text',
      x: 50,
      y: 30,
      rotation: 0,
      scale: 1,
      zIndex: 1,
      locked: false,
      visible: true,
      opacity: 1,
      createdAt: now,
      modifiedAt: now,
      text: 'NOTAS DE REUNIÓN',
      fontFamily: 'System',
      fontSize: 24,
      fontWeight: 'bold',
      color: '#333333',
      backgroundColor: null,
      width: 300,
      height: 40,
      alignment: 'left',
      isEditing: false,
    } as TextNode);

    // Campos de información
    const fields = [
      { label: 'Fecha: _______________', y: 80 },
      { label: 'Hora: _______________', y: 110 },
      { label: 'Lugar: _______________', y: 140 },
      { label: 'Asistentes: _______________', y: 170 },
    ];

    fields.forEach((field) => {
      nodes.push({
        id: uuidv4(),
        type: 'text',
        x: 50,
        y: field.y,
        rotation: 0,
        scale: 1,
        zIndex: 1,
        locked: false,
        visible: true,
        opacity: 1,
        createdAt: now,
        modifiedAt: now,
        text: field.label,
        fontFamily: 'System',
        fontSize: 14,
        fontWeight: 'normal',
        color: '#666666',
        backgroundColor: null,
        width: 250,
        height: 25,
        alignment: 'left',
        isEditing: false,
      } as TextNode);
    });

    // Sección de agenda
    nodes.push({
      id: uuidv4(),
      type: 'text',
      x: 50,
      y: 220,
      rotation: 0,
      scale: 1,
      zIndex: 1,
      locked: false,
      visible: true,
      opacity: 1,
      createdAt: now,
      modifiedAt: now,
      text: 'AGENDA:',
      fontFamily: 'System',
      fontSize: 16,
      fontWeight: 'bold',
      color: '#333333',
      backgroundColor: null,
      width: 100,
      height: 25,
      alignment: 'left',
      isEditing: false,
    } as TextNode);

    // Sección de notas
    nodes.push({
      id: uuidv4(),
      type: 'text',
      x: 50,
      y: 350,
      rotation: 0,
      scale: 1,
      zIndex: 1,
      locked: false,
      visible: true,
      opacity: 1,
      createdAt: now,
      modifiedAt: now,
      text: 'NOTAS:',
      fontFamily: 'System',
      fontSize: 16,
      fontWeight: 'bold',
      color: '#333333',
      backgroundColor: null,
      width: 100,
      height: 25,
      alignment: 'left',
      isEditing: false,
    } as TextNode);

    // Sección de acciones
    nodes.push({
      id: uuidv4(),
      type: 'text',
      x: 50,
      y: 550,
      rotation: 0,
      scale: 1,
      zIndex: 1,
      locked: false,
      visible: true,
      opacity: 1,
      createdAt: now,
      modifiedAt: now,
      text: 'ACCIONES PENDIENTES:',
      fontFamily: 'System',
      fontSize: 16,
      fontWeight: 'bold',
      color: '#333333',
      backgroundColor: null,
      width: 200,
      height: 25,
      alignment: 'left',
      isEditing: false,
    } as TextNode);

    return nodes;
  }

  /**
   * Crea nodos para método Cornell
   */
  private createCornellNotesNodes(): Node[] {
    // Implementación similar a meeting notes
    return [];
  }

  /**
   * Crea nodos para Bullet Journal
   */
  private createBulletJournalNodes(): Node[] {
    // Implementación con símbolos de bullet journal
    return [];
  }

  /**
   * Crea nodos para Kanban
   */
  private createKanbanNodes(): Node[] {
    // Tabla con 3 columnas: To Do, In Progress, Done
    return [];
  }

  /**
   * Crea nodos para planificador semanal
   */
  private createWeeklyPlannerNodes(): Node[] {
    // Tabla con 7 columnas (días) y filas para horas
    return [];
  }

  /**
   * Agrega una plantilla
   */
  addTemplate(template: Template): void {
    this.templates.set(template.id, template);
  }

  /**
   * Obtiene una plantilla por ID
   */
  getTemplate(id: string): Template | undefined {
    return this.templates.get(id);
  }

  /**
   * Lista plantillas con filtros
   */
  getTemplates(filter?: TemplateFilter): Template[] {
    let templates = Array.from(this.templates.values());

    if (filter) {
      if (filter.category) {
        templates = templates.filter((t) => t.category === filter.category);
      }

      if (filter.isPremium !== undefined) {
        templates = templates.filter((t) => t.isPremium === filter.isPremium);
      }

      if (filter.search) {
        const searchLower = filter.search.toLowerCase();
        templates = templates.filter(
          (t) =>
            t.name.toLowerCase().includes(searchLower) ||
            t.description.toLowerCase().includes(searchLower) ||
            t.tags.some((tag) => tag.toLowerCase().includes(searchLower))
        );
      }

      if (filter.tags && filter.tags.length > 0) {
        templates = templates.filter((t) =>
          filter.tags!.some((tag) => t.tags.includes(tag))
        );
      }

      // Ordenar
      if (filter.sortBy) {
        switch (filter.sortBy) {
          case 'popular':
            templates.sort((a, b) => b.downloads - a.downloads);
            break;
          case 'newest':
            templates.sort((a, b) => b.createdAt - a.createdAt);
            break;
          case 'rating':
            templates.sort((a, b) => b.rating - a.rating);
            break;
          case 'name':
            templates.sort((a, b) => a.name.localeCompare(b.name));
            break;
        }
      }
    }

    return templates;
  }

  /**
   * Obtiene categorías disponibles
   */
  getCategories(): TemplateCategory[] {
    const categories = new Set<TemplateCategory>();
    this.templates.forEach((t) => categories.add(t.category));
    return Array.from(categories);
  }

  /**
   * Crea un documento a partir de una plantilla
   */
  createFromTemplate(templateId: string): Document {
    const template = this.templates.get(templateId);
    if (!template) {
      throw new Error(`Template ${templateId} not found`);
    }

    // Incrementar contador de descargas
    template.downloads++;

    const now = Date.now();
    const document: Document = {
      id: uuidv4(),
      title: template.document.title || 'Nueva nota',
      pages: (template.document.pages || []).map((page) => ({
        ...page,
        id: uuidv4(),
        nodes: page.nodes?.map((node) => ({
          ...node,
          id: uuidv4(),
          createdAt: now,
          modifiedAt: now,
        })) || [],
        createdAt: now,
        modifiedAt: now,
      })),
      currentPageIndex: 0,
      tags: [...template.tags],
      favorite: false,
      createdAt: now,
      modifiedAt: now,
    };

    return document;
  }

  /**
   * Guarda una plantilla personalizada del usuario
   */
  async saveUserTemplate(document: Document, name: string, description: string): Promise<Template> {
    const template: Template = {
      id: `user-${uuidv4()}`,
      name,
      description,
      category: 'custom',
      isPremium: false,
      tags: ['custom', 'user-created'],
      createdAt: Date.now(),
      downloads: 0,
      rating: 0,
      document: {
        title: document.title,
        pages: document.pages,
      },
    };

    this.addTemplate(template);
    this.userTemplates.add(template.id);
    await this.saveUserTemplates();

    return template;
  }

  /**
   * Elimina una plantilla de usuario
   */
  async deleteUserTemplate(templateId: string): Promise<void> {
    if (!this.userTemplates.has(templateId)) {
      throw new Error('Cannot delete built-in template');
    }

    this.templates.delete(templateId);
    this.userTemplates.delete(templateId);
    this.favorites.delete(templateId);
    await this.saveUserTemplates();
  }

  /**
   * Guarda plantillas de usuario en storage
   */
  private async saveUserTemplates(): Promise<void> {
    const userTemplatesList = Array.from(this.userTemplates).map((id) =>
      this.templates.get(id)
    );
    await AsyncStorage.setItem(
      this.STORAGE_KEY,
      JSON.stringify(userTemplatesList)
    );
  }

  /**
   * Carga plantillas de usuario desde storage
   */
  private async loadUserTemplates(): Promise<void> {
    try {
      const data = await AsyncStorage.getItem(this.STORAGE_KEY);
      if (data) {
        const templates: Template[] = JSON.parse(data);
        templates.forEach((template) => {
          this.addTemplate(template);
          this.userTemplates.add(template.id);
        });
      }

      const favoritesData = await AsyncStorage.getItem(this.FAVORITES_KEY);
      if (favoritesData) {
        const favoritesList: string[] = JSON.parse(favoritesData);
        favoritesList.forEach((id) => this.favorites.add(id));
      }
    } catch (error) {
      console.error('Error loading user templates:', error);
    }
  }

  /**
   * Agrega/quita de favoritos
   */
  async toggleFavorite(templateId: string): Promise<boolean> {
    const isFavorite = this.favorites.has(templateId);
    
    if (isFavorite) {
      this.favorites.delete(templateId);
    } else {
      this.favorites.add(templateId);
    }

    await AsyncStorage.setItem(
      this.FAVORITES_KEY,
      JSON.stringify(Array.from(this.favorites))
    );

    return !isFavorite;
  }

  /**
   * Obtiene plantillas favoritas
   */
  getFavorites(): Template[] {
    return Array.from(this.favorites)
      .map((id) => this.templates.get(id))
      .filter((t): t is Template => t !== undefined);
  }

  /**
   * Obtiene estadísticas
   */
  getStats(): {
    total: number;
    premium: number;
    free: number;
    byCategory: Record<TemplateCategory, number>;
  } {
    const templates = Array.from(this.templates.values());
    const byCategory: Record<string, number> = {};

    templates.forEach((t) => {
      byCategory[t.category] = (byCategory[t.category] || 0) + 1;
    });

    return {
      total: templates.length,
      premium: templates.filter((t) => t.isPremium).length,
      free: templates.filter((t) => !t.isPremium).length,
      byCategory: byCategory as Record<TemplateCategory, number>,
    };
  }
}

export const templateService = new TemplateService();
export default TemplateService;
