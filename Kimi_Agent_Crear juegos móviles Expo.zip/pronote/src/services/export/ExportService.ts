/**
 * ProNote - Export Service
 * Exportación a múltiples formatos
 */

import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as Print from 'expo-print';
import { captureRef } from 'react-native-view-shot';
import { Document, Page } from '@types/index';
import { pdfService } from '../pdf/PDFService';

export type ExportFormat = 'pdf' | 'png' | 'jpg' | 'svg' | 'pronote' | 'txt' | 'md';

export interface ExportOptions {
  format: ExportFormat;
  quality?: 'low' | 'medium' | 'high';
  includeBackground?: boolean;
  pageRange?: 'all' | 'current' | { start: number; end: number };
  destination?: 'device' | 'share' | 'print' | 'cloud';
  filename?: string;
}

export interface ExportResult {
  success: boolean;
  uri?: string;
  error?: string;
  fileSize?: number;
}

class ExportService {
  /**
   * Exporta un documento
   */
  async exportDocument(
    document: Document,
    options: ExportOptions
  ): Promise<ExportResult> {
    try {
      let uri: string;

      switch (options.format) {
        case 'pdf':
          uri = await this.exportToPDF(document, options);
          break;
        case 'png':
        case 'jpg':
          uri = await this.exportToImage(document, options);
          break;
        case 'svg':
          uri = await this.exportToSVG(document, options);
          break;
        case 'pronote':
          uri = await this.exportToProNote(document, options);
          break;
        case 'txt':
          uri = await this.exportToText(document, options);
          break;
        case 'md':
          uri = await this.exportToMarkdown(document, options);
          break;
        default:
          throw new Error(`Unsupported format: ${options.format}`);
      }

      // Manejar destino
      if (options.destination === 'share') {
        await Sharing.shareAsync(uri, {
          mimeType: this.getMimeType(options.format),
          dialogTitle: `Compartir ${document.title}`,
        });
      } else if (options.destination === 'print') {
        await Print.printAsync({ uri });
      }

      const fileInfo = await FileSystem.getInfoAsync(uri);

      return {
        success: true,
        uri,
        fileSize: fileInfo.exists ? fileInfo.size : 0,
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message,
      };
    }
  }

  /**
   * Exporta a PDF
   */
  private async exportToPDF(
    document: Document,
    options: ExportOptions
  ): Promise<string> {
    return await pdfService.exportToPDF(document, {
      quality: options.quality,
      includeBackground: options.includeBackground,
    });
  }

  /**
   * Exporta a imagen
   */
  private async exportToImage(
    document: Document,
    options: ExportOptions
  ): Promise<string> {
    // En implementación real, renderizaría el canvas y capturaría
    // Por ahora, placeholder
    const extension = options.format === 'jpg' ? 'jpg' : 'png';
    const outputPath = FileSystem.cacheDirectory + `${document.id}.${extension}`;
    return outputPath;
  }

  /**
   * Exporta a SVG
   */
  private async exportToSVG(
    document: Document,
    options: ExportOptions
  ): Promise<string> {
    const svgContent = this.generateSVG(document, options);
    const outputPath = FileSystem.cacheDirectory + `${document.id}.svg`;
    
    await FileSystem.writeAsStringAsync(outputPath, svgContent);
    return outputPath;
  }

  /**
   * Genera SVG del documento
   */
  private generateSVG(document: Document, options: ExportOptions): string {
    const page = document.pages[0]; // Simplificado
    
    let svg = `<?xml version="1.0" encoding="UTF-8"?>`;
    svg += `<svg width="800" height="1200" xmlns="http://www.w3.org/2000/svg">`;
    
    // Fondo
    if (options.includeBackground !== false) {
      svg += `<rect width="100%" height="100%" fill="${page.background.color}"/>`;
    }
    
    // Nodos
    page.nodes.forEach((node) => {
      // Simplificado - en producción, convertir cada nodo a SVG
    });
    
    svg += `</svg>`;
    return svg;
  }

  /**
   * Exporta a formato ProNote nativo
   */
  private async exportToProNote(
    document: Document,
    options: ExportOptions
  ): Promise<string> {
    const exportData = {
      version: '2.0',
      format: 'pronote',
      exportedAt: Date.now(),
      document,
    };

    const outputPath = FileSystem.cacheDirectory + `${document.id}.pronote`;
    
    await FileSystem.writeAsStringAsync(
      outputPath,
      JSON.stringify(exportData, null, 2)
    );

    return outputPath;
  }

  /**
   * Exporta a texto plano
   */
  private async exportToText(
    document: Document,
    options: ExportOptions
  ): Promise<string> {
    let text = `${document.title}\n`;
    text += `${'='.repeat(document.title.length)}\n\n`;

    document.pages.forEach((page, index) => {
      text += `--- Página ${index + 1} ---\n\n`;
      
      page.nodes.forEach((node) => {
        if (node.type === 'text') {
          text += (node as any).text + '\n\n';
        }
      });
    });

    const outputPath = FileSystem.cacheDirectory + `${document.id}.txt`;
    await FileSystem.writeAsStringAsync(outputPath, text);
    
    return outputPath;
  }

  /**
   * Exporta a Markdown
   */
  private async exportToMarkdown(
    document: Document,
    options: ExportOptions
  ): Promise<string> {
    let md = `# ${document.title}\n\n`;

    document.pages.forEach((page, index) => {
      md += `## ${page.name}\n\n`;
      
      page.nodes.forEach((node) => {
        if (node.type === 'text') {
          md += (node as any).text + '\n\n';
        } else if (node.type === 'image') {
          md += `![Imagen](${(node as any).uri})\n\n`;
        }
      });
    });

    const outputPath = FileSystem.cacheDirectory + `${document.id}.md`;
    await FileSystem.writeAsStringAsync(outputPath, md);
    
    return outputPath;
  }

  /**
   * Obtiene MIME type
   */
  private getMimeType(format: ExportFormat): string {
    const mimeTypes: Record<ExportFormat, string> = {
      pdf: 'application/pdf',
      png: 'image/png',
      jpg: 'image/jpeg',
      svg: 'image/svg+xml',
      pronote: 'application/json',
      txt: 'text/plain',
      md: 'text/markdown',
    };
    return mimeTypes[format];
  }

  /**
   * Batch export
   */
  async batchExport(
    documents: Document[],
    options: ExportOptions
  ): Promise<ExportResult[]> {
    const results: ExportResult[] = [];
    
    for (const doc of documents) {
      const result = await this.exportDocument(doc, options);
      results.push(result);
    }
    
    return results;
  }
}

export const exportService = new ExportService();
export default ExportService;
