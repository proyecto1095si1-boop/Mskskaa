/**
 * ProNote - PDF Service
 * Exportación e importación avanzada de documentos PDF
 */

import * as FileSystem from 'expo-file-system';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { PDFDocument, PDFPage, rgb, StandardFonts } from 'pdf-lib';
import { Skia, SkImage } from '@shopify/react-native-skia';
import { Document, Page, Node, isInkNode, isTextNode, isImageNode } from '@types/index';

export interface PDFExportOptions {
  includeBackground?: boolean;
  quality?: 'low' | 'medium' | 'high';
  pageSize?: 'A4' | 'Letter' | 'Legal' | 'A3' | 'A5';
  orientation?: 'portrait' | 'landscape';
  margin?: { top: number; right: number; bottom: number; left: number };
  compression?: boolean;
  password?: string;
  metadata?: {
    title?: string;
    author?: string;
    subject?: string;
    keywords?: string[];
    creator?: string;
  };
}

export interface PDFImportOptions {
  extractImages?: boolean;
  extractText?: boolean;
  ocrEnabled?: boolean;
  pageRange?: { start: number; end: number };
}

export interface PDFImportResult {
  pages: Array<{
    index: number;
    imageUri?: string;
    text?: string;
    width: number;
    height: number;
  }>;
  metadata: {
    title?: string;
    author?: string;
    pageCount: number;
  };
}

export interface PDFAnnotation {
  type: 'highlight' | 'underline' | 'strikeout' | 'squiggly' | 'ink' | 'text';
  page: number;
  bbox: { x: number; y: number; width: number; height: number };
  color?: string;
  content?: string;
  author?: string;
  date?: Date;
}

class PDFService {
  private pageSizes: Record<string, { width: number; height: number }> = {
    A4: { width: 595.28, height: 841.89 },
    Letter: { width: 612, height: 792 },
    Legal: { width: 612, height: 1008 },
    A3: { width: 841.89, height: 1190.55 },
    A5: { width: 419.53, height: 595.28 },
  };

  /**
   * Exporta un documento ProNote a PDF
   */
  async exportToPDF(
    document: Document,
    options: PDFExportOptions = {}
  ): Promise<string> {
    const {
      pageSize = 'A4',
      orientation = 'portrait',
      includeBackground = true,
      quality = 'high',
      margin = { top: 20, right: 20, bottom: 20, left: 20 },
      compression = true,
      password,
      metadata = {},
    } = options;

    try {
      // Crear nuevo documento PDF
      const pdfDoc = await PDFDocument.create();

      // Configurar metadatos
      if (metadata.title) pdfDoc.setTitle(metadata.title);
      if (metadata.author) pdfDoc.setAuthor(metadata.author);
      if (metadata.subject) pdfDoc.setSubject(metadata.subject);
      if (metadata.keywords) pdfDoc.setKeywords(metadata.keywords);
      if (metadata.creator) pdfDoc.setCreator(metadata.creator);

      // Configurar protección con contraseña si se especifica
      if (password) {
        // Nota: pdf-lib no soporta encriptación directamente
        // Se necesitaría usar una librería adicional como qpdf
      }

      // Obtener tamaño de página
      let { width, height } = this.pageSizes[pageSize];
      if (orientation === 'landscape') {
        [width, height] = [height, width];
      }

      // Procesar cada página del documento
      for (const page of document.pages) {
        const pdfPage = pdfDoc.addPage([width, height]);

        // Dibujar fondo si se solicita
        if (includeBackground && page.background.type !== 'blank') {
          await this.drawBackground(pdfPage, page.background, width, height);
        }

        // Dibujar nodos
        for (const node of page.nodes) {
          await this.drawNode(pdfPage, node, margin);
        }
      }

      // Guardar PDF
      const pdfBytes = await pdfDoc.save({
        useObjectStreams: compression,
        addDefaultPage: false,
      });

      // Guardar archivo
      const outputPath = FileSystem.cacheDirectory + `${document.id}.pdf`;
      await FileSystem.writeAsStringAsync(
        outputPath,
        Buffer.from(pdfBytes).toString('base64'),
        { encoding: FileSystem.EncodingType.Base64 }
      );

      return outputPath;
    } catch (error) {
      console.error('Error exporting to PDF:', error);
      throw error;
    }
  }

  /**
   * Importa un PDF como documento ProNote
   */
  async importFromPDF(
    pdfUri: string,
    options: PDFImportOptions = {}
  ): Promise<PDFImportResult> {
    const {
      extractImages = true,
      extractText = true,
      pageRange,
    } = options;

    try {
      // Leer archivo PDF
      const pdfBase64 = await FileSystem.readAsStringAsync(pdfUri, {
        encoding: FileSystem.EncodingType.Base64,
      });

      const pdfBytes = Buffer.from(pdfBase64, 'base64');
      const pdfDoc = await PDFDocument.load(pdfBytes);

      const pages: PDFImportResult['pages'] = [];
      const pdfPages = pdfDoc.getPages();

      // Determinar rango de páginas a procesar
      const startPage = pageRange?.start || 0;
      const endPage = pageRange?.end || pdfPages.length;

      for (let i = startPage; i < Math.min(endPage, pdfPages.length); i++) {
        const pdfPage = pdfPages[i];
        const { width, height } = pdfPage.getSize();

        const pageResult: PDFImportResult['pages'][0] = {
          index: i,
          width,
          height,
        };

        // Extraer texto si se solicita
        if (extractText) {
          // Nota: pdf-lib no extrae texto directamente
          // Se necesitaría usar pdfjs-dist o similar
          pageResult.text = '';
        }

        // Renderizar página como imagen
        if (extractImages) {
          // En producción, usaría react-native-pdf o pdf-renderer
          // para convertir la página a imagen
          pageResult.imageUri = '';
        }

        pages.push(pageResult);
      }

      // Extraer metadatos
      const metadata = {
        title: pdfDoc.getTitle() || undefined,
        author: pdfDoc.getAuthor() || undefined,
        pageCount: pdfPages.length,
      };

      return { pages, metadata };
    } catch (error) {
      console.error('Error importing PDF:', error);
      throw error;
    }
  }

  /**
   * Fusiona múltiples PDFs en uno solo
   */
  async mergePDFs(pdfUris: string[]): Promise<string> {
    try {
      const mergedPdf = await PDFDocument.create();

      for (const uri of pdfUris) {
        const pdfBase64 = await FileSystem.readAsStringAsync(uri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        const pdfBytes = Buffer.from(pdfBase64, 'base64');
        const pdf = await PDFDocument.load(pdfBytes);
        
        const pages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
        pages.forEach((page) => mergedPdf.addPage(page));
      }

      const mergedBytes = await mergedPdf.save();
      const outputPath = FileSystem.cacheDirectory + `merged_${Date.now()}.pdf`;
      
      await FileSystem.writeAsStringAsync(
        outputPath,
        Buffer.from(mergedBytes).toString('base64'),
        { encoding: FileSystem.EncodingType.Base64 }
      );

      return outputPath;
    } catch (error) {
      console.error('Error merging PDFs:', error);
      throw error;
    }
  }

  /**
   * Divide un PDF en páginas individuales
   */
  async splitPDF(pdfUri: string): Promise<string[]> {
    try {
      const pdfBase64 = await FileSystem.readAsStringAsync(pdfUri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      const pdfBytes = Buffer.from(pdfBase64, 'base64');
      const pdfDoc = await PDFDocument.load(pdfBytes);

      const outputPaths: string[] = [];
      const pages = pdfDoc.getPages();

      for (let i = 0; i < pages.length; i++) {
        const newPdf = await PDFDocument.create();
        const [page] = await newPdf.copyPages(pdfDoc, [i]);
        newPdf.addPage(page);

        const bytes = await newPdf.save();
        const outputPath = FileSystem.cacheDirectory + `page_${i + 1}.pdf`;
        
        await FileSystem.writeAsStringAsync(
          outputPath,
          Buffer.from(bytes).toString('base64'),
          { encoding: FileSystem.EncodingType.Base64 }
        );

        outputPaths.push(outputPath);
      }

      return outputPaths;
    } catch (error) {
      console.error('Error splitting PDF:', error);
      throw error;
    }
  }

  /**
   * Agrega anotaciones a un PDF existente
   */
  async addAnnotations(pdfUri: string, annotations: PDFAnnotation[]): Promise<string> {
    try {
      const pdfBase64 = await FileSystem.readAsStringAsync(pdfUri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      const pdfBytes = Buffer.from(pdfBase64, 'base64');
      const pdfDoc = await PDFDocument.load(pdfBytes);

      // Nota: pdf-lib tiene soporte limitado para anotaciones
      // Para anotaciones avanzadas, se necesitaría una librería más completa

      const outputBytes = await pdfDoc.save();
      const outputPath = FileSystem.cacheDirectory + `annotated_${Date.now()}.pdf`;
      
      await FileSystem.writeAsStringAsync(
        outputPath,
        Buffer.from(outputBytes).toString('base64'),
        { encoding: FileSystem.EncodingType.Base64 }
      );

      return outputPath;
    } catch (error) {
      console.error('Error adding annotations:', error);
      throw error;
    }
  }

  /**
   * Comprime un PDF
   */
  async compressPDF(pdfUri: string, quality: 'low' | 'medium' | 'high' = 'medium'): Promise<string> {
    try {
      const pdfBase64 = await FileSystem.readAsStringAsync(pdfUri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      const pdfBytes = Buffer.from(pdfBase64, 'base64');
      const pdfDoc = await PDFDocument.load(pdfBytes);

      // Configurar compresión según calidad
      const compressionLevel = {
        low: 9,
        medium: 6,
        high: 3,
      }[quality];

      const compressedBytes = await pdfDoc.save({
        useObjectStreams: true,
        addDefaultPage: false,
      });

      const outputPath = FileSystem.cacheDirectory + `compressed_${Date.now()}.pdf`;
      
      await FileSystem.writeAsStringAsync(
        outputPath,
        Buffer.from(compressedBytes).toString('base64'),
        { encoding: FileSystem.EncodingType.Base64 }
      );

      return outputPath;
    } catch (error) {
      console.error('Error compressing PDF:', error);
      throw error;
    }
  }

  /**
   * Obtiene información de un PDF
   */
  async getPDFInfo(pdfUri: string): Promise<{
    pageCount: number;
    title?: string;
    author?: string;
    subject?: string;
    creator?: string;
    creationDate?: Date;
    modificationDate?: Date;
    fileSize: number;
  }> {
    try {
      const fileInfo = await FileSystem.getInfoAsync(pdfUri);
      const pdfBase64 = await FileSystem.readAsStringAsync(pdfUri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      const pdfBytes = Buffer.from(pdfBase64, 'base64');
      const pdfDoc = await PDFDocument.load(pdfBytes);

      return {
        pageCount: pdfDoc.getPageCount(),
        title: pdfDoc.getTitle() || undefined,
        author: pdfDoc.getAuthor() || undefined,
        subject: pdfDoc.getSubject() || undefined,
        creator: pdfDoc.getCreator() || undefined,
        creationDate: pdfDoc.getCreationDate() || undefined,
        modificationDate: pdfDoc.getModificationDate() || undefined,
        fileSize: fileInfo.exists ? fileInfo.size : 0,
      };
    } catch (error) {
      console.error('Error getting PDF info:', error);
      throw error;
    }
  }

  /**
   * Dibuja el fondo de una página
   */
  private async drawBackground(
    pdfPage: PDFPage,
    background: Page['background'],
    width: number,
    height: number
  ): Promise<void> {
    const { drawLine, drawRectangle } = pdfPage;

    switch (background.type) {
      case 'lined':
        // Dibujar líneas horizontales
        for (let y = background.lineSpacing; y < height; y += background.lineSpacing) {
          drawLine({
            start: { x: 0, y },
            end: { x: width, y },
            thickness: 0.5,
            color: rgb(0.9, 0.9, 0.9),
          });
        }
        break;

      case 'grid':
        // Dibujar cuadrícula
        for (let x = 0; x < width; x += background.lineSpacing) {
          drawLine({
            start: { x, y: 0 },
            end: { x, y: height },
            thickness: 0.5,
            color: rgb(0.9, 0.9, 0.9),
          });
        }
        for (let y = 0; y < height; y += background.lineSpacing) {
          drawLine({
            start: { x: 0, y },
            end: { x: width, y },
            thickness: 0.5,
            color: rgb(0.9, 0.9, 0.9),
          });
        }
        break;

      case 'dotted':
        // Dibujar puntos
        for (let x = 0; x < width; x += background.lineSpacing) {
          for (let y = 0; y < height; y += background.lineSpacing) {
            drawRectangle({
              x: x - 1,
              y: y - 1,
              width: 2,
              height: 2,
              color: rgb(0.8, 0.8, 0.8),
            });
          }
        }
        break;
    }
  }

  /**
   * Dibuja un nodo en el PDF
   */
  private async drawNode(
    pdfPage: PDFPage,
    node: Node,
    margin: { top: number; right: number; bottom: number; left: number }
  ): Promise<void> {
    if (isInkNode(node)) {
      // Dibujar trazos de tinta
      for (const stroke of node.strokes) {
        // Convertir path SVG a líneas del PDF
        // Esta es una simplificación - en producción se necesitaría
        // parsear el path SVG y convertirlo a comandos PDF
      }
    } else if (isTextNode(node)) {
      // Dibujar texto
      // Nota: Se necesitaría cargar la fuente apropiada
    } else if (isImageNode(node)) {
      // Incrustar imagen
      try {
        const imageBase64 = await FileSystem.readAsStringAsync(node.uri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        // Incrustar en PDF según el tipo de imagen
      } catch (error) {
        console.warn('Could not embed image:', error);
      }
    }
  }

  /**
   * Comparte un PDF
   */
  async sharePDF(pdfUri: string, title?: string): Promise<void> {
    try {
      await Sharing.shareAsync(pdfUri, {
        mimeType: 'application/pdf',
        dialogTitle: title || 'Compartir PDF',
        UTI: 'com.adobe.pdf',
      });
    } catch (error) {
      console.error('Error sharing PDF:', error);
      throw error;
    }
  }

  /**
   * Imprime un PDF
   */
  async printPDF(pdfUri: string, options?: Print.PrintOptions): Promise<void> {
    try {
      await Print.printAsync({
        uri: pdfUri,
        ...options,
      });
    } catch (error) {
      console.error('Error printing PDF:', error);
      throw error;
    }
  }
}

export const pdfService = new PDFService();
export default PDFService;
