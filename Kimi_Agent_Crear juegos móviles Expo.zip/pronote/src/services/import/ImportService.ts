/**
 * ProNote - Import Service
 * Importación desde múltiples fuentes y formatos
 */

import * as FileSystem from 'expo-file-system';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { Document, Page } from '@types/index';
import { pdfService } from '../pdf/PDFService';
import { ocrService } from '../ocr/OCRService';
import { v4 as uuidv4 } from 'uuid';

export type ImportSource = 'device' | 'camera' | 'cloud' | 'clipboard';
export type ImportFormat = 'pdf' | 'image' | 'pronote' | 'txt' | 'md' | 'docx';

export interface ImportOptions {
  source: ImportSource;
  format?: ImportFormat;
  ocrEnabled?: boolean;
  extractPages?: boolean;
  createNewDocument?: boolean;
}

export interface ImportResult {
  success: boolean;
  document?: Document;
  documents?: Document[];
  error?: string;
  importedPages?: number;
}

class ImportService {
  /**
   * Importa desde el dispositivo
   */
  async importFromDevice(options: ImportOptions): Promise<ImportResult> {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: this.getMimeTypes(options.format),
        copyToCacheDirectory: true,
      });

      if (result.canceled) {
        return { success: false, error: 'User cancelled' };
      }

      const file = result.assets[0];
      return await this.processFile(file.uri, file.name, options);
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Importa desde cámara
   */
  async importFromCamera(options: ImportOptions): Promise<ImportResult> {
    try {
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 1,
        allowsEditing: true,
      });

      if (result.canceled) {
        return { success: false, error: 'User cancelled' };
      }

      const image = result.assets[0];
      return await this.processImage(image.uri, options);
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Importa desde galería
   */
  async importFromGallery(options: ImportOptions): Promise<ImportResult> {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 1,
        allowsMultipleSelection: true,
      });

      if (result.canceled) {
        return { success: false, error: 'User cancelled' };
      }

      const documents: Document[] = [];

      for (const image of result.assets) {
        const importResult = await this.processImage(image.uri, options);
        if (importResult.success && importResult.document) {
          documents.push(importResult.document);
        }
      }

      return {
        success: true,
        documents,
        importedPages: documents.reduce((sum, d) => sum + d.pages.length, 0),
      };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Procesa un archivo
   */
  private async processFile(
    uri: string,
    fileName: string,
    options: ImportOptions
  ): Promise<ImportResult> {
    const extension = fileName.split('.').pop()?.toLowerCase();

    switch (extension) {
      case 'pdf':
        return await this.importPDF(uri, options);
      case 'pronote':
      case 'json':
        return await this.importProNote(uri, options);
      case 'txt':
        return await this.importText(uri, options);
      case 'md':
      case 'markdown':
        return await this.importMarkdown(uri, options);
      case 'png':
      case 'jpg':
      case 'jpeg':
        return await this.processImage(uri, options);
      default:
        return { success: false, error: `Unsupported format: ${extension}` };
    }
  }

  /**
   * Importa PDF
   */
  private async importPDF(uri: string, options: ImportOptions): Promise<ImportResult> {
    try {
      const pdfResult = await pdfService.importFromPDF(uri, {
        extractImages: true,
        extractText: options.ocrEnabled,
      });

      const document: Document = {
        id: uuidv4(),
        title: `Imported PDF ${new Date().toLocaleDateString()}`,
        pages: pdfResult.pages.map((page, index) => ({
          id: uuidv4(),
          name: `Page ${index + 1}`,
          nodes: [],
          background: {
            type: 'blank',
            color: '#FFFFFF',
            lineColor: '#E0E0E0',
            lineSpacing: 30,
          },
          thumbnail: page.imageUri || null,
          createdAt: Date.now(),
          modifiedAt: Date.now(),
        })),
        currentPageIndex: 0,
        tags: ['imported', 'pdf'],
        favorite: false,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
      };

      return {
        success: true,
        document,
        importedPages: document.pages.length,
      };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Procesa imagen
   */
  private async processImage(uri: string, options: ImportOptions): Promise<ImportResult> {
    try {
      // Copiar imagen a directorio de la app
      const fileName = `imported_${Date.now()}.png`;
      const destPath = FileSystem.documentDirectory + 'images/' + fileName;

      await FileSystem.copyAsync({
        from: uri,
        to: destPath,
      });

      // Realizar OCR si está habilitado
      let extractedText = '';
      if (options.ocrEnabled) {
        const ocrResult = await ocrService.recognize(uri);
        extractedText = ocrResult.text;
      }

      const page: Page = {
        id: uuidv4(),
        name: 'Page 1',
        nodes: [
          {
            id: uuidv4(),
            type: 'image',
            x: 50,
            y: 50,
            rotation: 0,
            scale: 1,
            zIndex: 1,
            locked: false,
            visible: true,
            opacity: 1,
            createdAt: Date.now(),
            modifiedAt: Date.now(),
            uri: destPath,
            fileName,
            aspectRatio: 1,
            width: 400,
            height: 400,
            originalWidth: 400,
            originalHeight: 400,
          } as any,
          ...(extractedText ? [{
            id: uuidv4(),
            type: 'text',
            x: 50,
            y: 500,
            rotation: 0,
            scale: 1,
            zIndex: 2,
            locked: false,
            visible: true,
            opacity: 1,
            createdAt: Date.now(),
            modifiedAt: Date.now(),
            text: extractedText,
            fontFamily: 'System',
            fontSize: 14,
            fontWeight: 'normal',
            color: '#333333',
            backgroundColor: null,
            width: 400,
            height: 200,
            alignment: 'left',
            isEditing: false,
          } as any] : []),
        ],
        background: {
          type: 'blank',
          color: '#FFFFFF',
          lineColor: '#E0E0E0',
          lineSpacing: 30,
        },
        thumbnail: null,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
      };

      const document: Document = {
        id: uuidv4(),
        title: `Imported Image ${new Date().toLocaleDateString()}`,
        pages: [page],
        currentPageIndex: 0,
        tags: ['imported', 'image'],
        favorite: false,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
      };

      return {
        success: true,
        document,
        importedPages: 1,
      };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Importa formato ProNote
   */
  private async importProNote(uri: string, options: ImportOptions): Promise<ImportResult> {
    try {
      const content = await FileSystem.readAsStringAsync(uri);
      const data = JSON.parse(content);

      if (data.format !== 'pronote' && !data.documents) {
        return { success: false, error: 'Invalid ProNote file' };
      }

      const document: Document = data.document || data;

      // Regenerar IDs para evitar conflictos
      document.id = uuidv4();
      document.pages.forEach((page: Page) => {
        page.id = uuidv4();
        page.nodes.forEach((node: any) => {
          node.id = uuidv4();
        });
      });

      return {
        success: true,
        document,
        importedPages: document.pages.length,
      };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Importa texto plano
   */
  private async importText(uri: string, options: ImportOptions): Promise<ImportResult> {
    try {
      const content = await FileSystem.readAsStringAsync(uri);

      const page: Page = {
        id: uuidv4(),
        name: 'Page 1',
        nodes: [
          {
            id: uuidv4(),
            type: 'text',
            x: 50,
            y: 50,
            rotation: 0,
            scale: 1,
            zIndex: 1,
            locked: false,
            visible: true,
            opacity: 1,
            createdAt: Date.now(),
            modifiedAt: Date.now(),
            text: content,
            fontFamily: 'System',
            fontSize: 14,
            fontWeight: 'normal',
            color: '#333333',
            backgroundColor: null,
            width: 500,
            height: 800,
            alignment: 'left',
            isEditing: false,
          } as any,
        ],
        background: {
          type: 'blank',
          color: '#FFFFFF',
          lineColor: '#E0E0E0',
          lineSpacing: 30,
        },
        thumbnail: null,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
      };

      const document: Document = {
        id: uuidv4(),
        title: `Imported Text ${new Date().toLocaleDateString()}`,
        pages: [page],
        currentPageIndex: 0,
        tags: ['imported', 'text'],
        favorite: false,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
      };

      return {
        success: true,
        document,
        importedPages: 1,
      };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Importa Markdown
   */
  private async importMarkdown(uri: string, options: ImportOptions): Promise<ImportResult> {
    try {
      const content = await FileSystem.readAsStringAsync(uri);

      // Parsear markdown básico
      const lines = content.split('\n');
      const nodes: any[] = [];
      let y = 50;

      lines.forEach((line) => {
        if (line.startsWith('# ')) {
          nodes.push({
            id: uuidv4(),
            type: 'text',
            x: 50,
            y,
            rotation: 0,
            scale: 1,
            zIndex: 1,
            locked: false,
            visible: true,
            opacity: 1,
            createdAt: Date.now(),
            modifiedAt: Date.now(),
            text: line.replace('# ', ''),
            fontFamily: 'System',
            fontSize: 24,
            fontWeight: 'bold',
            color: '#333333',
            backgroundColor: null,
            width: 500,
            height: 40,
            alignment: 'left',
            isEditing: false,
          });
          y += 50;
        } else if (line.startsWith('## ')) {
          nodes.push({
            id: uuidv4(),
            type: 'text',
            x: 50,
            y,
            rotation: 0,
            scale: 1,
            zIndex: 1,
            locked: false,
            visible: true,
            opacity: 1,
            createdAt: Date.now(),
            modifiedAt: Date.now(),
            text: line.replace('## ', ''),
            fontFamily: 'System',
            fontSize: 20,
            fontWeight: 'bold',
            color: '#333333',
            backgroundColor: null,
            width: 500,
            height: 35,
            alignment: 'left',
            isEditing: false,
          });
          y += 45;
        } else if (line.trim()) {
          nodes.push({
            id: uuidv4(),
            type: 'text',
            x: 50,
            y,
            rotation: 0,
            scale: 1,
            zIndex: 1,
            locked: false,
            visible: true,
            opacity: 1,
            createdAt: Date.now(),
            modifiedAt: Date.now(),
            text: line,
            fontFamily: 'System',
            fontSize: 14,
            fontWeight: 'normal',
            color: '#333333',
            backgroundColor: null,
            width: 500,
            height: 25,
            alignment: 'left',
            isEditing: false,
          });
          y += 30;
        }
      });

      const page: Page = {
        id: uuidv4(),
        name: 'Page 1',
        nodes,
        background: {
          type: 'blank',
          color: '#FFFFFF',
          lineColor: '#E0E0E0',
          lineSpacing: 30,
        },
        thumbnail: null,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
      };

      const document: Document = {
        id: uuidv4(),
        title: `Imported Markdown ${new Date().toLocaleDateString()}`,
        pages: [page],
        currentPageIndex: 0,
        tags: ['imported', 'markdown'],
        favorite: false,
        createdAt: Date.now(),
        modifiedAt: Date.now(),
      };

      return {
        success: true,
        document,
        importedPages: 1,
      };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Obtiene MIME types soportados
   */
  private getMimeTypes(format?: ImportFormat): string[] {
    if (format) {
      const mimeMap: Record<ImportFormat, string[]> = {
        pdf: ['application/pdf'],
        image: ['image/png', 'image/jpeg', 'image/jpg'],
        pronote: ['application/json', '*/*'],
        txt: ['text/plain'],
        md: ['text/markdown', 'text/plain'],
        docx: ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
      };
      return mimeMap[format];
    }

    return ['*/*'];
  }
}

export const importService = new ImportService();
export default ImportService;
