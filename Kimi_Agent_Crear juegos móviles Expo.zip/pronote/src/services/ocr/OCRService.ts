/**
 * ProNote - OCR Service
 * Reconocimiento óptico de caracteres para notas manuscritas e impresas
 */

import * as FileSystem from 'expo-file-system';
import { createWorker, Worker } from 'tesseract.js';
import { Skia, SkImage } from '@shopify/react-native-skia';

export interface OCROptions {
  language?: string;
  whitelist?: string;
  blacklist?: string;
  psm?: number; // Page Segmentation Mode
  oem?: number; // OCR Engine Mode
}

export interface OCRResult {
  text: string;
  confidence: number;
  words: Array<{
    text: string;
    confidence: number;
    bbox: { x: number; y: number; width: number; height: number };
  }>;
  lines: Array<{
    text: string;
    bbox: { x: number; y: number; width: number; height: number };
  }>;
}

export interface HandwritingRecognitionResult {
  text: string;
  confidence: number;
  alternatives: string[];
}

class OCRService {
  private worker: Worker | null = null;
  private isInitialized: boolean = false;
  private supportedLanguages: string[] = ['eng', 'spa', 'fra', 'deu', 'ita', 'por', 'rus', 'chi_sim', 'jpn', 'kor', 'ara'];

  /**
   * Inicializa el worker de Tesseract
   */
  async initialize(language: string = 'eng'): Promise<void> {
    if (this.isInitialized) return;

    try {
      this.worker = await createWorker(language);
      this.isInitialized = true;
    } catch (error) {
      console.error('Error initializing OCR:', error);
      throw new Error('Failed to initialize OCR service');
    }
  }

  /**
   * Reconoce texto en una imagen
   */
  async recognize(imageUri: string, options: OCROptions = {}): Promise<OCRResult> {
    if (!this.isInitialized) {
      await this.initialize(options.language || 'eng');
    }

    try {
      // Verificar que el archivo existe
      const fileInfo = await FileSystem.getInfoAsync(imageUri);
      if (!fileInfo.exists) {
        throw new Error('Image file not found');
      }

      // Configurar opciones
      if (options.psm) {
        await this.worker?.setParameters({
          tessedit_pageseg_mode: options.psm.toString(),
        });
      }

      // Realizar OCR
      const result = await this.worker?.recognize(imageUri);

      if (!result) {
        throw new Error('OCR recognition failed');
      }

      return {
        text: result.data.text,
        confidence: result.data.confidence,
        words: result.data.words.map((word) => ({
          text: word.text,
          confidence: word.confidence,
          bbox: {
            x: word.bbox.x0,
            y: word.bbox.y0,
            width: word.bbox.x1 - word.bbox.x0,
            height: word.bbox.y1 - word.bbox.y0,
          },
        })),
        lines: result.data.lines.map((line) => ({
          text: line.text,
          bbox: {
            x: line.bbox.x0,
            y: line.bbox.y0,
            width: line.bbox.x1 - line.bbox.x0,
            height: line.bbox.y1 - line.bbox.y0,
          },
        })),
      };
    } catch (error) {
      console.error('OCR recognition error:', error);
      throw error;
    }
  }

  /**
   * Reconoce texto manuscrito usando modelo especializado
   * Nota: Requiere backend o modelo local más avanzado
   */
  async recognizeHandwriting(imageUri: string): Promise<HandwritingRecognitionResult> {
    // Implementación simplificada - en producción usaría un modelo específico
    // como MyScript, Google Cloud Vision, o Azure Ink Recognizer
    
    try {
      const result = await this.recognize(imageUri, {
        psm: 6, // Assume a single uniform block of text
      });

      return {
        text: result.text,
        confidence: result.confidence,
        alternatives: [], // En implementación real, obtendría alternativas
      };
    } catch (error) {
      console.error('Handwriting recognition error:', error);
      throw error;
    }
  }

  /**
   * Extrae texto de un área específica de la imagen
   */
  async recognizeRegion(
    imageUri: string,
    region: { x: number; y: number; width: number; height: number },
    options: OCROptions = {}
  ): Promise<OCRResult> {
    try {
      // Recortar la región de interés
      const croppedUri = await this.cropImage(imageUri, region);
      
      // Realizar OCR en la región recortada
      const result = await this.recognize(croppedUri, options);
      
      // Limpiar archivo temporal
      await FileSystem.deleteAsync(croppedUri, { idempotent: true });
      
      return result;
    } catch (error) {
      console.error('Region OCR error:', error);
      throw error;
    }
  }

  /**
   * Busca texto en la imagen
   */
  async searchText(imageUri: string, searchTerm: string): Promise<Array<{
    text: string;
    confidence: number;
    bbox: { x: number; y: number; width: number; height: number };
  }>> {
    try {
      const result = await this.recognize(imageUri);
      
      const matches = result.words.filter((word) =>
        word.text.toLowerCase().includes(searchTerm.toLowerCase())
      );
      
      return matches;
    } catch (error) {
      console.error('Text search error:', error);
      throw error;
    }
  }

  /**
   * Cambia el idioma del OCR
   */
  async setLanguage(language: string): Promise<void> {
    if (!this.supportedLanguages.includes(language)) {
      throw new Error(`Language ${language} not supported`);
    }

    if (this.worker) {
      await this.worker.loadLanguage(language);
      await this.worker.initialize(language);
    }
  }

  /**
   * Obtiene los idiomas soportados
   */
  getSupportedLanguages(): string[] {
    return this.supportedLanguages;
  }

  /**
   * Libera recursos
   */
  async terminate(): Promise<void> {
    if (this.worker) {
      await this.worker.terminate();
      this.worker = null;
      this.isInitialized = false;
    }
  }

  /**
   * Recorta una región de una imagen usando Skia
   */
  private async cropImage(
    imageUri: string,
    region: { x: number; y: number; width: number; height: number }
  ): Promise<string> {
    // Implementación usando Skia para recortar
    // En producción, esto usaría react-native-image-crop-picker o similar
    
    const tempPath = FileSystem.cacheDirectory + `cropped_${Date.now()}.png`;
    
    // Por ahora, simplemente copiamos la imagen completa
    // La implementación completa requeriría procesamiento de imagen
    await FileSystem.copyAsync({
      from: imageUri,
      to: tempPath,
    });
    
    return tempPath;
  }

  /**
   * Convierte texto manuscrito a texto digital (Ink to Text)
   * Usa algoritmos de reconocimiento de patrones
   */
  async inkToText(strokes: Array<{
    points: Array<{ x: number; y: number }>;
  }>): Promise<string> {
    // Esta es una implementación placeholder
    // En producción, usaría MyScript o similar
    
    // Por ahora, simplemente indicamos que esta función necesita backend
    console.warn('Ink to Text requires backend service or ML model');
    return '';
  }

  /**
   * Detecta y extrae tablas de la imagen
   */
  async extractTables(imageUri: string): Promise<Array<{
    rows: number;
    cols: number;
    cells: string[][];
    bbox: { x: number; y: number; width: number; height: number };
  }>> {
    // Implementación placeholder
    // En producción, usaría OpenCV o modelo de detección de tablas
    
    console.warn('Table extraction requires advanced CV algorithms');
    return [];
  }

  /**
   * Detecta y extrae fórmulas matemáticas
   */
  async extractFormulas(imageUri: string): Promise<Array<{
    latex: string;
    confidence: number;
    bbox: { x: number; y: number; width: number; height: number };
  }>> {
    // Implementación placeholder
    // En producción, usaría Mathpix o similar
    
    console.warn('Formula extraction requires specialized service');
    return [];
  }
}

export const ocrService = new OCRService();
export default OCRService;
