/**
 * ProNote - Storage Service
 * Gestión avanzada de almacenamiento local
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import { Document, Page, Node } from '@types/index';

export interface StorageStats {
  totalSize: number;
  documentsSize: number;
  imagesSize: number;
  audioSize: number;
  cacheSize: number;
  freeSpace: number;
}

export interface BackupInfo {
  id: string;
  name: string;
  createdAt: number;
  size: number;
  documentCount: number;
  includesMedia: boolean;
}

class StorageService {
  private readonly DOCUMENTS_KEY = 'pronote-documents-v2';
  private readonly SETTINGS_KEY = 'pronote-settings';
  private readonly BACKUPS_DIR = FileSystem.documentDirectory + 'backups/';
  private readonly IMAGES_DIR = FileSystem.documentDirectory + 'images/';
  private readonly AUDIO_DIR = FileSystem.documentDirectory + 'audio/';

  /**
   * Inicializa directorios de almacenamiento
   */
  async initialize(): Promise<void> {
    await this.ensureDirectories();
  }

  /**
   * Asegura que los directorios existan
   */
  private async ensureDirectories(): Promise<void> {
    const directories = [this.BACKUPS_DIR, this.IMAGES_DIR, this.AUDIO_DIR];
    
    for (const dir of directories) {
      const dirInfo = await FileSystem.getInfoAsync(dir);
      if (!dirInfo.exists) {
        await FileSystem.makeDirectoryAsync(dir, { intermediates: true });
      }
    }
  }

  /**
   * Guarda documentos
   */
  async saveDocuments(documents: Document[]): Promise<void> {
    try {
      await AsyncStorage.setItem(this.DOCUMENTS_KEY, JSON.stringify(documents));
    } catch (error) {
      console.error('Error saving documents:', error);
      throw error;
    }
  }

  /**
   * Carga documentos
   */
  async loadDocuments(): Promise<Document[]> {
    try {
      const data = await AsyncStorage.getItem(this.DOCUMENTS_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Error loading documents:', error);
      return [];
    }
  }

  /**
   * Guarda configuración
   */
  async saveSettings(settings: any): Promise<void> {
    try {
      await AsyncStorage.setItem(this.SETTINGS_KEY, JSON.stringify(settings));
    } catch (error) {
      console.error('Error saving settings:', error);
      throw error;
    }
  }

  /**
   * Carga configuración
   */
  async loadSettings(): Promise<any> {
    try {
      const data = await AsyncStorage.getItem(this.SETTINGS_KEY);
      return data ? JSON.parse(data) : {};
    } catch (error) {
      console.error('Error loading settings:', error);
      return {};
    }
  }

  /**
   * Guarda imagen
   */
  async saveImage(uri: string, fileName: string): Promise<string> {
    const destPath = this.IMAGES_DIR + fileName;
    
    try {
      await FileSystem.copyAsync({
        from: uri,
        to: destPath,
      });
      return destPath;
    } catch (error) {
      console.error('Error saving image:', error);
      throw error;
    }
  }

  /**
   * Elimina imagen
   */
  async deleteImage(fileName: string): Promise<void> {
    try {
      await FileSystem.deleteAsync(this.IMAGES_DIR + fileName, { idempotent: true });
    } catch (error) {
      console.error('Error deleting image:', error);
    }
  }

  /**
   * Obtiene estadísticas de almacenamiento
   */
  async getStats(): Promise<StorageStats> {
    try {
      const [documentsInfo, imagesInfo, audioInfo, freeSpace] = await Promise.all([
        this.getDirectorySize(this.BACKUPS_DIR),
        this.getDirectorySize(this.IMAGES_DIR),
        this.getDirectorySize(this.AUDIO_DIR),
        FileSystem.getFreeDiskStorageAsync(),
      ]);

      const documentsData = await AsyncStorage.getItem(this.DOCUMENTS_KEY);
      const documentsSize = documentsData ? documentsData.length * 2 : 0; // Aproximación

      return {
        totalSize: documentsSize + imagesInfo + audioInfo,
        documentsSize,
        imagesSize: imagesInfo,
        audioSize: audioInfo,
        cacheSize: documentsInfo,
        freeSpace,
      };
    } catch (error) {
      console.error('Error getting storage stats:', error);
      return {
        totalSize: 0,
        documentsSize: 0,
        imagesSize: 0,
        audioSize: 0,
        cacheSize: 0,
        freeSpace: 0,
      };
    }
  }

  /**
   * Obtiene tamaño de directorio
   */
  private async getDirectorySize(dir: string): Promise<number> {
    try {
      const files = await FileSystem.readDirectoryAsync(dir);
      let totalSize = 0;

      for (const file of files) {
        const fileInfo = await FileSystem.getInfoAsync(dir + file);
        if (fileInfo.exists) {
          totalSize += fileInfo.size;
        }
      }

      return totalSize;
    } catch {
      return 0;
    }
  }

  /**
   * Crea backup
   */
  async createBackup(name: string, includeMedia: boolean = true): Promise<BackupInfo> {
    const timestamp = Date.now();
    const backupId = `backup_${timestamp}`;
    const backupPath = this.BACKUPS_DIR + backupId + '.json';

    try {
      const documents = await this.loadDocuments();
      
      const backup = {
        id: backupId,
        name,
        createdAt: timestamp,
        documents,
        includeMedia,
        version: '2.0',
      };

      await FileSystem.writeAsStringAsync(
        backupPath,
        JSON.stringify(backup, null, 2)
      );

      const fileInfo = await FileSystem.getInfoAsync(backupPath);

      return {
        id: backupId,
        name,
        createdAt: timestamp,
        size: fileInfo.exists ? fileInfo.size : 0,
        documentCount: documents.length,
        includesMedia: includeMedia,
      };
    } catch (error) {
      console.error('Error creating backup:', error);
      throw error;
    }
  }

  /**
   * Lista backups
   */
  async listBackups(): Promise<BackupInfo[]> {
    try {
      const files = await FileSystem.readDirectoryAsync(this.BACKUPS_DIR);
      const backups: BackupInfo[] = [];

      for (const file of files) {
        if (file.endsWith('.json')) {
          const content = await FileSystem.readAsStringAsync(this.BACKUPS_DIR + file);
          const backup = JSON.parse(content);
          const fileInfo = await FileSystem.getInfoAsync(this.BACKUPS_DIR + file);

          backups.push({
            id: backup.id,
            name: backup.name,
            createdAt: backup.createdAt,
            size: fileInfo.exists ? fileInfo.size : 0,
            documentCount: backup.documents?.length || 0,
            includesMedia: backup.includeMedia,
          });
        }
      }

      return backups.sort((a, b) => b.createdAt - a.createdAt);
    } catch (error) {
      console.error('Error listing backups:', error);
      return [];
    }
  }

  /**
   * Restaura backup
   */
  async restoreBackup(backupId: string): Promise<Document[]> {
    const backupPath = this.BACKUPS_DIR + backupId + '.json';

    try {
      const content = await FileSystem.readAsStringAsync(backupPath);
      const backup = JSON.parse(content);

      await this.saveDocuments(backup.documents);
      return backup.documents;
    } catch (error) {
      console.error('Error restoring backup:', error);
      throw error;
    }
  }

  /**
   * Elimina backup
   */
  async deleteBackup(backupId: string): Promise<void> {
    try {
      await FileSystem.deleteAsync(this.BACKUPS_DIR + backupId + '.json', {
        idempotent: true,
      });
    } catch (error) {
      console.error('Error deleting backup:', error);
      throw error;
    }
  }

  /**
   * Limpia caché
   */
  async clearCache(): Promise<void> {
    try {
      const cacheDir = FileSystem.cacheDirectory;
      if (cacheDir) {
        await FileSystem.deleteAsync(cacheDir, { idempotent: true });
      }
    } catch (error) {
      console.error('Error clearing cache:', error);
    }
  }

  /**
   * Exporta todos los datos
   */
  async exportAllData(): Promise<string> {
    const exportData = {
      documents: await this.loadDocuments(),
      settings: await this.loadSettings(),
      exportedAt: Date.now(),
      version: '2.0',
    };

    const exportPath = FileSystem.cacheDirectory + `pronote_export_${Date.now()}.json`;
    
    await FileSystem.writeAsStringAsync(
      exportPath,
      JSON.stringify(exportData, null, 2)
    );

    return exportPath;
  }

  /**
   * Importa datos
   */
  async importData(importPath: string): Promise<void> {
    try {
      const content = await FileSystem.readAsStringAsync(importPath);
      const data = JSON.parse(content);

      if (data.documents) {
        await this.saveDocuments(data.documents);
      }

      if (data.settings) {
        await this.saveSettings(data.settings);
      }
    } catch (error) {
      console.error('Error importing data:', error);
      throw error;
    }
  }

  /**
   * Limpia todo el almacenamiento
   */
  async clearAll(): Promise<void> {
    try {
      await AsyncStorage.clear();
      
      const dirs = [this.BACKUPS_DIR, this.IMAGES_DIR, this.AUDIO_DIR];
      for (const dir of dirs) {
        await FileSystem.deleteAsync(dir, { idempotent: true });
      }
      
      await this.ensureDirectories();
    } catch (error) {
      console.error('Error clearing storage:', error);
      throw error;
    }
  }
}

export const storageService = new StorageService();
export default StorageService;
