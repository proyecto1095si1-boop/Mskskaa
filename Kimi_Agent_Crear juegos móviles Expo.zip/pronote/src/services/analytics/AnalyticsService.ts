/**
 * ProNote - Analytics Service
 * Seguimiento de uso y métricas de la aplicación
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Device from 'expo-device';
import { Platform } from 'react-native';

export interface AnalyticsEvent {
  name: string;
  properties?: Record<string, any>;
  timestamp: number;
}

export interface UserSession {
  sessionId: string;
  startTime: number;
  endTime?: number;
  duration?: number;
  pagesViewed: string[];
  actions: AnalyticsEvent[];
}

export interface AppMetrics {
  totalSessions: number;
  totalTimeSpent: number;
  documentsCreated: number;
  pagesCreated: number;
  strokesDrawn: number;
  exportsCount: number;
  featureUsage: Record<string, number>;
}

class AnalyticsService {
  private currentSession: UserSession | null = null;
  private eventsQueue: AnalyticsEvent[] = [];
  private isEnabled: boolean = true;
  private readonly SESSION_KEY = 'pronote-analytics-session';
  private readonly METRICS_KEY = 'pronote-analytics-metrics';
  private readonly EVENTS_KEY = 'pronote-analytics-events';

  /**
   * Inicializa el servicio de analytics
   */
  async initialize(): Promise<void> {
    const enabled = await AsyncStorage.getItem('pronote-analytics-enabled');
    this.isEnabled = enabled !== 'false';
    
    // Cargar eventos pendientes
    await this.loadPendingEvents();
  }

  /**
   * Inicia una nueva sesión de usuario
   */
  startSession(): void {
    if (!this.isEnabled) return;

    this.currentSession = {
      sessionId: `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      startTime: Date.now(),
      pagesViewed: [],
      actions: [],
    };

    this.trackEvent('session_start', {
      deviceType: Device.deviceType,
      brand: Device.brand,
      model: Device.modelName,
      osVersion: Device.osVersion,
      platform: Platform.OS,
    });
  }

  /**
   * Finaliza la sesión actual
   */
  endSession(): void {
    if (!this.isEnabled || !this.currentSession) return;

    this.currentSession.endTime = Date.now();
    this.currentSession.duration = this.currentSession.endTime - this.currentSession.startTime;

    this.trackEvent('session_end', {
      duration: this.currentSession.duration,
      pagesViewed: this.currentSession.pagesViewed.length,
      actionsCount: this.currentSession.actions.length,
    });

    this.saveSession();
    this.currentSession = null;
  }

  /**
   * Registra un evento
   */
  trackEvent(eventName: string, properties: Record<string, any> = {}): void {
    if (!this.isEnabled) return;

    const event: AnalyticsEvent = {
      name: eventName,
      properties: {
        ...properties,
        timestamp: Date.now(),
        sessionId: this.currentSession?.sessionId,
      },
      timestamp: Date.now(),
    };

    this.eventsQueue.push(event);

    if (this.currentSession) {
      this.currentSession.actions.push(event);
    }

    // Guardar periódicamente
    if (this.eventsQueue.length >= 10) {
      this.flushEvents();
    }
  }

  /**
   * Registra visualización de página
   */
  trackPageView(pageName: string, properties?: Record<string, any>): void {
    this.trackEvent('page_view', { page: pageName, ...properties });
    
    if (this.currentSession && !this.currentSession.pagesViewed.includes(pageName)) {
      this.currentSession.pagesViewed.push(pageName);
    }
  }

  /**
   * Registra uso de herramienta
   */
  trackToolUsage(toolName: string, duration?: number): void {
    this.trackEvent('tool_used', {
      tool: toolName,
      duration,
    });
  }

  /**
   * Registra creación de documento
   */
  trackDocumentCreated(template?: string): void {
    this.trackEvent('document_created', { template });
    this.incrementMetric('documentsCreated');
  }

  /**
   * Registra exportación
   */
  trackExport(format: string, success: boolean): void {
    this.trackEvent('document_exported', { format, success });
    if (success) {
      this.incrementMetric('exportsCount');
    }
  }

  /**
   * Registra error
   */
  trackError(errorType: string, errorMessage: string, context?: Record<string, any>): void {
    this.trackEvent('error', {
      errorType,
      errorMessage,
      ...context,
    });
  }

  /**
   * Registra rendimiento
   */
  trackPerformance(metricName: string, value: number, unit?: string): void {
    this.trackEvent('performance', {
      metric: metricName,
      value,
      unit,
    });
  }

  /**
   * Incrementa una métrica
   */
  private async incrementMetric(metricName: keyof AppMetrics): Promise<void> {
    try {
      const metricsJson = await AsyncStorage.getItem(this.METRICS_KEY);
      const metrics: Partial<AppMetrics> = metricsJson ? JSON.parse(metricsJson) : {};
      
      (metrics[metricName] as number) = ((metrics[metricName] as number) || 0) + 1;
      
      await AsyncStorage.setItem(this.METRICS_KEY, JSON.stringify(metrics));
    } catch (error) {
      console.error('Error incrementing metric:', error);
    }
  }

  /**
   * Guarda la sesión actual
   */
  private async saveSession(): Promise<void> {
    if (!this.currentSession) return;

    try {
      const sessionsJson = await AsyncStorage.getItem(this.SESSION_KEY);
      const sessions: UserSession[] = sessionsJson ? JSON.parse(sessionsJson) : [];
      
      sessions.push(this.currentSession);
      
      // Mantener solo las últimas 100 sesiones
      if (sessions.length > 100) {
        sessions.shift();
      }
      
      await AsyncStorage.setItem(this.SESSION_KEY, JSON.stringify(sessions));
    } catch (error) {
      console.error('Error saving session:', error);
    }
  }

  /**
   * Guarda eventos pendientes
   */
  private async flushEvents(): Promise<void> {
    if (this.eventsQueue.length === 0) return;

    try {
      const eventsJson = await AsyncStorage.getItem(this.EVENTS_KEY);
      const storedEvents: AnalyticsEvent[] = eventsJson ? JSON.parse(eventsJson) : [];
      
      storedEvents.push(...this.eventsQueue);
      
      // Mantener solo los últimos 1000 eventos
      if (storedEvents.length > 1000) {
        storedEvents.splice(0, storedEvents.length - 1000);
      }
      
      await AsyncStorage.setItem(this.EVENTS_KEY, JSON.stringify(storedEvents));
      this.eventsQueue = [];
    } catch (error) {
      console.error('Error flushing events:', error);
    }
  }

  /**
   * Carga eventos pendientes
   */
  private async loadPendingEvents(): Promise<void> {
    try {
      const eventsJson = await AsyncStorage.getItem(this.EVENTS_KEY);
      if (eventsJson) {
        this.eventsQueue = JSON.parse(eventsJson);
      }
    } catch (error) {
      console.error('Error loading pending events:', error);
    }
  }

  /**
   * Obtiene métricas de la app
   */
  async getMetrics(): Promise<AppMetrics> {
    try {
      const metricsJson = await AsyncStorage.getItem(this.METRICS_KEY);
      const storedMetrics: Partial<AppMetrics> = metricsJson ? JSON.parse(metricsJson) : {};
      
      return {
        totalSessions: storedMetrics.totalSessions || 0,
        totalTimeSpent: storedMetrics.totalTimeSpent || 0,
        documentsCreated: storedMetrics.documentsCreated || 0,
        pagesCreated: storedMetrics.pagesCreated || 0,
        strokesDrawn: storedMetrics.strokesDrawn || 0,
        exportsCount: storedMetrics.exportsCount || 0,
        featureUsage: storedMetrics.featureUsage || {},
      };
    } catch (error) {
      console.error('Error getting metrics:', error);
      return {
        totalSessions: 0,
        totalTimeSpent: 0,
        documentsCreated: 0,
        pagesCreated: 0,
        strokesDrawn: 0,
        exportsCount: 0,
        featureUsage: {},
      };
    }
  }

  /**
   * Obtiene historial de sesiones
   */
  async getSessions(): Promise<UserSession[]> {
    try {
      const sessionsJson = await AsyncStorage.getItem(this.SESSION_KEY);
      return sessionsJson ? JSON.parse(sessionsJson) : [];
    } catch (error) {
      console.error('Error getting sessions:', error);
      return [];
    }
  }

  /**
   * Habilita/deshabilita analytics
   */
  async setEnabled(enabled: boolean): Promise<void> {
    this.isEnabled = enabled;
    await AsyncStorage.setItem('pronote-analytics-enabled', enabled.toString());
  }

  /**
   * Verifica si analytics está habilitado
   */
  isAnalyticsEnabled(): boolean {
    return this.isEnabled;
  }

  /**
   * Limpia todos los datos de analytics
   */
  async clearAllData(): Promise<void> {
    await AsyncStorage.multiRemove([
      this.SESSION_KEY,
      this.METRICS_KEY,
      this.EVENTS_KEY,
    ]);
    this.eventsQueue = [];
    this.currentSession = null;
  }

  /**
   * Exporta datos de analytics
   */
  async exportData(): Promise<{
    sessions: UserSession[];
    metrics: AppMetrics;
    events: AnalyticsEvent[];
  }> {
    const [sessions, metrics, eventsJson] = await Promise.all([
      this.getSessions(),
      this.getMetrics(),
      AsyncStorage.getItem(this.EVENTS_KEY),
    ]);

    return {
      sessions,
      metrics,
      events: eventsJson ? JSON.parse(eventsJson) : [],
    };
  }
}

export const analyticsService = new AnalyticsService();
export default AnalyticsService;
